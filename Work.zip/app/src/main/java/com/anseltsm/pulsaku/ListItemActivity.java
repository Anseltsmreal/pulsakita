package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ListItemActivity extends AppCompatActivity {
	
	private String fontName = "";
	private String typeace = "";
	
	private LinearLayout linear3;
	private TabLayout tablayout1;
	private ViewPager viewpager1;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private LinearLayout linear6;
	private TextView textview1;
	
	private TabFragmentAdapter Tab;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.list_item);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		tablayout1 = findViewById(R.id.tablayout1);
		viewpager1 = findViewById(R.id.viewpager1);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		linear6 = findViewById(R.id.linear6);
		textview1 = findViewById(R.id.textview1);
		Tab = new TabFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MainActivity.class);
				startActivity(i);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		_FilterPhoneNumber();
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		tablayout1.setupWithViewPager(viewpager1);
		tablayout1.addTab(tablayout1.newTab().setText("Pulsa"));
		tablayout1.addTab(tablayout1.newTab().setText("Data"));
		tablayout1.addTab(tablayout1.newTab().setText("Masa Aktif"));
		Tab.setTabCount(3);
		viewpager1.setAdapter(Tab);
		tablayout1.setTabTextColors(0xFF424242, 0xFF000000);
		tablayout1.setSelectedTabIndicatorColor(0xFF000000);
		tablayout1.setInlineLabel(false);
		_changeActivityFont("muli");
	}
	
	public class TabFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public TabFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			if (_position == 0) {
				return "Pulsa";
			}
			if (_position == 1) {
				return "Data";
			}
			if (_position == 2) {
				return "Masa Aktif";
			}
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new ListPulsaFragmentActivity();
			}
			if (_position == 1) {
				return new ListDataFragmentActivity();
			}
			if (_position == 2) {
				return new ListDataFragmentActivity();
			}
			return null;
		}
	}
	
	@Override
	public void onBackPressed() {
		
	}
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _FilterPhoneNumber() {
		String cNumber = getIntent().getStringExtra("CNumber");
		
		// Telkomsel
		if (cNumber.startsWith("0811") || cNumber.startsWith("0812") || cNumber.startsWith("0813") ||
		    cNumber.startsWith("0821") || cNumber.startsWith("0822") || cNumber.startsWith("0823") ||
		    cNumber.startsWith("0851") || cNumber.startsWith("0852") || cNumber.startsWith("0853")) {
			    textview1.setText("TELKOMSEL - ".concat(getIntent().getStringExtra("Number")));
			
			// Indosat
		} else if (cNumber.startsWith("0814") || cNumber.startsWith("0815") || cNumber.startsWith("0816") ||
		           cNumber.startsWith("0855") || cNumber.startsWith("0856") || cNumber.startsWith("0857") || 
		           cNumber.startsWith("0858") || cNumber.startsWith("0877") || cNumber.startsWith("0878")) {
			    textview1.setText("INDOSAT - ".concat(getIntent().getStringExtra("Number")));
			
			// XL Axiata
		} else if (cNumber.startsWith("0817") || cNumber.startsWith("0818") || cNumber.startsWith("0819") || 
		           cNumber.startsWith("0859") || cNumber.startsWith("0879")) {
			    textview1.setText("XL - ".concat(getIntent().getStringExtra("Number")));
			
			// Tri
		} else if (cNumber.startsWith("0895") || cNumber.startsWith("0896") || cNumber.startsWith("0897") || 
		           cNumber.startsWith("0898") || cNumber.startsWith("0899")) {
			    textview1.setText("TRI - ".concat(getIntent().getStringExtra("Number")));
			
			// Axis
		} else if (cNumber.startsWith("0831") || cNumber.startsWith("0832") || cNumber.startsWith("0833") || 
		           cNumber.startsWith("0838")) {
			    textview1.setText("AXIS - ".concat(getIntent().getStringExtra("Number")));
			
			// Smartfren
		} else if (cNumber.startsWith("0881") || cNumber.startsWith("0882") || cNumber.startsWith("0883") || 
		           cNumber.startsWith("0884") || cNumber.startsWith("0885") || cNumber.startsWith("0886") || 
		           cNumber.startsWith("0887") || cNumber.startsWith("0888") || cNumber.startsWith("0889")) {
			    textview1.setText("SMARTFREN - ".concat(getIntent().getStringExtra("Number")));
			
			// Tidak dikenal
		} else {
			    textview1.setText("Operator tidak dikenali - ".concat(getIntent().getStringExtra("Number")));
		}
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}