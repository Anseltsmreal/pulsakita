package com.anseltsm.pulsaku;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class HomeFragmentActivity extends Fragment {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private String seems = "";
	private String balance = "";
	private boolean hideBal = false;
	private HashMap<String, Object> map = new HashMap<>();
	private String AM = "";
	private String PM = "";
	private String EVE = "";
	private String NEW_DAY = "";
	private double hour = 0;
	private double counter = 0;
	private HashMap<String, Object> mj = new HashMap<>();
	private boolean wal = false;
	private boolean His_empty = false;
	private double percentage = 0;
	private double ini_blc = 0;
	private double sendAmount = 0;
	private double AMT = 0;
	private double AMOUNT = 0;
	private String amt = "";
	private String reference = "";
	private String ini_bal = "";
	private String verifyID = "";
	private HashMap<String, Object> dataMap = new HashMap<>();
	private HashMap<String, Object> token = new HashMap<>();
	private HashMap<String, Object> refreshMap = new HashMap<>();
	private double saldo = 0;
	private HashMap<String, Object> server = new HashMap<>();
	private double count = 0;
	
	private ArrayList<HashMap<String, Object>> slide = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listSlide = new ArrayList<>();
	private ArrayList<String> broadKeys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> broadMessageList = new ArrayList<>();
	private ArrayList<String> keys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listUsersMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listMenu = new ArrayList<>();
	
	private LinearLayout linear116;
	private ScrollView vscroll1;
	private LinearLayout linUpp;
	private LinearLayout linear82;
	private LinearLayout linear100;
	private LinearLayout linear84;
	private ImageView imageCus;
	private ImageView imageNotify;
	private CircleImageView circleimage;
	private TextView textGreet;
	private LinearLayout linear117;
	private TextView Uname;
	private ImageView user_badge;
	private LinearLayout linear3;
	private LinearLayout walletCard;
	private LinearLayout linear113;
	private LinearLayout linear11;
	private LinearLayout linear101;
	private TextView textview28;
	private LinearLayout linear12;
	private TextView Fname;
	private TextView naira;
	private TextView bal;
	private ImageView img_hide_amt;
	private LinearLayout linear102;
	private ImageView imageview_logo;
	private LinearLayout SEND;
	private LinearLayout REQ;
	private LinearLayout TOPUP;
	private LinearLayout linearMENU;
	private LinearLayout linear_SEND;
	private TextView textview81;
	private ImageView imgSEND;
	private LinearLayout linear109;
	private TextView textview82;
	private ImageView imgREQ;
	private LinearLayout linear110;
	private TextView textview83;
	private ImageView imgTOPUP;
	private LinearLayout linear111;
	private TextView textview84;
	private ImageView imgMENU;
	private TextView textview59;
	private LinearLayout linear115;
	private LinearLayout linear_serv;
	private RecyclerView recyclerview1;
	private LinearLayout linear_Air;
	private LinearLayout linear_Inter;
	private ImageView imgData;
	private TextView History___B;
	private ImageView imgPulsa;
	private TextView textview58___B;
	private LinearLayout linear89;
	private LinearLayout layB1;
	private LinearLayout layB3;
	private LinearLayout layB2;
	private TextView textview65___B;
	private LinearLayout linear90;
	private TextView textview69;
	private ImageView imagev1;
	private WebView webview1;
	private LinearLayout linear_tv;
	private LinearLayout linear_elec;
	private ImageView imageview20;
	private TextView textview66___B;
	private ImageView imgListrik;
	private TextView textview68___B;
	private LinearLayout linear_game;
	private LinearLayout linear_wallet;
	private ImageView imgGame;
	private TextView textview76___B;
	private ImageView imageview29;
	private TextView textview78___B;
	private LinearLayout linear_toll;
	private LinearLayout linear_more;
	private ImageView imgToll;
	private TextView textview73___B;
	private ImageView imageview30;
	private TextView textview85__B;
	
	private TimerTask t;
	private Intent in = new Intent();
	private SharedPreferences wallet;
	private Calendar time = Calendar.getInstance();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference sql = _firebase.getReference("users");
	private ChildEventListener _sql_child_listener;
	private SharedPreferences data;
	private com.google.android.material.bottomsheet.BottomSheetDialog bs;
	private AlertDialog cd;
	private DatabaseReference serverMain = _firebase.getReference("server");
	private ChildEventListener _serverMain_child_listener;
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	private SharedPreferences sp;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.home_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear116 = _view.findViewById(R.id.linear116);
		vscroll1 = _view.findViewById(R.id.vscroll1);
		linUpp = _view.findViewById(R.id.linUpp);
		linear82 = _view.findViewById(R.id.linear82);
		linear100 = _view.findViewById(R.id.linear100);
		linear84 = _view.findViewById(R.id.linear84);
		imageCus = _view.findViewById(R.id.imageCus);
		imageNotify = _view.findViewById(R.id.imageNotify);
		circleimage = _view.findViewById(R.id.circleimage);
		textGreet = _view.findViewById(R.id.textGreet);
		linear117 = _view.findViewById(R.id.linear117);
		Uname = _view.findViewById(R.id.Uname);
		user_badge = _view.findViewById(R.id.user_badge);
		linear3 = _view.findViewById(R.id.linear3);
		walletCard = _view.findViewById(R.id.walletCard);
		linear113 = _view.findViewById(R.id.linear113);
		linear11 = _view.findViewById(R.id.linear11);
		linear101 = _view.findViewById(R.id.linear101);
		textview28 = _view.findViewById(R.id.textview28);
		linear12 = _view.findViewById(R.id.linear12);
		Fname = _view.findViewById(R.id.Fname);
		naira = _view.findViewById(R.id.naira);
		bal = _view.findViewById(R.id.bal);
		img_hide_amt = _view.findViewById(R.id.img_hide_amt);
		linear102 = _view.findViewById(R.id.linear102);
		imageview_logo = _view.findViewById(R.id.imageview_logo);
		SEND = _view.findViewById(R.id.SEND);
		REQ = _view.findViewById(R.id.REQ);
		TOPUP = _view.findViewById(R.id.TOPUP);
		linearMENU = _view.findViewById(R.id.linearMENU);
		linear_SEND = _view.findViewById(R.id.linear_SEND);
		textview81 = _view.findViewById(R.id.textview81);
		imgSEND = _view.findViewById(R.id.imgSEND);
		linear109 = _view.findViewById(R.id.linear109);
		textview82 = _view.findViewById(R.id.textview82);
		imgREQ = _view.findViewById(R.id.imgREQ);
		linear110 = _view.findViewById(R.id.linear110);
		textview83 = _view.findViewById(R.id.textview83);
		imgTOPUP = _view.findViewById(R.id.imgTOPUP);
		linear111 = _view.findViewById(R.id.linear111);
		textview84 = _view.findViewById(R.id.textview84);
		imgMENU = _view.findViewById(R.id.imgMENU);
		textview59 = _view.findViewById(R.id.textview59);
		linear115 = _view.findViewById(R.id.linear115);
		linear_serv = _view.findViewById(R.id.linear_serv);
		recyclerview1 = _view.findViewById(R.id.recyclerview1);
		linear_Air = _view.findViewById(R.id.linear_Air);
		linear_Inter = _view.findViewById(R.id.linear_Inter);
		imgData = _view.findViewById(R.id.imgData);
		History___B = _view.findViewById(R.id.History___B);
		imgPulsa = _view.findViewById(R.id.imgPulsa);
		textview58___B = _view.findViewById(R.id.textview58___B);
		linear89 = _view.findViewById(R.id.linear89);
		layB1 = _view.findViewById(R.id.layB1);
		layB3 = _view.findViewById(R.id.layB3);
		layB2 = _view.findViewById(R.id.layB2);
		textview65___B = _view.findViewById(R.id.textview65___B);
		linear90 = _view.findViewById(R.id.linear90);
		textview69 = _view.findViewById(R.id.textview69);
		imagev1 = _view.findViewById(R.id.imagev1);
		webview1 = _view.findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear_tv = _view.findViewById(R.id.linear_tv);
		linear_elec = _view.findViewById(R.id.linear_elec);
		imageview20 = _view.findViewById(R.id.imageview20);
		textview66___B = _view.findViewById(R.id.textview66___B);
		imgListrik = _view.findViewById(R.id.imgListrik);
		textview68___B = _view.findViewById(R.id.textview68___B);
		linear_game = _view.findViewById(R.id.linear_game);
		linear_wallet = _view.findViewById(R.id.linear_wallet);
		imgGame = _view.findViewById(R.id.imgGame);
		textview76___B = _view.findViewById(R.id.textview76___B);
		imageview29 = _view.findViewById(R.id.imageview29);
		textview78___B = _view.findViewById(R.id.textview78___B);
		linear_toll = _view.findViewById(R.id.linear_toll);
		linear_more = _view.findViewById(R.id.linear_more);
		imgToll = _view.findViewById(R.id.imgToll);
		textview73___B = _view.findViewById(R.id.textview73___B);
		imageview30 = _view.findViewById(R.id.imageview30);
		textview85__B = _view.findViewById(R.id.textview85__B);
		wallet = getContext().getSharedPreferences("wallet", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		data = getContext().getSharedPreferences("data", Activity.MODE_PRIVATE);
		sp = getContext().getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		imageCus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getContext().getApplicationContext(), SupportActivity.class);
				in.setAction(Intent.ACTION_VIEW);
				in.putExtra("name", "");
				startActivity(in);
			}
		});
		
		circleimage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setAction(Intent.ACTION_VIEW);
				in.setClass(getContext().getApplicationContext(), AccountSetupActivity.class);
				startActivity(in);
			}
		});
		
		SEND.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bs = new com.google.android.material.bottomsheet.BottomSheetDialog(getActivity());
				View bsV;
				bsV = getActivity().getLayoutInflater().inflate(R.layout.transfer_type,null );
				bs.setContentView(bsV);
				bs.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				final LinearLayout wallet = (LinearLayout) bsV.findViewById(R.id.wallet);
				final LinearLayout bank_acct = (LinearLayout) bsV.findViewById(R.id.bank_acct);
				final LinearLayout share = (LinearLayout) bsV.findViewById(R.id.share);
				final TextView th1 = (TextView) bsV.findViewById(R.id.th1);
				final TextView th2 = (TextView) bsV.findViewById(R.id.th2);
				final TextView th3 = (TextView) bsV.findViewById(R.id.th3);
				final TextView t1 = (TextView) bsV.findViewById(R.id.t1);
				final TextView t2 = (TextView) bsV.findViewById(R.id.t2);
				final TextView t3 = (TextView) bsV.findViewById(R.id.t3);
				final LinearLayout bg = (LinearLayout) bsV.findViewById(R.id.bg);
				final LinearLayout indicator = (LinearLayout) bsV.findViewById(R.id.indicator);
				th1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
				th2.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
				th3.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
				indicator.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFE0E0E0));
				_advancedCorners(bg, "#FFFFFF", 30, 30, 0, 0);
				bs.setCancelable(true);
				wallet.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						bs.dismiss();
						SketchwareUtil.showMessage(getContext().getApplicationContext(), "Features coming soon!");
					}
				});
				bank_acct.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						bs.dismiss();
						SketchwareUtil.showMessage(getContext().getApplicationContext(), "Features coming soon!");
					}
				});
				bs.show();
				share.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						bs.dismiss();
						in.setClass(getContext().getApplicationContext(), TransferFundActivity.class);
						in.putExtra("Type", "Send");
						startActivity(in);
					}
				});
				bs.show();
			}
		});
		
		TOPUP.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getContext().getApplicationContext(), TopupActivity.class);
				in.setAction(Intent.ACTION_VIEW);
				startActivity(in);
			}
		});
		
		linear_Air.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_Air.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								in.setClass(getContext().getApplicationContext(), RechargepyActivity.class);
								in.putExtra("type", "PulsaData");
								sp.edit().putString("tp", "PulsaData").commit();
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		linear_Inter.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_Inter.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								SketchwareUtil.showMessage(getContext().getApplicationContext(), "Maaf Fitur Sedang Maintenance!");
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		textview69.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(linear3);
				if (imagev1.getRotation() == 270) {
					layB2.setVisibility(View.VISIBLE);
					layB3.setVisibility(View.VISIBLE);
					imagev1.setRotation((float)(360));
					textview69.setText("Lebih sedikit");
				} else {
					if (imagev1.getRotation() == 360) {
						imagev1.setRotation((float)(270));
						layB2.setVisibility(View.GONE);
						layB3.setVisibility(View.GONE);
						textview69.setText("Lebih banyak");
					}
				}
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		linear_elec.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_elec.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								in.setClass(getContext().getApplicationContext(), TokenKategoriActivity.class);
								in.putExtra("id", "23");
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		linear_game.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_game.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								in.setClass(getContext().getApplicationContext(), ChooseGameActivity.class);
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		linear_wallet.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_wallet.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								in.setClass(getContext().getApplicationContext(), ChooseWalletActivity.class);
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		_sql_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				sql.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listUsersMap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listUsersMap.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("full_name")) {
								Fname.setText(_childValue.get("full_name").toString());
								data.edit().putString("name", _childValue.get("full_name").toString()).commit();
							}
							if (_childValue.containsKey("username")) {
								Uname.setText(" @".concat(_childValue.get("username").toString()));
								data.edit().putString("username", _childValue.get("username").toString()).commit();
							}
							Glide.with(getContext().getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(circleimage);
							data.edit().putString("avatar", _childValue.get("avatar").toString()).commit();
							if (_childValue.get("status").toString().equals("Member")) {
								user_badge.setVisibility(View.GONE);
							} else {
								if (_childValue.get("status").toString().equals("Special")) {
									user_badge.setVisibility(View.VISIBLE);
									user_badge.setImageResource(R.drawable.verified_badge);
									user_badge.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
								} else {
									if (_childValue.get("status").toString().equals("Owner")) {
										user_badge.setVisibility(View.VISIBLE);
										user_badge.setImageResource(R.drawable.owner_badge);
										user_badge.setColorFilter(0xFFFFDF00, PorterDuff.Mode.MULTIPLY);
									}
								}
							}
							if (_childValue.get("banned").toString().equals("Yes")) {
								in.setClass(getContext().getApplicationContext(), BannedActivity.class);
								startActivity(in);
							} else {
								
							}
							bal.setText(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("saldo").toString())));
							balance = _childValue.get("saldo").toString();
							sp.edit().putString("uid", _childValue.get("uid").toString()).commit();
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				sql.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listUsersMap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listUsersMap.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("full_name")) {
								Fname.setText(_childValue.get("full_name").toString());
								data.edit().putString("name", _childValue.get("full_name").toString()).commit();
							}
							if (_childValue.containsKey("username")) {
								Uname.setText(" @".concat(_childValue.get("username").toString()));
								data.edit().putString("username", _childValue.get("username").toString()).commit();
							}
							Glide.with(getContext().getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(circleimage);
							data.edit().putString("avatar", _childValue.get("avatar").toString()).commit();
							if (_childValue.get("status").toString().equals("Member")) {
								user_badge.setVisibility(View.GONE);
							} else {
								if (_childValue.get("status").toString().equals("Special")) {
									user_badge.setVisibility(View.VISIBLE);
									user_badge.setImageResource(R.drawable.verified_badge);
									user_badge.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
								} else {
									if (_childValue.get("status").toString().equals("Owner")) {
										user_badge.setVisibility(View.VISIBLE);
										user_badge.setImageResource(R.drawable.owner_badge);
										user_badge.setColorFilter(0xFFFFDF00, PorterDuff.Mode.MULTIPLY);
									}
								}
							}
							if (_childValue.get("banned").toString().equals("Yes")) {
								in.setClass(getContext().getApplicationContext(), BannedActivity.class);
								startActivity(in);
							} else {
								
							}
							bal.setText(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("saldo").toString())));
							balance = new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("saldo").toString()));
							sp.edit().putString("uid", _childValue.get("uid").toString()).commit();
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sql.addChildEventListener(_sql_child_listener);
		
		_serverMain_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Server")) {
					if (_childValue.get("Status").toString().equals("Offline")) {
						in.setClass(getContext().getApplicationContext(), MaintenanceActivity.class);
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Server")) {
					if (_childValue.get("Status").toString().equals("Offline")) {
						in.setClass(getContext().getApplicationContext(), MaintenanceActivity.class);
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		serverMain.addChildEventListener(_serverMain_child_listener);
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					sp.edit().putString("telkomsel", _childValue.get("telkomsel").toString()).commit();
					sp.edit().putString("xl", _childValue.get("xl").toString()).commit();
					sp.edit().putString("axis", _childValue.get("axis").toString()).commit();
					sp.edit().putString("tri", _childValue.get("tri").toString()).commit();
					sp.edit().putString("indosat", _childValue.get("indosat").toString()).commit();
					sp.edit().putString("smartfren", _childValue.get("smartfren").toString()).commit();
					sp.edit().putString("game", _childValue.get("game").toString()).commit();
					sp.edit().putString("ewallet", _childValue.get("ewallet").toString()).commit();
					sp.edit().putString("token", _childValue.get("token").toString()).commit();
					sp.edit().putString("info", _childValue.get("info").toString()).commit();
					webview1.loadUrl(_childValue.get("notif").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					sp.edit().putString("telkomsel", _childValue.get("telkomsel").toString()).commit();
					sp.edit().putString("xl", _childValue.get("xl").toString()).commit();
					sp.edit().putString("axis", _childValue.get("axis").toString()).commit();
					sp.edit().putString("tri", _childValue.get("tri").toString()).commit();
					sp.edit().putString("indosat", _childValue.get("indosat").toString()).commit();
					sp.edit().putString("smartfren", _childValue.get("smartfren").toString()).commit();
					sp.edit().putString("game", _childValue.get("game").toString()).commit();
					sp.edit().putString("ewallet", _childValue.get("ewallet").toString()).commit();
					sp.edit().putString("token", _childValue.get("token").toString()).commit();
					sp.edit().putString("info", _childValue.get("info").toString()).commit();
					webview1.loadUrl(_childValue.get("notif").toString());
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_removeScollBar(vscroll1);
		_Image_Slider();
		_bolder();
		_hideSee();
		user_badge.setColorFilter(0xFFFFDF00, PorterDuff.Mode.MULTIPLY);
		user_badge.setVisibility(View.GONE);
		imagev1.setRotation((float)(270));
		layB2.setVisibility(View.GONE);
		layB3.setVisibility(View.GONE);
		walletCard.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFEEEEEE));
		linear_serv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)31, 0xFFFAFAFA));
		walletCard.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFEEEEEE));
		img_hide_amt.setColorFilter(Color.parseColor("#BDBDBD"));
		//imageNotify.setColorFilter(Color.parseColor("#ffffff"));
		linear_Air.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_Inter.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		imagev1.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
		Fname.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		naira.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/mulibold.ttf"), 0);
		bal.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/mulibold.ttf"), 0);
		textGreet.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		imageCus.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
		imgSEND.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
		imgREQ.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
		imgTOPUP.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
		imgMENU.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
		_advancedCorners(linear11, "#212121", 35, 35, 0, 0);
		_autoTransitionScroll(linear3);
		layB2.setVisibility(View.VISIBLE);
		layB3.setVisibility(View.VISIBLE);
		imagev1.setRotation((float)(360));
		textview69.setText("Lebih sedikit");
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (wallet.contains("balance")) {
			bal.setText("•••");
			img_hide_amt.setImageResource(R.drawable.icon_visibility_black);
		}
		if (data.contains("avatar")) {
			circleimage.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(data.getString("avatar", ""), 1024, 1024));
		}
		_GREET_USER();
		sql.addChildEventListener(_sql_child_listener);
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		t.cancel();
	}
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _ColorShadow_SDK28(final View _view, final String _color, final double _number) {
		_view.setElevation((float)_number);
		
		_view.setOutlineAmbientShadowColor(Color.parseColor(_color));
		_view.setOutlineSpotShadowColor(Color.parseColor(_color));
	}
	
	
	public void _advancedCorners(final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _GREET_USER() {
		Calendar time = Calendar.getInstance();
		AM = "Selamat Pagi,";
		PM = "Selamat siang,";
		EVE = "Selamat Sore,";
		NEW_DAY = "Selamat Malam,";
		hour = time.get(Calendar.HOUR_OF_DAY);
		if (hour >= 10 && hour < 15) {
			    textGreet.setText(PM);
		} else if (hour >= 6 && hour < 10) {
			    textGreet.setText(AM);
		} else if (hour >= 15 && hour < 18) {
			    textGreet.setText(EVE);
		} else {
			    textGreet.setText(NEW_DAY);
		}
	}
	
	
	public void _Image_Slider() {
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", "0");
			slide.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", "1");
			slide.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", "2");
			slide.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", "3");
			slide.add(_item);
		}
		recyclerview1.setAdapter(new Recyclerview1Adapter(slide));
		recyclerview1.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		t = new TimerTask() {
			@Override
			public void run() {
				getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						count = count + 1;
						if (count > 4) {
							count = 0;
							recyclerview1.smoothScrollToPosition((int)count);
						} else {
							recyclerview1.smoothScrollToPosition((int)count);
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(3500), (int)(3500));
	}
	
	
	public void _bolder() {
		History___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview58___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview65___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview66___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview68___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview76___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview78___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview73___B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		textview85__B.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
		linear_Air.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_Inter.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_tv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_elec.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_game.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_wallet.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_toll.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
		linear_more.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)31, (int)2, 0xFFEEEEEE, Color.TRANSPARENT));
	}
	
	
	public void _hideSee() {
		seems = "1";
		img_hide_amt.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						if (seems.equals("1")) {
								if (bal.getText().toString().equals("•••")) {
						_autoTransitionScroll(linear12);
						bal.setText(new DecimalFormat("###,###,###").format(Double.parseDouble(balance)));
						img_hide_amt.setImageResource(R.drawable.icon_visibility_off_black);
					} else {
						_autoTransitionScroll(linear12);
						bal.setText("•••");
						img_hide_amt.setImageResource(R.drawable.icon_visibility_black);
					}
								seems = "0";
						}
						else {
						if (bal.getText().toString().equals("•••")) {
						_autoTransitionScroll(linear12);
						img_hide_amt.setImageResource(R.drawable.icon_visibility_off_black);
						bal.setText(new DecimalFormat("###,###,###").format(Double.parseDouble(balance)));
					} else {
						_autoTransitionScroll(linear12);
						bal.setText("•••");
						img_hide_amt.setImageResource(R.drawable.icon_visibility_black);
					}
								seems = "1";
						}
				}
		});
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.image_slider, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView cardAds = _view.findViewById(R.id.cardAds);
			final LinearLayout linear_ads = _view.findViewById(R.id.linear_ads);
			final ImageView adsImage = _view.findViewById(R.id.adsImage);
			
			if (_position == 0) {
				adsImage.setImageResource(R.drawable.banner_1);
			}
			if (_position == 1) {
				adsImage.setImageResource(R.drawable.banner_2);
			}
			if (_position == 2) {
				adsImage.setImageResource(R.drawable.banner_3);
			}
			if (_position == 3) {
				adsImage.setImageResource(R.drawable.banner_4);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}