package com.anseltsm.pulsaku;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class AccountSetupActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private double cnr = 0;
	private String fontName = "";
	private String typeace = "";
	private String type = "";
	private String myUsername = "";
	private boolean emptyDetails = false;
	private double count = 0;
	private HashMap<String, Object> updateUserMap = new HashMap<>();
	private boolean pik = false;
	private String path = "";
	private String imagename = "";
	private String phoneNumber = "";
	private String maskedNumber = "";
	private boolean dialog_showing = false;
	private String d = "";
	
	private ArrayList<HashMap<String, Object>> usernames = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear4;
	private ScrollView vscroll1;
	private LinearLayout linear5;
	private ImageView close;
	private LinearLayout linear18;
	private LinearLayout linear3;
	private LinearLayout cardMain;
	private LinearLayout linear17;
	private LinearLayout cardUsern;
	private LinearLayout cardName;
	private LinearLayout cardEmail;
	private LinearLayout cardNumb;
	private LinearLayout cardPin;
	private CircleImageView image;
	private TextView nameMain;
	private TextView uid;
	private TextView textview15;
	private LinearLayout linear9;
	private ImageView imageview1;
	private TextView textview2;
	private TextView usern;
	private LinearLayout linear10;
	private ImageView imageview2;
	private TextView textview3;
	private TextView name;
	private LinearLayout linear12;
	private ImageView imageview3;
	private TextView textview9;
	private TextView email;
	private LinearLayout linear14;
	private ImageView imageview4;
	private TextView textview11;
	private TextView number;
	private LinearLayout linear16;
	private ImageView imageview5;
	private TextView textview13;
	private TextView pin;
	private TextView btn;
	
	private ObjectAnimator animation = new ObjectAnimator();
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private SharedPreferences data;
	private AlertDialog cd;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private StorageReference storageDB = _firebase_storage.getReference("bucket/profile");
	private OnCompleteListener<Uri> _storageDB_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _storageDB_download_success_listener;
	private OnSuccessListener _storageDB_delete_success_listener;
	private OnProgressListener _storageDB_upload_progress_listener;
	private OnProgressListener _storageDB_download_progress_listener;
	private OnFailureListener _storageDB_failure_listener;
	
	private Intent activity = new Intent();
	private TimerTask t;
	private DatabaseReference sqlUser = _firebase.getReference("users");
	private ChildEventListener _sqlUser_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.account_setup);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		vscroll1 = findViewById(R.id.vscroll1);
		linear5 = findViewById(R.id.linear5);
		close = findViewById(R.id.close);
		linear18 = findViewById(R.id.linear18);
		linear3 = findViewById(R.id.linear3);
		cardMain = findViewById(R.id.cardMain);
		linear17 = findViewById(R.id.linear17);
		cardUsern = findViewById(R.id.cardUsern);
		cardName = findViewById(R.id.cardName);
		cardEmail = findViewById(R.id.cardEmail);
		cardNumb = findViewById(R.id.cardNumb);
		cardPin = findViewById(R.id.cardPin);
		image = findViewById(R.id.image);
		nameMain = findViewById(R.id.nameMain);
		uid = findViewById(R.id.uid);
		textview15 = findViewById(R.id.textview15);
		linear9 = findViewById(R.id.linear9);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		usern = findViewById(R.id.usern);
		linear10 = findViewById(R.id.linear10);
		imageview2 = findViewById(R.id.imageview2);
		textview3 = findViewById(R.id.textview3);
		name = findViewById(R.id.name);
		linear12 = findViewById(R.id.linear12);
		imageview3 = findViewById(R.id.imageview3);
		textview9 = findViewById(R.id.textview9);
		email = findViewById(R.id.email);
		linear14 = findViewById(R.id.linear14);
		imageview4 = findViewById(R.id.imageview4);
		textview11 = findViewById(R.id.textview11);
		number = findViewById(R.id.number);
		linear16 = findViewById(R.id.linear16);
		imageview5 = findViewById(R.id.imageview5);
		textview13 = findViewById(R.id.textview13);
		pin = findViewById(R.id.pin);
		btn = findViewById(R.id.btn);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		
		close.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				activity.setClass(getApplicationContext(), MainActivity.class);
				startActivity(activity);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				
			}
		});
		
		cardUsern.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_widget_animate(cardUsern);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								activity.setClass(getApplicationContext(), UpdateDialogActivity.class);
								activity.putExtra("t1", "Enter your Username");
								activity.putExtra("t2", "Enter your new username and update your account.");
								activity.putExtra("hint", myUsername);
								activity.putExtra("type", "username");
								startActivity(activity);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		cardName.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_widget_animate(cardName);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								activity.setClass(getApplicationContext(), UpdateDialogActivity.class);
								activity.putExtra("t1", "Full Name");
								activity.putExtra("t2", "Enter your real full name and update your account.");
								activity.putExtra("hint", data.getString("name", ""));
								activity.putExtra("type", "name");
								startActivity(activity);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		cardEmail.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				type = "email";
				_widget_animate(cardEmail);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								activity.setClass(getApplicationContext(), UpdateDialogActivity.class);
								activity.putExtra("t1", "Update Email Address");
								activity.putExtra("t2", "Enter your new email address and update your account.");
								activity.putExtra("hint", FirebaseAuth.getInstance().getCurrentUser().getEmail());
								activity.putExtra("type", type);
								startActivity(activity);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		cardNumb.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_widget_animate(cardNumb);
				type = "number";
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								activity.setClass(getApplicationContext(), UpdateNumericActivity.class);
								activity.putExtra("t1", "Add Phone Number");
								activity.putExtra("t2", "Enter your phone number to update your account.");
								activity.putExtra("hint", data.getString("mask-number", ""));
								activity.putExtra("type", type);
								startActivity(activity);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		cardPin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_widget_animate(cardPin);
				type = "pin";
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								activity.setClass(getApplicationContext(), UpdateNumericActivity.class);
								activity.putExtra("t1", "Change Pin");
								activity.putExtra("t2", "Enter your new pin and update your account.");
								activity.putExtra("hint", "****");
								activity.putExtra("type", type);
								startActivity(activity);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				image.startAnimation(fade_in);
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		uid.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", FirebaseAuth.getInstance().getCurrentUser().getUid()));
				SketchwareUtil.showMessage(getApplicationContext(), "Disalin");
			}
		});
		
		btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (pik) {
					storageDB.child(imagename).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_storageDB_failure_listener).addOnProgressListener(_storageDB_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return storageDB.child(imagename).getDownloadUrl();
						}}).addOnCompleteListener(_storageDB_upload_success_listener);
				} else {
					activity.setClass(getApplicationContext(), MainActivity.class);
					startActivity(activity);
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
					
				}
			}
		});
		
		_storageDB_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				_telegramLoaderDialog(true);
			}
		};
		
		_storageDB_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storageDB_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				updateUserMap = new HashMap<>();
				updateUserMap.put("avatar", _downloadUrl);
				sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
				updateUserMap.clear();
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								finish();
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		};
		
		_storageDB_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_storageDB_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_storageDB_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_sqlUser_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childKey)) {
					_telegramLoaderDialog(false);
					if (_childValue.containsKey("username")) {
						myUsername = _childValue.get("username").toString().toLowerCase();
						usern.setText(" @".concat(myUsername));
						data.edit().putString("username", myUsername).commit();
					}
					if (_childValue.containsKey("full_name")) {
						data.edit().putString("name", _childValue.get("full_name").toString()).commit();
						name.setText(_childValue.get("full_name").toString());
						nameMain.setText(_childValue.get("full_name").toString());
					}
					if (_childValue.containsKey("email")) {
						email.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
						data.edit().putString("email", FirebaseAuth.getInstance().getCurrentUser().getEmail()).commit();
					}
					if (_childValue.containsKey("number")) {
						phoneNumber = _childValue.get("number").toString();
						String maskedPhoneNum = phoneNumber.replaceAll("\\d(?=\\d{4})", "*");
						data.edit().putString("number", _childValue.get("number").toString()).commit();
						data.edit().putString("mask-number", maskedPhoneNum).commit();
						number.setText(data.getString("mask-number", ""));
					}
					if (_childValue.containsKey("avatar")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(image);
					}
				} else {
					if (_childValue.isEmpty()) {
						emptyDetails = true;
					} else {
						usernames.add(_childValue);
						emptyDetails = false;
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childKey)) {
					_telegramLoaderDialog(false);
					if (_childValue.containsKey("username")) {
						myUsername = _childValue.get("username").toString().toLowerCase();
						usern.setText(" @".concat(myUsername));
						data.edit().putString("username", myUsername).commit();
					}
					if (_childValue.containsKey("full_name")) {
						data.edit().putString("name", _childValue.get("full_name").toString()).commit();
						name.setText(_childValue.get("full_name").toString());
						nameMain.setText(_childValue.get("full_name").toString());
					}
					if (_childValue.containsKey("email")) {
						email.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
						data.edit().putString("email", FirebaseAuth.getInstance().getCurrentUser().getEmail()).commit();
					}
					if (_childValue.containsKey("number")) {
						phoneNumber = _childValue.get("number").toString();
						String maskedPhoneNum = phoneNumber.replaceAll("\\d(?=\\d{4})", "*");
						data.edit().putString("number", _childValue.get("number").toString()).commit();
						data.edit().putString("mask-number", maskedPhoneNum).commit();
						number.setText(data.getString("mask-number", ""));
					}
					if (_childValue.containsKey("avatar")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(image);
					}
				} else {
					if (_childValue.isEmpty()) {
						emptyDetails = true;
					} else {
						usernames.add(_childValue);
						emptyDetails = false;
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlUser.addChildEventListener(_sqlUser_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					updateUserMap = new HashMap<>();
					updateUserMap.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
					sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
					updateUserMap.clear();
					_Toast("Email Changed and automatically updated.");
				} else {
					_Toast(_errorMessage);
				}
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		cnr = 30;
		_changeActivityFont("light");
		_cardViews();
		btn.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		usern.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		email.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		number.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		pin.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		nameMain.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		if (updateUserMap.isEmpty()) {
			emptyDetails = true;
		} else {
			emptyDetails = false;
		}
		type = "";
		pik = false;
		uid.setText(FirebaseAuth.getInstance().getCurrentUser().getUid());
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				if (_filePath.get((int)(0)).endsWith("png")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Gambar di larang, harap gunakan gambar berformat \"jpg\"");
				} else {
					image.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					data.edit().putString("avatar", _filePath.get((int)(0))).commit();
					imagename = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
					path = _filePath.get((int)(0));
					pik = true;
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		sqlUser.addChildEventListener(_sqlUser_child_listener);
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _cardViews() {
		cardMain.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFFFAFAFA));
		cardUsern.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFFFAFAFA));
		cardName.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFFFAFAFA));
		cardEmail.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFFFAFAFA));
		cardNumb.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFFFAFAFA));
		cardPin.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFFFAFAFA));
		btn.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)cnr, 0xFF212121));
		close.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _widget_animate(final View _view) {
		animation.setTarget(_view);
		animation.setPropertyName("scaleX");
		animation.setFloatValues((float)(1.0d), (float)(1.1d));
		animation.setDuration((int)(100));
		animation.setRepeatMode(ValueAnimator.REVERSE);
		animation.setRepeatCount((int)(1));
		animation.start();
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _Toast(final String _text) {
		SketchwareUtil.showMessage(getApplicationContext(), _text);
		_telegramLoaderDialog(false);
	}
	
	
	public void _Update_Dialog(final String _text1, final String _text2, final String _hint) {
		cd = new AlertDialog.Builder(AccountSetupActivity.this).create();
		LayoutInflater cdLI = getLayoutInflater();
		View cdCV = (View) cdLI.inflate(R.layout.update_dialog, null);
		cd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		cd.setView(cdCV);
		final LinearLayout bg = (LinearLayout)
		cdCV.findViewById(R.id.bg);
		final TextView t1 = (TextView)
		cdCV.findViewById(R.id.t1);
		final TextView t2 = (TextView)
		cdCV.findViewById(R.id.t2);
		final EditText edit = (EditText)
		cdCV.findViewById(R.id.edit);
		final TextView btnCl = (TextView)
		cdCV.findViewById(R.id.btnCl);
		final TextView btnUp = (TextView)
		cdCV.findViewById(R.id.btnUp);
		bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFFFFF));
		_GradientDrawable(btnCl, 30, 0, 2, "#E0E0E0", "#000000", true, true, 100);
		_GradientDrawable(btnUp, 30, 0, 2, "#212121", "#000000", true, true, 100);
		edit.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF5F5F5));
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/muli.ttf"), 1);
		btnCl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		btnUp.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		t1.setText(_text1);
		t2.setText(_text2);
		edit.setHint(_hint);
		cd.setCancelable(false);
		cd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		btnUp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!type.equals("")) {
					if (type.equals("username")) {
						if (edit.getText().toString().trim().toLowerCase().equals(myUsername.trim().toLowerCase())) {
							_telegramLoaderDialog(false);
							cd.dismiss();
						} else {
							if (edit.getText().toString().trim().length() > 4) {
								if (!emptyDetails) {
									count = 0;
									for(int _repeat89 = 0; _repeat89 < (int)(usernames.size()); _repeat89++) {
										if (usernames.get((int)count).containsKey("username")) {
											if (usernames.get((int)count).get("username").toString().equals(edit.getText().toString().trim().toLowerCase())) {
												_telegramLoaderDialog(false);
												_Toast("The username \"".concat(edit.getText().toString().trim().toLowerCase().concat("\" has already exist.")));
												break;
											} else {
												if (count == usernames.size()) {
													updateUserMap = new HashMap<>();
													updateUserMap.put("username", edit.getText().toString().toLowerCase().trim());
													sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
													cd.dismiss();
													_Toast("Your username has been added.");
												}
											}
										}
										count++;
									}
								} else {
									updateUserMap = new HashMap<>();
									updateUserMap.put("username", edit.getText().toString().toLowerCase().trim());
									sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
									_Toast("Your username has been added.");
									cd.dismiss();
								}
							} else {
								_Toast("Username is invalid or too short.");
							}
						}
					} else {
						if (type.equals("email")) {
							if (edit.getText().toString().trim().length() > 5) {
								_telegramLoaderDialog(true);
								FirebaseAuth.getInstance().getCurrentUser().updateEmail(edit.getText().toString().trim()).addOnCompleteListener(auth_updateEmailListener);
								cd.dismiss();
							} else {
								_Toast("Invalid email address. Check your email and try again");
							}
						} else {
							if (type.equals("number")) {
								_LengthOfEditText(edit, 11);
								if (edit.getText().toString().trim().length() == 11) {
									updateUserMap = new HashMap<>();
									updateUserMap.put("number", edit.getText().toString().trim());
									sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
									_Toast("Your Mobile Number as being Added.");
									cd.dismiss();
								} else {
									_Toast("Enter your real mobile number.");
								}
								
							} else {
								if (type.equals("name")) {
									updateUserMap = new HashMap<>();
									updateUserMap.put("full_name", edit.getText().toString().trim());
									sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
									_Toast("Please use your real full name.");
									cd.dismiss();
									
								} else {
									if (type.equals("pin")) {
										updateUserMap = new HashMap<>();
										updateUserMap.put("pin", edit.getText().toString().trim());
										sqlUser.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(updateUserMap);
										_Toast("Your Pin as being Added.");
										cd.dismiss();
									}
								}
							}
						}
					}
				} else {
					cd.dismiss();
				}
			}
		});
		btnCl.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				cd.dismiss();
			}
		});
		cd.show();
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		} else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _LengthOfEditText(final TextView _editText, final double _value_character) {
		InputFilter[] gb = _editText.getFilters(); InputFilter[] newFilters = new InputFilter[gb.length + 1]; System.arraycopy(gb, 0, newFilters, 0, gb.length); newFilters[gb.length] = new InputFilter.LengthFilter((int)_value_character); _editText.setFilters(newFilters);
	}
	
	
	public void _Dialog() {
		cd = new AlertDialog.Builder(AccountSetupActivity.this).create();
		LayoutInflater cdLI = getLayoutInflater();
		View cdCV = (View) cdLI.inflate(R.layout.material_dialog, null);
		cd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		cd.setView(cdCV);
		final LinearLayout bg = (LinearLayout)
		cdCV.findViewById(R.id.bg);
		final TextView t1 = (TextView)
		cdCV.findViewById(R.id.t1);
		final TextView t2 = (TextView)
		cdCV.findViewById(R.id.t2);
		final TextView b1 = (TextView)
		cdCV.findViewById(R.id.b1);
		final TextView b2 = (TextView)
		cdCV.findViewById(R.id.b2);
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mulibold.ttf"), 1);
		t2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		b1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/muli.ttf"), 0);
		b2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/muli.ttf"), 0);
		t1.setText("Konfirmasi Keluar");
		t2.setText("Apakah anda yakin ingin keluar dari akun ini?");
		b1.setText("Ya");
		b2.setText("Batalkan");
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				cd.dismiss();
				_telegramLoaderDialog(true);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_telegramLoaderDialog(false);
								FirebaseAuth.getInstance().signOut();
								finishAffinity();
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				cd.dismiss();
			}
		});
		cd.setCancelable(false);
		cd.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}