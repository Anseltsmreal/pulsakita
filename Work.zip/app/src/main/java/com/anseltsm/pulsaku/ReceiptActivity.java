package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Environment;
import android.view.View;
import android.widget.LinearLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ReceiptActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private String receipt_id = "";
	private String AMT = "";
	private String FEE = "";
	private String TOTAL = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String accountbalance = "";
	private String amount = "";
	private HashMap<String, Object> ch = new HashMap<>();
	private String savepath = "";
	private String id1 = "";
	private String id2 = "";
	private String id3 = "";
	private String ig1 = "";
	private String ig2 = "";
	private String gg = "";
	private String dataJSON = "";
	private String t1 = "";
	private String t2 = "";
	private String t3 = "";
	private String t4 = "";
	private String t5 = "";
	private String t6 = "";
	private double price = 0;
	private String nominal = "";
	private double saldo = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear_core;
	private LinearLayout linear11;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView menu;
	private LinearLayout top;
	private LinearLayout linear2;
	private LinearLayout bottom;
	private TextView amt1;
	private TextView mess;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout line;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear17;
	private LinearLayout linear19;
	private LinearLayout linear18;
	private TextView textview4;
	private LinearLayout linear8;
	private LinearLayout line2;
	private LinearLayout linear24;
	private TextView NamIn;
	private LinearLayout line1;
	private TextView name_produk;
	private TextView numbIn;
	private LinearLayout linear25;
	private TextView numb_tujuan;
	private TextView textview5;
	private TextView biller;
	private TextView textview7;
	private TextView trs_ref;
	private TextView textview21;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private TextView textview9;
	private TextView amt2;
	private TextView textview13;
	private TextView fee;
	private LinearLayout linear23;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private TextView textview16;
	private TextView textview19;
	private TextView status;
	private LinearLayout linear22;
	private TextView date_time;
	private TextView textview20;
	private TextView ss_id;
	
	private Intent in = new Intent();
	private TimerTask t;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private SharedPreferences sp;
	private Calendar c = Calendar.getInstance();
	private RequestNetwork refresh;
	private RequestNetwork.RequestListener _refresh_request_listener;
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	private DatabaseReference sqlHistory = _firebase.getReference("history");
	private ChildEventListener _sqlHistory_child_listener;
	private Notification notif;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private RequestNetwork tg;
	private RequestNetwork.RequestListener _tg_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.receipt);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear_core = findViewById(R.id.linear_core);
		linear11 = findViewById(R.id.linear11);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		menu = findViewById(R.id.menu);
		top = findViewById(R.id.top);
		linear2 = findViewById(R.id.linear2);
		bottom = findViewById(R.id.bottom);
		amt1 = findViewById(R.id.amt1);
		mess = findViewById(R.id.mess);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		line = findViewById(R.id.line);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear17 = findViewById(R.id.linear17);
		linear19 = findViewById(R.id.linear19);
		linear18 = findViewById(R.id.linear18);
		textview4 = findViewById(R.id.textview4);
		linear8 = findViewById(R.id.linear8);
		line2 = findViewById(R.id.line2);
		linear24 = findViewById(R.id.linear24);
		NamIn = findViewById(R.id.NamIn);
		line1 = findViewById(R.id.line1);
		name_produk = findViewById(R.id.name_produk);
		numbIn = findViewById(R.id.numbIn);
		linear25 = findViewById(R.id.linear25);
		numb_tujuan = findViewById(R.id.numb_tujuan);
		textview5 = findViewById(R.id.textview5);
		biller = findViewById(R.id.biller);
		textview7 = findViewById(R.id.textview7);
		trs_ref = findViewById(R.id.trs_ref);
		textview21 = findViewById(R.id.textview21);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		textview9 = findViewById(R.id.textview9);
		amt2 = findViewById(R.id.amt2);
		textview13 = findViewById(R.id.textview13);
		fee = findViewById(R.id.fee);
		linear23 = findViewById(R.id.linear23);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		textview16 = findViewById(R.id.textview16);
		textview19 = findViewById(R.id.textview19);
		status = findViewById(R.id.status);
		linear22 = findViewById(R.id.linear22);
		date_time = findViewById(R.id.date_time);
		textview20 = findViewById(R.id.textview20);
		ss_id = findViewById(R.id.ss_id);
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		refresh = new RequestNetwork(this);
		tg = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), MainActivity.class);
				startActivity(in);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				
			}
		});
		
		menu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				{PopupMenu popup = new PopupMenu(ReceiptActivity.this, menu);
							android.view.Menu menu = popup.getMenu();
					
					menu.add("Simpan");
					menu.add("Bagikan");
					menu.add("Bantuan");
					popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
						
										public boolean onMenuItemClick(android.view.MenuItem item) {
												switch (item.getTitle().toString()) {
														
														case "Simpan":
								_telegramLoaderDialog(true);
								t = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												_telegramLoaderDialog(false);
											}
										});
									}
								};
								_timer.schedule(t, (int)(995));
								t = new TimerTask() {
									    @Override
									    public void run() {
										        runOnUiThread(new Runnable() {
											            @Override
											            public void run() {
												                savepath = "storage/emulated/0/Download/".concat("com.theflash.receipt (".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(10), (int)(100)))).concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(50), (int)(500))))).concat(").jpg")));
												                try {
													                    // Ambil referensi ke LinearLayout dengan ID linear_core
													                    LinearLayout linearCore = findViewById(R.id.linear_core);
													
													                    // Bitmap untuk menyimpan screenshot
													                    Bitmap bitmap = Bitmap.createBitmap(linearCore.getWidth(), linearCore.getHeight(), Bitmap.Config.ARGB_8888);
													                    Canvas canvas = new Canvas(bitmap);
													                    linearCore.draw(canvas);  // Gambar hanya layout linear_core ke bitmap
													
													                    // Tentukan lokasi penyimpanan file
													                    File imageFile = new File(savepath);
													                    FileOutputStream outputStream = new FileOutputStream(imageFile);
													                    int quality = 100; // kualitas gambar
													                    bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
													                    outputStream.flush();
													                    outputStream.close();
													                } catch (Exception e) {
													                    e.printStackTrace(); // Log error jika ada
													                }
												            }
											        });
										    }
								};
								_timer.schedule(t, 1000);  // Atur timer untuk delay 1 detik
								
								t = new TimerTask() {
									    @Override
									    public void run() {
										        runOnUiThread(new Runnable() {
											            @Override
											            public void run() {
												                // Menampilkan pesan bahwa gambar sudah disimpan
												                SketchwareUtil.showMessage(getApplicationContext(), "Tersimpan Di ".concat(savepath));
												            }
											        });
										    }
								};
								_timer.schedule(t, 2500);  // Atur timer untuk delay 2,5 detik setelah penyimpanan
								return true;
								case "Bagikan":
								 
								return true;
								case "Bantuan":
								in.setClass(getApplicationContext(), SupportActivity.class);
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
								return true;
								
														default: return false;
												}
										}
								});
					
					
					popup.show();}
			}
		});
		
		_refresh_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				dataJSON = _response;
				try{
					JSONObject jsonObject = new JSONObject(dataJSON);
					t1 = jsonObject.getString("status");
					t2 = jsonObject.getString("ref_id");
					t3 = jsonObject.getString("trx_id");
					t4 = jsonObject.getString("produk");
					t5 = jsonObject.getString("price");
					t6 = jsonObject.getString("sn");
				} catch (Exception e) {}
				map = new HashMap<>();
				map.put("status", t1);
				map.put("refid", t2);
				map.put("trxid", t3);
				map.put("produk", name_produk.getText().toString());
				map.put("tanggal", sp.getString("tanggal", ""));
				map.put("sn", t6);
				map.put("jam", sp.getString("jam", ""));
				map.put("price", amt2.getText().toString().replace("Rp", ""));
				map.put("tujuan", numb_tujuan.getText().toString());
				map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				//push data ke transaksi, transaksi pending, 
				sqlHistory.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat(sp.getString("jam", ""))).updateChildren(map);
				map.clear();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("member_id")) {
						sp.edit().putString("member_id", _childValue.get("member_id").toString()).commit();
					}
					if (_childValue.containsKey("secret_key")) {
						sp.edit().putString("secret_key", _childValue.get("secret_key").toString()).commit();
					}
					if (_childValue.containsKey("signature")) {
						sp.edit().putString("signature", _childValue.get("signature").toString()).commit();
					}
				} else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("member_id")) {
						sp.edit().putString("member_id", _childValue.get("member_id").toString()).commit();
					}
					if (_childValue.containsKey("secret_key")) {
						sp.edit().putString("secret_key", _childValue.get("secret_key").toString()).commit();
					}
					if (_childValue.containsKey("signature")) {
						sp.edit().putString("signature", _childValue.get("signature").toString()).commit();
					}
				} else {
					
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		_sqlHistory_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(sp.getString("uid", "").concat(sp.getString("jam", "")))) {
					if (_childValue.containsKey("amount")) {
						nominal = new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("amount").toString()));
						amt1.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("amount").toString()))));
						amt2.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("amount").toString()))));
					}
					if (_childValue.containsKey("produk")) {
						name_produk.setText(_childValue.get("produk").toString());
					}
					if (_childValue.containsKey("refid")) {
						trs_ref.setText(_childValue.get("refid").toString());
					}
					if (_childValue.containsKey("sn")) {
						textview21.setText(_childValue.get("sn").toString());
					}
					if (_childValue.containsKey("status")) {
						status.setText(_childValue.get("status").toString());
						if (status.getText().toString().equals("gagal")) {
							mess.setTextColor(0xFFF44336);
							status.setTextColor(0xFFF44336);
							mess.setText("Transaksi ".concat(status.getText().toString()));
							textview21.setVisibility(View.GONE);
						} else {
							if (status.getText().toString().equals("pending")) {
								textview21.setVisibility(View.GONE);
								mess.setTextColor(0xFF2196F3);
								status.setTextColor(0xFF2196F3);
								mess.setText("Transaksi ".concat(status.getText().toString()));
							} else {
								if (status.getText().toString().equals("sukses")) {
									textview21.setVisibility(View.VISIBLE);
									status.setTextColor(0xFF4CAF50);
									mess.setText("Transaksi ".concat(status.getText().toString()));
									mess.setTextColor(0xFF4CAF50);
								}
							}
						}
					}
					if (_childValue.containsKey("tgl")) {
						date_time.setText(_childValue.get("tgl").toString());
					}
					if (_childValue.containsKey("trxid")) {
						ss_id.setText(_childValue.get("trxid").toString());
					}
					if (_childValue.containsKey("tujuan")) {
						numb_tujuan.setText(_childValue.get("tujuan").toString());
					}
					if (_childValue.containsKey("tanggal")) {
						sp.edit().putString("tanggal", _childValue.get("tanggal").toString()).commit();
					}
					if (_childValue.containsKey("jam")) {
						sp.edit().putString("jam", _childValue.get("jam").toString()).commit();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(sp.getString("uid", "").concat(sp.getString("jam", "")))) {
					if (_childValue.containsKey("amount")) {
						nominal = new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("amount").toString()));
						amt1.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("amount").toString()))));
						amt2.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("amount").toString()))));
					}
					if (_childValue.containsKey("produk")) {
						name_produk.setText(_childValue.get("produk").toString());
					}
					if (_childValue.containsKey("refid")) {
						trs_ref.setText(_childValue.get("refid").toString());
					}
					if (_childValue.containsKey("sn")) {
						textview21.setText(_childValue.get("sn").toString());
					}
					if (_childValue.containsKey("status")) {
						status.setText(_childValue.get("status").toString());
						if (status.getText().toString().equals("gagal")) {
							mess.setTextColor(0xFFF44336);
							status.setTextColor(0xFFF44336);
							mess.setText("Transaksi ".concat(status.getText().toString()));
							textview21.setVisibility(View.GONE);
						} else {
							if (status.getText().toString().equals("pending")) {
								textview21.setVisibility(View.GONE);
								mess.setTextColor(0xFF2196F3);
								status.setTextColor(0xFF2196F3);
								mess.setText("Transaksi ".concat(status.getText().toString()));
							} else {
								if (status.getText().toString().equals("sukses")) {
									textview21.setVisibility(View.VISIBLE);
									status.setTextColor(0xFF4CAF50);
									mess.setText("Transaksi ".concat(status.getText().toString()));
									mess.setTextColor(0xFF4CAF50);
								}
							}
						}
					}
					if (_childValue.containsKey("tgl")) {
						date_time.setText(_childValue.get("tgl").toString());
					}
					if (_childValue.containsKey("trxid")) {
						ss_id.setText(_childValue.get("trxid").toString());
					}
					if (_childValue.containsKey("tujuan")) {
						numb_tujuan.setText(_childValue.get("tujuan").toString());
					}
					if (_childValue.containsKey("tanggal")) {
						sp.edit().putString("tanggal", _childValue.get("tanggal").toString()).commit();
					}
					if (_childValue.containsKey("jam")) {
						sp.edit().putString("jam", _childValue.get("jam").toString()).commit();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlHistory.addChildEventListener(_sqlHistory_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					saldo = Double.parseDouble(_childValue.get("saldo").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					saldo = Double.parseDouble(_childValue.get("saldo").toString());
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_tg_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		_fullScreencall();
		_changeActivityFont("light");
		amt1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		mess.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		ss_id.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/receipt.ttf"), 0);
		trs_ref.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/receipt.ttf"), 0);
		
		//getWindow().setStatusBarColor(Color.parseColor("#1976d2"));
		//getWindow().setNavigationBarColor(Color.parseColor("#000000"));
		//getActionBar().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor("#2196f3")));
		getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor("#EEEEEE")));
		mess.setTextIsSelectable(true);
		trs_ref.setTextIsSelectable(true);
		ss_id.setTextIsSelectable(true);
		textview21.setTextIsSelectable(true);
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						_telegramLoaderDialog(true);
						if (status.getText().toString().equals("gagal") || status.getText().toString().equals("sukses")) {
							_telegramLoaderDialog(false);
							t.cancel();
							_set_Notification(sp.getString("info", ""), "No Transaksi ".concat(trs_ref.getText().toString().concat("   ".concat(name_produk.getText().toString().concat("  ".concat(status.getText().toString().concat(" Di Proses")))))));
						} else {
							id1 = sp.getString("member_id", "");
							id2 = sp.getString("secret_key", "");
							id3 = trs_ref.getText().toString();
							ig1 = ":";
							ig2 = ":";
							// Dapatkan referensi ke komponen EditText dan TextView
							//TextView mcc = findViewById(R.id.mc); // Gantilah dengan ID komponen EditText Anda
							//TextView scc = findViewById(R.id.sc); // Gantilah dengan ID komponen TextView Anda
							//TextView txt = findViewById(R.id.hs);
							
							String inputText = id1.concat(ig1.concat(id2.concat(ig2.concat(id3))));
							
							try {
								    // Buat objek MessageDigest dengan algoritma MD5
								    MessageDigest md = MessageDigest.getInstance("MD5");
								
								    // Update nilai hash dengan byte dari string
								    md.update(inputText.getBytes());
								
								    // Dapatkan nilai hash dalam bentuk byte
								    byte[] digest = md.digest();
								
								    // Ubah byte menjadi nilai heksadesimal
								    BigInteger bigInt = new BigInteger(1, digest);
								    String md5Value = bigInt.toString(16);
								
								    // Pastikan panjangnya 32 karakter
								    while (md5Value.length() < 32) {
									        md5Value = "0" + md5Value;
									    }
								
								    // Tampilkan nilai MD5 di 
								gg = md5Value;
							} catch (NoSuchAlgorithmException e) {
								    e.printStackTrace();
							}
							refresh.startRequestNetwork(RequestNetworkController.GET, "https://api.tokovoucher.net/v1/transaksi/status?ref_id=".concat(trs_ref.getText().toString().concat("&member_code=".concat(sp.getString("member_id", "").concat("&signature=".concat(gg))))), "", _refresh_request_listener);
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(5000), (int)(5000));
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _RECEIPT_DETAILS() {
		if (getIntent().hasExtra("total-amt")) {
			amt1.setText("Rp".concat(getIntent().getStringExtra("total-amt")));
		}
		if (getIntent().hasExtra("fee")) {
			fee.setText("Rp".concat(getIntent().getStringExtra("fee")));
		}
		if (getIntent().hasExtra("amt")) {
			amt2.setText("Rp".concat(getIntent().getStringExtra("amt")));
		}
		if (getIntent().hasExtra("biller")) {
			biller.setText(getIntent().getStringExtra("biller"));
		}
		if (getIntent().hasExtra("date-time")) {
			date_time.setText(getIntent().getStringExtra("date-time"));
		}
		if (getIntent().hasExtra("mess")) {
			mess.setText(getIntent().getStringExtra("mess"));
		}
		if (getIntent().hasExtra("number")) {
			numb_tujuan.setText(getIntent().getStringExtra("number"));
		}
		if (getIntent().hasExtra("name")) {
			name_produk.setText(getIntent().getStringExtra("name"));
		}
		if (getIntent().hasExtra("type")) {
			status.setText(getIntent().getStringExtra("type"));
		}
		if (getIntent().hasExtra("ref")) {
			trs_ref.setText(getIntent().getStringExtra("ref"));
		}
		if (getIntent().hasExtra("s_id")) {
			ss_id.setText(getIntent().getStringExtra("s_id"));
		} else {
			ss_id.setText("null");
		}
	}
	
	
	public void _stateColor(final int _statusColor, final int _navigationColor) {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(_statusColor);
		getWindow().setNavigationBarColor(_navigationColor);
	}
	
	
	public void _fullScreencall() {
		if(Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19)
		{
			// lower api
			View v = this.getWindow().getDecorView();
			 v.setSystemUiVisibility(View.GONE);
			 }
		else if(Build.VERSION.SDK_INT >= 19)
		{
			//for new api versions.
			View decorView = getWindow().getDecorView();
			int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			 decorView.setSystemUiVisibility(uiOptions);
		}
	}
	
	
	public void _set_Notification(final String _Title, final String _Message) {
		final Context context = getApplicationContext();
		
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(this, ReceiptActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
		
		// Tambahkan FLAG_IMMUTABLE
		PendingIntent pendingIntent = PendingIntent.getActivity(
		    this, 
		    0, 
		    intent, 
		    PendingIntent.FLAG_IMMUTABLE
		);
		
		int notificationId = 1;
		String channelId = "channel-01";
		String channelName = "Channel Name";
		int importance = NotificationManager.IMPORTANCE_HIGH;
		
		// Buat NotificationChannel untuk API 26+
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			    NotificationChannel mChannel = new NotificationChannel(
			            channelId, 
			            channelName, 
			            importance
			    );
			    notificationManager.createNotificationChannel(mChannel);
		}
		
		// Builder untuk notifikasi
		androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
		        .setSmallIcon(R.drawable.receipt_in) // Ganti dengan icon yang benar
		        .setContentTitle(_Title)
		        .setContentText(_Message)
		        .setAutoCancel(true) // Atur apakah notifikasi hilang setelah diklik
		        .setOngoing(false) // Jika true, ini akan menjadi notifikasi permanen
		        .setContentIntent(pendingIntent);
		
		// Kirim notifikasi
		notificationManager.notify(notificationId, mBuilder.build());
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}