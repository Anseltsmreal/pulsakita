package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ChooseWalletActivity extends AppCompatActivity {
	
	private LinearLayout linear8;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textH;
	private LinearLayout linear9;
	private LinearLayout linear1;
	private LinearLayout linear_dana;
	private LinearLayout line1;
	private LinearLayout linear_ovo;
	private LinearLayout line;
	private LinearLayout linear_linkaja;
	private LinearLayout linear19;
	private LinearLayout linear_gopay;
	private LinearLayout linear24;
	private LinearLayout linear_kaspro;
	private LinearLayout linear39;
	private LinearLayout linear_shopeepay;
	private LinearLayout linear28;
	private LinearLayout linear_isaku;
	private LinearLayout linear32;
	private LinearLayout linear_grab;
	private LinearLayout linear5;
	private ImageView imageview2;
	private LinearLayout linear10;
	private TextView textview8;
	private ImageView imageview11;
	private TextView textH1;
	private LinearLayout linear14;
	private ImageView imageview5;
	private LinearLayout linear15;
	private TextView textview9;
	private ImageView imageview12;
	private TextView textH2;
	private LinearLayout linear17;
	private ImageView imageview6;
	private LinearLayout linear18;
	private TextView textview10;
	private ImageView imageview13;
	private TextView textH3;
	private LinearLayout linear22;
	private ImageView imageview7;
	private LinearLayout linear23;
	private TextView textview11;
	private ImageView imageview14;
	private TextView textH4;
	private LinearLayout linear37;
	private ImageView imageview18;
	private LinearLayout linear38;
	private TextView textview15;
	private ImageView imageview19;
	private TextView textview16;
	private LinearLayout linear26;
	private ImageView imageview8;
	private LinearLayout linear27;
	private TextView textview12;
	private ImageView imageview15;
	private TextView textH5;
	private LinearLayout linear30;
	private ImageView imageview9;
	private LinearLayout linear31;
	private TextView textview13;
	private ImageView imageview16;
	private TextView textH6;
	private LinearLayout linear34;
	private ImageView imageview10;
	private LinearLayout linear35;
	private TextView textview14;
	private ImageView imageview17;
	private TextView textH7;
	
	private Intent in = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.choose_wallet);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear8 = findViewById(R.id.linear8);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		textH = findViewById(R.id.textH);
		linear9 = findViewById(R.id.linear9);
		linear1 = findViewById(R.id.linear1);
		linear_dana = findViewById(R.id.linear_dana);
		line1 = findViewById(R.id.line1);
		linear_ovo = findViewById(R.id.linear_ovo);
		line = findViewById(R.id.line);
		linear_linkaja = findViewById(R.id.linear_linkaja);
		linear19 = findViewById(R.id.linear19);
		linear_gopay = findViewById(R.id.linear_gopay);
		linear24 = findViewById(R.id.linear24);
		linear_kaspro = findViewById(R.id.linear_kaspro);
		linear39 = findViewById(R.id.linear39);
		linear_shopeepay = findViewById(R.id.linear_shopeepay);
		linear28 = findViewById(R.id.linear28);
		linear_isaku = findViewById(R.id.linear_isaku);
		linear32 = findViewById(R.id.linear32);
		linear_grab = findViewById(R.id.linear_grab);
		linear5 = findViewById(R.id.linear5);
		imageview2 = findViewById(R.id.imageview2);
		linear10 = findViewById(R.id.linear10);
		textview8 = findViewById(R.id.textview8);
		imageview11 = findViewById(R.id.imageview11);
		textH1 = findViewById(R.id.textH1);
		linear14 = findViewById(R.id.linear14);
		imageview5 = findViewById(R.id.imageview5);
		linear15 = findViewById(R.id.linear15);
		textview9 = findViewById(R.id.textview9);
		imageview12 = findViewById(R.id.imageview12);
		textH2 = findViewById(R.id.textH2);
		linear17 = findViewById(R.id.linear17);
		imageview6 = findViewById(R.id.imageview6);
		linear18 = findViewById(R.id.linear18);
		textview10 = findViewById(R.id.textview10);
		imageview13 = findViewById(R.id.imageview13);
		textH3 = findViewById(R.id.textH3);
		linear22 = findViewById(R.id.linear22);
		imageview7 = findViewById(R.id.imageview7);
		linear23 = findViewById(R.id.linear23);
		textview11 = findViewById(R.id.textview11);
		imageview14 = findViewById(R.id.imageview14);
		textH4 = findViewById(R.id.textH4);
		linear37 = findViewById(R.id.linear37);
		imageview18 = findViewById(R.id.imageview18);
		linear38 = findViewById(R.id.linear38);
		textview15 = findViewById(R.id.textview15);
		imageview19 = findViewById(R.id.imageview19);
		textview16 = findViewById(R.id.textview16);
		linear26 = findViewById(R.id.linear26);
		imageview8 = findViewById(R.id.imageview8);
		linear27 = findViewById(R.id.linear27);
		textview12 = findViewById(R.id.textview12);
		imageview15 = findViewById(R.id.imageview15);
		textH5 = findViewById(R.id.textH5);
		linear30 = findViewById(R.id.linear30);
		imageview9 = findViewById(R.id.imageview9);
		linear31 = findViewById(R.id.linear31);
		textview13 = findViewById(R.id.textview13);
		imageview16 = findViewById(R.id.imageview16);
		textH6 = findViewById(R.id.textH6);
		linear34 = findViewById(R.id.linear34);
		imageview10 = findViewById(R.id.imageview10);
		linear35 = findViewById(R.id.linear35);
		textview14 = findViewById(R.id.textview14);
		imageview17 = findViewById(R.id.imageview17);
		textH7 = findViewById(R.id.textH7);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear_dana.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_dana.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "Dana");
				startActivity(in);
			}
		});
		
		linear_ovo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_ovo.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "Ovo");
				startActivity(in);
			}
		});
		
		linear_linkaja.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_linkaja.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "LinkAja");
				startActivity(in);
			}
		});
		
		linear_gopay.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_gopay.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "Gopay");
				startActivity(in);
			}
		});
		
		linear_kaspro.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_kaspro.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "Kaspro");
				startActivity(in);
			}
		});
		
		linear_shopeepay.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_shopeepay.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "ShopeePay");
				startActivity(in);
			}
		});
		
		linear_isaku.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_isaku.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "iSaku");
				startActivity(in);
			}
		});
		
		linear_grab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_grab.startAnimation(fade_in);
				in.setClass(getApplicationContext(), RechargepyActivity.class);
				in.putExtra("type", "Grab");
				startActivity(in);
			}
		});
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		_autoTransitionScroll(linear1);
		_removeScollBar(vscroll1);
		linear8.setElevation((float)4);
		textH.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textH7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}