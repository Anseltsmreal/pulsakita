package com.anseltsm.pulsaku;

import com.anseltsm.pulsaku.SplashActivity;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private FloatingActionButton _fab;
	private String user_id = "";
	private String fontName = "";
	private String typeace = "";
	private String seems = "";
	private String balance = "";
	private String AM = "";
	private String PM = "";
	private String EVE = "";
	private String NEW_DAY = "";
	private double counter = 0;
	private HashMap<String, Object> mj = new HashMap<>();
	private HashMap<String, Object> checkFreeze = new HashMap<>();
	private String token = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listSlide = new ArrayList<>();
	private ArrayList<String> broadKeys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> broadMessageList = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private ViewPager viewpager2;
	private ViewPager viewpager4;
	private ViewPager viewpager3;
	private ViewPager viewpager1;
	private LinearLayout linearNAV;
	private LinearLayout linearHOME;
	private LinearLayout linearHISTORY;
	private LinearLayout linearINBOX;
	private LinearLayout linearSETTINGS;
	private ImageView imageHOME;
	private TextView textHOME;
	private ImageView imageHISTORY;
	private TextView textSERVICE;
	private ImageView imageINBOX;
	private TextView textREWARD;
	private ImageView imageSETTING;
	private TextView textSETTIN;
	
	private Intent in = new Intent();
	private TimerTask t;
	private FragFragmentAdapter frag;
	private Frag2FragmentAdapter frag2;
	private Frag3FragmentAdapter frag3;
	private Frag4FragmentAdapter frag4;
	private DatabaseReference CheckFreeze = _firebase.getReference("users");
	private ChildEventListener _CheckFreeze_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	
	private OnCompleteListener cloudMessaging_onCompleteListener;
	private RequestNetwork requestNetwork;
	private RequestNetwork.RequestListener _requestNetwork_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		linear2 = findViewById(R.id.linear2);
		viewpager2 = findViewById(R.id.viewpager2);
		viewpager4 = findViewById(R.id.viewpager4);
		viewpager3 = findViewById(R.id.viewpager3);
		viewpager1 = findViewById(R.id.viewpager1);
		linearNAV = findViewById(R.id.linearNAV);
		linearHOME = findViewById(R.id.linearHOME);
		linearHISTORY = findViewById(R.id.linearHISTORY);
		linearINBOX = findViewById(R.id.linearINBOX);
		linearSETTINGS = findViewById(R.id.linearSETTINGS);
		imageHOME = findViewById(R.id.imageHOME);
		textHOME = findViewById(R.id.textHOME);
		imageHISTORY = findViewById(R.id.imageHISTORY);
		textSERVICE = findViewById(R.id.textSERVICE);
		imageINBOX = findViewById(R.id.imageINBOX);
		textREWARD = findViewById(R.id.textREWARD);
		imageSETTING = findViewById(R.id.imageSETTING);
		textSETTIN = findViewById(R.id.textSETTIN);
		frag = new FragFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		frag2 = new Frag2FragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		frag3 = new Frag3FragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		frag4 = new Frag4FragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		auth = FirebaseAuth.getInstance();
		requestNetwork = new RequestNetwork(this);
		
		linearHOME.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textHOME.setTextColor(0xFF000000);
				textSERVICE.setTextColor(0xFF9E9E9E);
				textREWARD.setTextColor(0xFF9E9E9E);
				textSETTIN.setTextColor(0xFF9E9E9E);
				imageHOME.setImageResource(R.drawable.icon_home_round_black);
				imageHISTORY.setImageResource(R.drawable.icon_history_round);
				imageINBOX.setImageResource(R.drawable.icon_notifications_round);
				imageSETTING.setImageResource(R.drawable.icon_settings_round);
				viewpager1.setCurrentItem((int)0);
				viewpager1.setVisibility(View.VISIBLE);
				viewpager2.setVisibility(View.GONE);
				viewpager3.setVisibility(View.GONE);
				viewpager4.setVisibility(View.GONE);
			}
		});
		
		linearHISTORY.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textHOME.setTextColor(0xFF9E9E9E);
				textSERVICE.setTextColor(0xFF000000);
				textREWARD.setTextColor(0xFF9E9E9E);
				textSETTIN.setTextColor(0xFF9E9E9E);
				imageHOME.setImageResource(R.drawable.icon_home_round);
				imageHISTORY.setImageResource(R.drawable.icon_history_round_black);
				imageINBOX.setImageResource(R.drawable.icon_notifications_round);
				imageSETTING.setImageResource(R.drawable.icon_settings_round);
				viewpager2.setCurrentItem((int)0);
				viewpager2.setVisibility(View.VISIBLE);
				viewpager1.setVisibility(View.GONE);
				viewpager3.setVisibility(View.GONE);
				viewpager4.setVisibility(View.GONE);
			}
		});
		
		linearINBOX.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textHOME.setTextColor(0xFF9E9E9E);
				textSERVICE.setTextColor(0xFF9E9E9E);
				textREWARD.setTextColor(0xFF000000);
				textSETTIN.setTextColor(0xFF9E9E9E);
				imageHOME.setImageResource(R.drawable.icon_home_round);
				imageHISTORY.setImageResource(R.drawable.icon_history_round);
				imageINBOX.setImageResource(R.drawable.icon_notifications_round_black);
				imageSETTING.setImageResource(R.drawable.icon_settings_round);
				viewpager3.setCurrentItem((int)0);
				viewpager3.setVisibility(View.VISIBLE);
				viewpager1.setVisibility(View.GONE);
				viewpager2.setVisibility(View.GONE);
				viewpager4.setVisibility(View.GONE);
			}
		});
		
		linearSETTINGS.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textHOME.setTextColor(0xFF9E9E9E);
				textSERVICE.setTextColor(0xFF9E9E9E);
				textREWARD.setTextColor(0xFF9E9E9E);
				textSETTIN.setTextColor(0xFF000000);
				imageHOME.setImageResource(R.drawable.icon_home_round);
				imageHISTORY.setImageResource(R.drawable.icon_history_round);
				imageINBOX.setImageResource(R.drawable.icon_notifications_round);
				imageSETTING.setImageResource(R.drawable.icon_settings_round_black);
				viewpager4.setCurrentItem((int)0);
				viewpager4.setVisibility(View.VISIBLE);
				viewpager1.setVisibility(View.GONE);
				viewpager2.setVisibility(View.GONE);
				viewpager3.setVisibility(View.GONE);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), ScannerActivity.class);
				startActivity(in);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				
			}
		});
		
		_CheckFreeze_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("freeze").toString().equals("true")) {
						_openBlockAlert();
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("freeze").toString().equals("true")) {
						_openBlockAlert();
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		CheckFreeze.addChildEventListener(_CheckFreeze_child_listener);
		
		cloudMessaging_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_requestNetwork_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_ColorShadow_SDK28(_fab, "#424242", 20);
		_ColorShadow_SDK28(linearNAV, "#424242", 20);
		textHOME.setTextColor(0xFF212121);
		textSERVICE.setTextColor(0xFF9E9E9E);
		textREWARD.setTextColor(0xFF9E9E9E);
		textSETTIN.setTextColor(0xFF9E9E9E);
		viewpager1.setCurrentItem((int)0);
		frag.setTabCount(1);
		viewpager1.setAdapter(frag);
		viewpager1.setOffscreenPageLimit((int)1);
		((PagerAdapter)viewpager1.getAdapter()).notifyDataSetChanged();
		viewpager2.setCurrentItem((int)0);
		frag2.setTabCount(1);
		viewpager2.setAdapter(frag2);
		viewpager2.setOffscreenPageLimit((int)1);
		((PagerAdapter)viewpager2.getAdapter()).notifyDataSetChanged();
		viewpager3.setCurrentItem((int)0);
		frag3.setTabCount(1);
		viewpager3.setAdapter(frag3);
		viewpager3.setOffscreenPageLimit((int)1);
		((PagerAdapter)viewpager3.getAdapter()).notifyDataSetChanged();
		viewpager4.setCurrentItem((int)0);
		frag4.setTabCount(1);
		viewpager4.setAdapter(frag4);
		viewpager4.setOffscreenPageLimit((int)1);
		((PagerAdapter)viewpager4.getAdapter()).notifyDataSetChanged();
		_changeActivityFont("muli");
		viewpager2.setVisibility(View.GONE);
		viewpager3.setVisibility(View.GONE);
		viewpager4.setVisibility(View.GONE);
		_stateColor(0xFFFFFFFF, 0xFFF6F6F8);
		_subscribeFCMTopic("all");
		if (Build.VERSION.SDK_INT >= 23) {
			//SDK > 23
			if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_DENIED) {
				//Denied
				requestPermissions(new String[] {android.Manifest.permission.POST_NOTIFICATIONS}, 1111);
			}else {
				//Granted
				 
			}
		}else {
			//SDK < 23
			 
		}
	}
	
	public class FragFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public FragFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new HomeFragmentActivity();
			}
			return null;
		}
	}
	
	public class Frag2FragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public Frag2FragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new RiwayatFragmentActivity();
			}
			return null;
		}
	}
	
	public class Frag3FragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public Frag3FragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new InboxFragmentActivity();
			}
			return null;
		}
	}
	
	public class Frag4FragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public Frag4FragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new SettingsFragmentActivity();
			}
			return null;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (viewpager1.getCurrentItem() == 0) {
			finishAffinity();
		} else {
			viewpager1.setCurrentItem((int)0);
		}
	}
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _ColorShadow_SDK28(final View _view, final String _color, final double _number) {
		_view.setElevation((float)_number);
		
		_view.setOutlineAmbientShadowColor(Color.parseColor(_color));
		_view.setOutlineSpotShadowColor(Color.parseColor(_color));
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _BlackIcons_StatusBar() {
		{getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
	}
	
	
	public void _advancedCorners(final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	public void _viewGraphics(final View _view, final int _onFocus, final int _onRipple, final double _radius, final double _stroke, final int _strokeColor) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(_onFocus);
		GG.setCornerRadius((float)_radius);
		GG.setStroke((int) _stroke, _strokeColor);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ _onRipple}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _openBlockAlert() {
		{
			final AlertDialog NewCustomDialog = new AlertDialog.Builder(MainActivity.this).create();
			LayoutInflater NewCustomDialogLI = getLayoutInflater();
			View NewCustomDialogCV = (View) NewCustomDialogLI.inflate(R.layout.freeze_dialog, null);
			NewCustomDialog.setView(NewCustomDialogCV);
			NewCustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
			
			final LinearLayout dialog_body = (LinearLayout) NewCustomDialogCV.findViewById(R.id.dialog_body);
			final TextView create_request_button = (TextView) NewCustomDialogCV.findViewById(R.id.create_request_button);
			final TextView close_app_button = (TextView) NewCustomDialogCV.findViewById(R.id.close_app_button);
			final LinearLayout linear_text = (LinearLayout) NewCustomDialogCV.findViewById(R.id.linear_text);
			final ImageView imageview1 = (ImageView) NewCustomDialogCV.findViewById(R.id.imageview1);
			linear_text.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFF5F5F5));
			_viewGraphics(create_request_button, 0xFF000000, 0xFF616161, 300, 0, Color.TRANSPARENT);
			_viewGraphics(close_app_button, 0xFFF5F5F5, 0xFFE0E0E0, 300, 0, Color.TRANSPARENT);
			create_request_button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					NewCustomDialog.dismiss();
					finishAffinity();
				}
			});
			close_app_button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					NewCustomDialog.dismiss();
					finishAffinity();
				}
			});
			NewCustomDialog.setCancelable(false);
			NewCustomDialog.show();
		}
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		} else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _stateColor(final int _statusColor, final int _navigationColor) {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(_statusColor);
		getWindow().setNavigationBarColor(_navigationColor);
	}
	
	
	public void _getDeviceFCMToken() {
		FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(@NonNull Task<InstanceIdResult> task) {
				if (task.isSuccessful()) {
					token = task.getResult().getToken();
					
					
					
					// here my_token is textview
					
					
					//SketchwareUtil.showMessage(getApplicationContext(), "Fcm Token generated !");
					
					
				} else {
					
					
					//SketchwareUtil.showMessage(getApplicationContext(), "Unknown Error Occurred");
				}}});
	}
	
	
	public void _subscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().subscribeToTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						//SketchwareUtil.showMessage(getApplicationContext(), "Subscribed Successfully");
					} else {
						//SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Subscribe");
					}}});
		} else {
			//SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _unsubscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().unsubscribeFromTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						//SketchwareUtil.showMessage(getApplicationContext(), "Unsubscribed Successfully");
					} else {
						//SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Unsubscribe");
					}}});
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _sendFCMNotification(final String _key, final String _title, final String _content, final String _imageUrl, final String _topic, final String _token) {
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			HashMap<String, Object> requestHeader = new HashMap<>();
			
			HashMap<String, Object> notificationBody = new HashMap<>();
			
			HashMap<String, Object> requestBody = new HashMap<>();
			requestHeader = new HashMap<>();
			requestHeader.put("Authorization", "key=".concat(_key));
			requestHeader.put("Content-Type", "application/json");
			
			notificationBody = new HashMap<>();
			notificationBody.put("title", _title);
			notificationBody.put("body", _content);
			notificationBody.put("image", _imageUrl);
			
			requestBody = new HashMap<>();
			if (!_topic.equals("null")) {
				requestBody.put("to", "/topics/".concat(_topic));
			} else {
				requestBody.put("to", _token);
			}
			requestBody.put("notification", notificationBody);
			requestNetwork.setHeaders(requestHeader);
			requestNetwork.setParams(requestBody, RequestNetworkController.REQUEST_BODY);
			requestNetwork.startRequestNetwork(RequestNetworkController.POST, "https://fcm.googleapis.com/fcm/send", "", _requestNetwork_request_listener);
		} else {
			//SketchwareUtil.showMessage(getApplicationContext(), "No Internet Connection");
		}
	}
	
	
	public void _glideFromURL(final String _url, final ImageView _imageview) {
		Glide.with(getApplicationContext())
		.load(_url)
		.diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
		.error(R.drawable.noblepay_black_logo)
		.into(_imageview);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}