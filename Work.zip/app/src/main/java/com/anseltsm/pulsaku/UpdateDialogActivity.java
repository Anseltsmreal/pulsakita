package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class UpdateDialogActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double count = 0;
	private String fontName = "";
	private String typeace = "";
	private String usern = "";
	private String name = "";
	private String pin = "";
	private String number = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> usernames = new ArrayList<>();
	
	private LinearLayout linear3;
	private LinearLayout bg;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear4;
	private TextView t1;
	private TextView t2;
	private EditText edit;
	private LinearLayout errView;
	private TextView btnUp;
	private ImageView errImg;
	private TextView errTxt;
	
	private DatabaseReference sqlUsers = _firebase.getReference("users");
	private ChildEventListener _sqlUsers_child_listener;
	private FirebaseAuth Oauth;
	private OnCompleteListener<AuthResult> _Oauth_create_user_listener;
	private OnCompleteListener<AuthResult> _Oauth_sign_in_listener;
	private OnCompleteListener<Void> _Oauth_reset_password_listener;
	private OnCompleteListener<Void> Oauth_updateEmailListener;
	private OnCompleteListener<Void> Oauth_updatePasswordListener;
	private OnCompleteListener<Void> Oauth_emailVerificationSentListener;
	private OnCompleteListener<Void> Oauth_deleteUserListener;
	private OnCompleteListener<Void> Oauth_updateProfileListener;
	private OnCompleteListener<AuthResult> Oauth_phoneAuthListener;
	private OnCompleteListener<AuthResult> Oauth_googleSignInListener;
	
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.update_dialog);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		bg = findViewById(R.id.bg);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		linear4 = findViewById(R.id.linear4);
		t1 = findViewById(R.id.t1);
		t2 = findViewById(R.id.t2);
		edit = findViewById(R.id.edit);
		errView = findViewById(R.id.errView);
		btnUp = findViewById(R.id.btnUp);
		errImg = findViewById(R.id.errImg);
		errTxt = findViewById(R.id.errTxt);
		Oauth = FirebaseAuth.getInstance();
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		edit.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				try{
					_autoTransitionScroll(bg);
					if (_charSeq.trim().length() > 3) {
						_btnSup(true);
						errView.setVisibility(View.GONE);
						if (!getIntent().getStringExtra("type").equals("")) {
							if (getIntent().getStringExtra("type").equals("username")) {
								if (edit.getText().toString().trim().toLowerCase().equals(usern.trim().toLowerCase())) {
									
								} else {
									if (_charSeq.trim().length() > 4) {
										count = 0;
										for(int _repeat41 = 0; _repeat41 < (int)(usernames.size()); _repeat41++) {
											if (usernames.get((int)count).containsKey("-username")) {
												if (usernames.get((int)count).get("-username").toString().equals(_charSeq.trim().toLowerCase())) {
													errView.setVisibility(View.VISIBLE);
													errTxt.setText("The username already exist");
													break;
												} else {
													if (count == usernames.size()) {
														break;
													}
												}
											}
											count++;
										}
									} else {
										_Toast("Username is invalid or too short.");
									}
								}
							} else {
								
							}
						} else {
							
						}
					} else {
						_btnSup(false);
					}
				}catch(Exception e){
					_Toast(e.toString());
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		btnUp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!getIntent().getStringExtra("type").equals("")) {
					if (getIntent().getStringExtra("type").equals("username")) {
						map = new HashMap<>();
						map.put("username", edit.getText().toString().toLowerCase().trim());
						sqlUsers.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					}
					if (getIntent().getStringExtra("type").equals("name")) {
						map = new HashMap<>();
						map.put("full_name", edit.getText().toString().trim());
						sqlUsers.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					}
					if (getIntent().getStringExtra("type").equals("email")) {
						FirebaseAuth.getInstance().getCurrentUser().updateEmail(edit.getText().toString().trim()).addOnCompleteListener(Oauth_updateEmailListener);
					}
				}
			}
		});
		
		_sqlUsers_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					_telegramLoaderDialog(false);
					if (_childValue.containsKey("-username")) {
						usern = _childValue.get("-username").toString();
					}
					if (_childValue.containsKey("-full-name")) {
						name = _childValue.get("-full-name").toString();
					}
				} else {
					usernames.add(_childValue);
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (getIntent().getStringExtra("type").equals("username")) {
						if (_childValue.containsKey("-username")) {
							if (!edit.getText().toString().toLowerCase().trim().equals(usern) && edit.getText().toString().toLowerCase().trim().equals(_childValue.get("-username").toString())) {
								_Toast("Username has been updated.");
							}
						}
					}
					if (getIntent().getStringExtra("type").equals("name")) {
						if (_childValue.containsKey("-name")) {
							if (!edit.getText().toString().trim().equals(name) && edit.getText().toString().trim().equals(_childValue.get("-name").toString())) {
								_Toast("Full name has been updated.");
							}
						}
					}
					if (getIntent().getStringExtra("type").equals("pin")) {
						if (_childValue.containsKey("-pin")) {
							if (!edit.getText().toString().trim().equals(pin) && edit.getText().toString().trim().equals(_childValue.get("-pin").toString())) {
								_Toast("Transaction pin has been updated.");
							}
						}
					}
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									finish();
								}
							});
						}
					};
					_timer.schedule(t, (int)(500));
					
				} else {
					usernames.add(_childValue);
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlUsers.addChildEventListener(_sqlUsers_child_listener);
		
		Oauth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					map = new HashMap<>();
					map.put("-email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
					sqlUsers.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					finish();
				} else {
					_Toast(_errorMessage);
				}
			}
		};
		
		Oauth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Oauth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Oauth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Oauth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		Oauth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Oauth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_Oauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Oauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Oauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_changeActivityFont("light");
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		btnUp.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		_GradientDrawable(btnUp, 30, 0, 2, "#212121", "#212121", true, true, 100);
		edit.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFEEEEEE));
		t1.setText(getIntent().getStringExtra("t1"));
		t2.setText(getIntent().getStringExtra("t2"));
		edit.setHint(getIntent().getStringExtra("hint"));
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
		getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
		getWindow().setNavigationBarColor(Color.parseColor("#F5F5F5"));
		_autoTransitionScroll(bg);
		linear3.setElevation((float)3);
		errView.setVisibility(View.GONE);
		_telegramLoaderDialog(true);
		if (getIntent().getStringExtra("type").equals("number")) {
			_LengthOfEditText(edit, 11);
		}
		if (getIntent().getStringExtra("type").equals("pin")) {
			_LengthOfEditText(edit, 4);
		}
		if (getIntent().getStringExtra("type").equals("username")) {
			_LengthOfEditText(edit, 18);
		}
		_btnSup(false);
	}
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		} else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _Toast(final String _text) {
		SketchwareUtil.showMessage(getApplicationContext(), _text);
		_telegramLoaderDialog(false);
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _Max_textviewline(final TextView _txt, final double _line) {
		((TextView)_txt).setMaxLines((int)_line);
	}
	
	
	public void _LengthOfEditText(final TextView _editText, final double _value_character) {
		InputFilter[] gb = _editText.getFilters(); InputFilter[] newFilters = new InputFilter[gb.length + 1]; System.arraycopy(gb, 0, newFilters, 0, gb.length); newFilters[gb.length] = new InputFilter.LengthFilter((int)_value_character); _editText.setFilters(newFilters);
	}
	
	
	public void _btnSup(final boolean _TRUE) {
		if (_TRUE) {
			btnUp.setAlpha((float)(1.0d));
			btnUp.setEnabled(true);
		} else {
			btnUp.setAlpha((float)(0.6d));
			btnUp.setEnabled(false);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}