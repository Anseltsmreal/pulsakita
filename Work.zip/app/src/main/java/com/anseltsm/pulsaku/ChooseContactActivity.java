package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.provider.ContactsContract;
import android.net.Uri;
import android.content.ContentResolver;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.database.Cursor;

public class ChooseContactActivity extends AppCompatActivity {
	
	private HashMap<String, Object> map = new HashMap<>();
	private double searchnum = 0;
	private String saved = "";
	private double len = 0;
	private double n = 0;
	private String checkNumber = "";
	private String cleanNumber = "";
	private String format = "";
	private String format2 = "";
	private String format3 = "";
	
	private ArrayList<HashMap<String, Object>> Map = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_entries = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear5;
	private ListView listview1;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear_search;
	private LinearLayout linear4;
	private EditText edittext1;
	private LinearLayout linear_delete;
	private ImageView imageview2;
	private ImageView imageview3;
	
	private Intent in = new Intent();
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.choose_contact);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear5 = findViewById(R.id.linear5);
		listview1 = findViewById(R.id.listview1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		linear_search = findViewById(R.id.linear_search);
		linear4 = findViewById(R.id.linear4);
		edittext1 = findViewById(R.id.edittext1);
		linear_delete = findViewById(R.id.linear_delete);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.length() > 0) {
					    linear_delete.setVisibility(View.VISIBLE);
					
					    // Menggunakan ArrayList dengan tipe yang sesuai
					    ArrayList<HashMap<String, Object>> filteredList = new ArrayList<>();
					
					    for (HashMap<String, Object> item : Map) {
						        // Mengambil nomor sebagai Object, kemudian mengonversi ke String
						        String name = item.get("name").toString().toLowerCase();
						        if (name.contains(_charSeq.toLowerCase())) {
							            filteredList.add(item);
							        }
						    }
					
					    listview1.setAdapter(new Listview1Adapter(filteredList)); // Pastikan Listview1Adapter menerima tipe ini
				} else {
					    linear_delete.setVisibility(View.GONE);
					    listview1.setAdapter(new Listview1Adapter(Map)); // Map tetap utuh
				}
				
				((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext1.setText("");
			}
		});
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		linear_search.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFE1E1ED, 0xFFF8F7FC));
		linear_delete.setVisibility(View.GONE);
		_LengthOfEditText(edittext1, 12);
		_removeScollBar(listview1);
		if (Build.VERSION.SDK_INT >= 23) {
				if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_DENIED) {
						requestPermissions(new String[] {Manifest.permission.READ_CONTACTS}, 1000);
				} else {
						
						ContentResolver resolver=getContentResolver();
						Uri uri= ContactsContract.CommonDataKinds.Phone.CONTENT_URI; String[] projection=null;
						//use to access column-wise Data
						String selection=null;
						//use to access Row-Wise Data
						String[] selectonArgs=null; String order=null;
						Cursor cursor= resolver.query(uri,projection,selection,selectonArgs,order);
						//indian Team
						if (cursor.getCount()>0) {
								while (cursor.moveToNext()) {
										map = new HashMap<>();
						map.put("name", cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
						map.put("number", cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));
						Map.add(map);
								}
						}
						listview1.setAdapter(new Listview1Adapter(Map));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
		}
		else {
				ContentResolver resolver=getContentResolver();
				Uri uri= ContactsContract.CommonDataKinds.Phone.CONTENT_URI; String[] projection=null;
				//use to access column-wise Data
				String selection=null;
				//use to access Row-Wise Data
				String[] selectonArgs=null; String order=null;
				Cursor cursor= resolver.query(uri,projection,selection,selectonArgs,order);
				//IndianTeam40@gmail.com
				if (cursor.getCount()>0) {
						while (cursor.moveToNext()) {
								map = new HashMap<>();
					map.put("name", cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
					map.put("number", cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));
					Map.add(map);
								
						}
				}
				listview1.setAdapter(new Listview1Adapter(Map));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		}
	}
	
	public void _LengthOfEditText(final TextView _editText, final double _value_character) {
		InputFilter[] gb = _editText.getFilters(); 
		InputFilter[] newFilters = new InputFilter[gb.length + 1]; 
		System.arraycopy(gb, 0, newFilters, 0, gb.length); 
		newFilters[gb.length] = new InputFilter.LengthFilter((int)_value_character); 
		_editText.setFilters(newFilters);
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.kontak_custom, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview_nama = _view.findViewById(R.id.textview_nama);
			final TextView textview_telepon = _view.findViewById(R.id.textview_telepon);
			
			textview_nama.setText(_data.get((int)_position).get("name").toString());
			textview_telepon.setText(_data.get((int)_position).get("number").toString());
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					in.setClass(getApplicationContext(), RechargepyActivity.class);
					in.putExtra("type", sp.getString("tp", ""));
					format = _data.get((int)_position).get("number").toString().replace("+62 ", "");
					format2 = format.replace("-", "");
					format3 = format2.replace("+62", "");
					sp.edit().putString("ct", format3).commit();
					startActivity(in);
					finish();
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}