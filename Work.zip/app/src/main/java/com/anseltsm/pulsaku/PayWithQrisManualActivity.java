package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PayWithQrisManualActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout top;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear20;
	private TextView textview3;
	private LinearLayout langkah1;
	private LinearLayout linear_garis1;
	private LinearLayout linear9;
	private LinearLayout linear_garis2;
	private LinearLayout linear12;
	private LinearLayout linear_garis3;
	private LinearLayout linear14;
	private LinearLayout linear_garis4;
	private LinearLayout linear16;
	private LinearLayout linear_garis5;
	private LinearLayout linear18;
	private LinearLayout linear_garis6;
	private LinearLayout linear19;
	private LinearLayout linear_garis7;
	private TextView textview2;
	private TextView textview1;
	private LinearLayout lin1;
	private TextView t1;
	private TextView textview4;
	private LinearLayout lin2;
	private TextView t2;
	private TextView textview7;
	private LinearLayout lin3;
	private TextView t3;
	private TextView textview9;
	private LinearLayout lin4;
	private TextView t4;
	private TextView textview11;
	private LinearLayout lin5;
	private TextView t5;
	private TextView textview13;
	private LinearLayout lin6;
	private TextView t6;
	private TextView textview15;
	private LinearLayout lin7;
	private TextView textview5;
	private TextView textview16;
	
	private Intent in = new Intent();
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pay_with_qris_manual);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		top = findViewById(R.id.top);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear20 = findViewById(R.id.linear20);
		textview3 = findViewById(R.id.textview3);
		langkah1 = findViewById(R.id.langkah1);
		linear_garis1 = findViewById(R.id.linear_garis1);
		linear9 = findViewById(R.id.linear9);
		linear_garis2 = findViewById(R.id.linear_garis2);
		linear12 = findViewById(R.id.linear12);
		linear_garis3 = findViewById(R.id.linear_garis3);
		linear14 = findViewById(R.id.linear14);
		linear_garis4 = findViewById(R.id.linear_garis4);
		linear16 = findViewById(R.id.linear16);
		linear_garis5 = findViewById(R.id.linear_garis5);
		linear18 = findViewById(R.id.linear18);
		linear_garis6 = findViewById(R.id.linear_garis6);
		linear19 = findViewById(R.id.linear19);
		linear_garis7 = findViewById(R.id.linear_garis7);
		textview2 = findViewById(R.id.textview2);
		textview1 = findViewById(R.id.textview1);
		lin1 = findViewById(R.id.lin1);
		t1 = findViewById(R.id.t1);
		textview4 = findViewById(R.id.textview4);
		lin2 = findViewById(R.id.lin2);
		t2 = findViewById(R.id.t2);
		textview7 = findViewById(R.id.textview7);
		lin3 = findViewById(R.id.lin3);
		t3 = findViewById(R.id.t3);
		textview9 = findViewById(R.id.textview9);
		lin4 = findViewById(R.id.lin4);
		t4 = findViewById(R.id.t4);
		textview11 = findViewById(R.id.textview11);
		lin5 = findViewById(R.id.lin5);
		t5 = findViewById(R.id.t5);
		textview13 = findViewById(R.id.textview13);
		lin6 = findViewById(R.id.lin6);
		t6 = findViewById(R.id.t6);
		textview15 = findViewById(R.id.textview15);
		lin7 = findViewById(R.id.lin7);
		textview5 = findViewById(R.id.textview5);
		textview16 = findViewById(R.id.textview16);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear12.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								in.setClass(getApplicationContext(), ScanQrcodeManualActivity.class);
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		top.setElevation((float)4);
		lin1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		lin2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		lin3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		lin4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		lin5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		lin6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		lin7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFE1E1E9));
		_removeScollBar(vscroll1);
	}
	
	@Override
	public void onBackPressed() {
		
	}
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}