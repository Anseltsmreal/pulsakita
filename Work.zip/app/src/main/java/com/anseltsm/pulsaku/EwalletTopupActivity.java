package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class EwalletTopupActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> Map = new HashMap<>();
	private String status = "";
	private String data = "";
	private HashMap<String, Object> Map2 = new HashMap<>();
	private double ewallet = 0;
	
	private ArrayList<HashMap<String, Object>> testing = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	
	private LinearLayout linear3;
	private LinearLayout linear7;
	private LinearLayout linear_core;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private LinearLayout linear6;
	private TextView textview1;
	private ListView listview1;
	
	private RequestNetwork viewProduct;
	private RequestNetwork.RequestListener _viewProduct_request_listener;
	private SharedPreferences sp;
	private Intent in = new Intent();
	private TimerTask t;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.ewallet_topup);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		linear7 = findViewById(R.id.linear7);
		linear_core = findViewById(R.id.linear_core);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		linear6 = findViewById(R.id.linear6);
		textview1 = findViewById(R.id.textview1);
		listview1 = findViewById(R.id.listview1);
		viewProduct = new RequestNetwork(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MainActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		_viewProduct_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Map = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				status = (new Gson()).toJson(Map2.get("key"), new TypeToken<HashMap<String, Object>>(){}.getType());
				Map2 = new Gson().fromJson(status, new TypeToken<HashMap<String, Object>>(){}.getType());
				data = (new Gson()).toJson(Map.get("data"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listMap = new Gson().fromJson(data, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(listMap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				_removeScollBar(listview1);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("ewallet")) {
						ewallet = Double.parseDouble(_childValue.get("ewallet").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("ewallet")) {
						ewallet = Double.parseDouble(_childValue.get("ewallet").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		linear3.setElevation((float)4);
		linear7.setElevation((float)4);
		if (getIntent().getStringExtra("type").equals("Dana")) {
			Name.setText("Topup Dana");
			textview1.setText("Saldo Dana - ".concat(getIntent().getStringExtra("number")));
		} else {
			if (getIntent().getStringExtra("type").equals("Ovo")) {
				Name.setText("Topup Ovo");
				textview1.setText("Saldo Ovo - ".concat(getIntent().getStringExtra("number")));
			} else {
				if (getIntent().getStringExtra("type").equals("LinkAja")) {
					Name.setText("Topup LinkAja");
					textview1.setText("Saldo LinkAja - ".concat(getIntent().getStringExtra("number")));
				} else {
					if (getIntent().getStringExtra("type").equals("Gopay")) {
						Name.setText("Topup Gopay");
						textview1.setText("Saldo Gopay - ".concat(getIntent().getStringExtra("number")));
					} else {
						if (getIntent().getStringExtra("type").equals("Kaspro")) {
							Name.setText("Topup Kaspro");
							textview1.setText("Saldo Kaspro - ".concat(getIntent().getStringExtra("number")));
						} else {
							if (getIntent().getStringExtra("type").equals("ShopeePay")) {
								Name.setText("Topup ShopeePay");
								textview1.setText("Saldo ShopeePay - ".concat(getIntent().getStringExtra("number")));
							} else {
								if (getIntent().getStringExtra("type").equals("iSaku")) {
									Name.setText("Topup iSaku");
									textview1.setText("Saldo iSaku - ".concat(getIntent().getStringExtra("number")));
								} else {
									if (getIntent().getStringExtra("type").equals("Grab")) {
										Name.setText("Topup Grab");
										textview1.setText("Saldo Grab - ".concat(getIntent().getStringExtra("number")));
									}
								}
							}
						}
					}
				}
			}
		}
		viewProduct.startRequestNetwork(RequestNetworkController.GET, "https://api.tokovoucher.net/member/produk/list?member_code=".concat("M231128NBBK7814BS".concat("&signature=".concat("5ba9625048c9c28096093f2881e3a353".concat("&id_jenis=".concat(sp.getString("code_wallet", "")))))), "", _viewProduct_request_listener);
	}
	
	@Override
	public void onBackPressed() {
		
	}
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.ewallet_custom, null);
			}
			
			final LinearLayout core_ewallet = _view.findViewById(R.id.core_ewallet);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview_jumlah = _view.findViewById(R.id.textview_jumlah);
			final TextView textview_nominal = _view.findViewById(R.id.textview_nominal);
			
			core_ewallet.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFFF8F7FC);SketchUi.setCornerRadii(new float[]{
					d*10,d*10,d*10 ,d*10,d*0,d*0 ,d*0,d*0});
				linear2.setBackground(SketchUi);
			}
			textview_jumlah.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
			textview_nominal.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
			textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
			textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("ewallet", "")))));
			core_ewallet.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
					in.setClass(getApplicationContext(), CheckoutActivity.class);
					in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
					in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("ewallet", "")))));
					in.putExtra("tujuan", sp.getString("tujuan", ""));
					in.setAction(Intent.ACTION_VIEW);
					startActivity(in);
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}