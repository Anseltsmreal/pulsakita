package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class SettingsFragmentActivity extends Fragment {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> server = new HashMap<>();
	private HashMap<String, Object> map = new HashMap<>();
	private boolean logout = false;
	
	private LinearLayout linear3;
	private ScrollView vscroll1;
	private TextView textview28;
	private LinearLayout linear2;
	private LinearLayout about_core;
	private LinearLayout linear24;
	private LinearLayout settings_core;
	private LinearLayout application_stage_themes;
	private LinearLayout linear9;
	private LinearLayout application_stage_language;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private ImageView img1;
	private LinearLayout linear25;
	private TextView application_stage_themes_title;
	private TextView textview11;
	private ImageView img2;
	private LinearLayout linear26;
	private TextView textview12_email;
	private TextView textview13;
	private ImageView img3;
	private LinearLayout linear27;
	private TextView textview14_number;
	private TextView textview15;
	private ImageView img4;
	private LinearLayout linear28;
	private TextView textview16;
	private TextView textview17;
	private TextView textview10;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private LinearLayout linear34;
	private LinearLayout linear35;
	private LinearLayout linear36;
	private LinearLayout linear43;
	private ImageView img5;
	private LinearLayout linear37;
	private TextView textview18;
	private TextView textview19;
	private ImageView img6;
	private LinearLayout linear38;
	private LinearLayout linear42;
	private TextView textview20;
	private TextView textview21;
	private Switch switch2;
	private ImageView img7;
	private LinearLayout linear39;
	private LinearLayout linear41;
	private TextView textview22;
	private TextView textview23;
	private Switch switch1;
	private ImageView img8;
	private LinearLayout linear40;
	private TextView textview24;
	private TextView textview25;
	private ImageView img9;
	private LinearLayout linear44;
	private TextView textview26;
	private TextView textview27;
	
	private Intent in = new Intent();
	private DatabaseReference serverMain = _firebase.getReference("server");
	private ChildEventListener _serverMain_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference user = _firebase.getReference("users");
	private ChildEventListener _user_child_listener;
	private TimerTask t;
	private AlertDialog.Builder dialog;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.settings_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear3 = _view.findViewById(R.id.linear3);
		vscroll1 = _view.findViewById(R.id.vscroll1);
		textview28 = _view.findViewById(R.id.textview28);
		linear2 = _view.findViewById(R.id.linear2);
		about_core = _view.findViewById(R.id.about_core);
		linear24 = _view.findViewById(R.id.linear24);
		settings_core = _view.findViewById(R.id.settings_core);
		application_stage_themes = _view.findViewById(R.id.application_stage_themes);
		linear9 = _view.findViewById(R.id.linear9);
		application_stage_language = _view.findViewById(R.id.application_stage_language);
		linear10 = _view.findViewById(R.id.linear10);
		linear11 = _view.findViewById(R.id.linear11);
		linear13 = _view.findViewById(R.id.linear13);
		linear14 = _view.findViewById(R.id.linear14);
		img1 = _view.findViewById(R.id.img1);
		linear25 = _view.findViewById(R.id.linear25);
		application_stage_themes_title = _view.findViewById(R.id.application_stage_themes_title);
		textview11 = _view.findViewById(R.id.textview11);
		img2 = _view.findViewById(R.id.img2);
		linear26 = _view.findViewById(R.id.linear26);
		textview12_email = _view.findViewById(R.id.textview12_email);
		textview13 = _view.findViewById(R.id.textview13);
		img3 = _view.findViewById(R.id.img3);
		linear27 = _view.findViewById(R.id.linear27);
		textview14_number = _view.findViewById(R.id.textview14_number);
		textview15 = _view.findViewById(R.id.textview15);
		img4 = _view.findViewById(R.id.img4);
		linear28 = _view.findViewById(R.id.linear28);
		textview16 = _view.findViewById(R.id.textview16);
		textview17 = _view.findViewById(R.id.textview17);
		textview10 = _view.findViewById(R.id.textview10);
		linear30 = _view.findViewById(R.id.linear30);
		linear31 = _view.findViewById(R.id.linear31);
		linear32 = _view.findViewById(R.id.linear32);
		linear33 = _view.findViewById(R.id.linear33);
		linear34 = _view.findViewById(R.id.linear34);
		linear35 = _view.findViewById(R.id.linear35);
		linear36 = _view.findViewById(R.id.linear36);
		linear43 = _view.findViewById(R.id.linear43);
		img5 = _view.findViewById(R.id.img5);
		linear37 = _view.findViewById(R.id.linear37);
		textview18 = _view.findViewById(R.id.textview18);
		textview19 = _view.findViewById(R.id.textview19);
		img6 = _view.findViewById(R.id.img6);
		linear38 = _view.findViewById(R.id.linear38);
		linear42 = _view.findViewById(R.id.linear42);
		textview20 = _view.findViewById(R.id.textview20);
		textview21 = _view.findViewById(R.id.textview21);
		switch2 = _view.findViewById(R.id.switch2);
		img7 = _view.findViewById(R.id.img7);
		linear39 = _view.findViewById(R.id.linear39);
		linear41 = _view.findViewById(R.id.linear41);
		textview22 = _view.findViewById(R.id.textview22);
		textview23 = _view.findViewById(R.id.textview23);
		switch1 = _view.findViewById(R.id.switch1);
		img8 = _view.findViewById(R.id.img8);
		linear40 = _view.findViewById(R.id.linear40);
		textview24 = _view.findViewById(R.id.textview24);
		textview25 = _view.findViewById(R.id.textview25);
		img9 = _view.findViewById(R.id.img9);
		linear44 = _view.findViewById(R.id.linear44);
		textview26 = _view.findViewById(R.id.textview26);
		textview27 = _view.findViewById(R.id.textview27);
		auth = FirebaseAuth.getInstance();
		dialog = new AlertDialog.Builder(getActivity());
		
		linear43.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Dialog();
			}
		});
		
		textview27.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getContext().getApplicationContext(), PrivacyPolicyActivity.class);
				in.setAction(Intent.ACTION_VIEW);
				startActivity(in);
			}
		});
		
		_serverMain_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Server")) {
					if (_childValue.get("Status").toString().equals("Offline")) {
						in.setClass(getContext().getApplicationContext(), MaintenanceActivity.class);
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Server")) {
					if (_childValue.get("Status").toString().equals("Offline")) {
						in.setClass(getContext().getApplicationContext(), MaintenanceActivity.class);
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		serverMain.addChildEventListener(_serverMain_child_listener);
		
		_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("email")) {
						textview12_email.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("username")) {
						application_stage_themes_title.setText(_childValue.get("username").toString());
					}
					if (_childValue.containsKey("number")) {
						textview14_number.setText(_childValue.get("number").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("email")) {
						textview12_email.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("username")) {
						application_stage_themes_title.setText(_childValue.get("username").toString());
					}
					if (_childValue.containsKey("number")) {
						textview14_number.setText(_childValue.get("number").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user.addChildEventListener(_user_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		img1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		img9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)16, 0xFFF5F5F5));
		_removeScollBar(vscroll1);
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _dialog_mess() {
		
		AlertDialog alert = dialog.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, Color.parseColor("#EBEFF6")));
			alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#2196F3"));
			alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#EF5350"));
			alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#000000"));
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
		alert.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
		alert.getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
		TextView textT = (TextView)alert.getWindow().getDecorView().findViewById(android.R.id.message);
		Spannable text = new SpannableString(textT.getText().toString()); 
		text.setSpan(new ForegroundColorSpan(Color.parseColor("#757575")), 0, text.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE); 
		alert.setMessage(text);
		
		int titleId = getResources().getIdentifier( "alertTitle", "id", "android" ); 
		if (titleId > 0) 
		{ 
			TextView dialogTitle = (TextView) alert.getWindow().getDecorView().findViewById(titleId); 
			if (dialogTitle != null) 
			{
				Spannable title = new SpannableString(dialogTitle.getText().toString()); 
				title.setSpan(new ForegroundColorSpan(Color.parseColor("#000000")), 0, title.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE); 
				alert.setTitle(title);
			} 
		}
	}
	
	
	public void _Dialog() {
		dialog.setMessage("Kamu Yakin Bakal Keluar Dari Akun Ini? ");
		dialog.setPositiveButton("Yakin", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				t.cancel();
				FirebaseAuth.getInstance().signOut();
				in.setClass(getContext().getApplicationContext(), SplashActivity.class);
				in.setAction(Intent.ACTION_VIEW);
				startActivity(in);
			}
		});
		dialog.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		_dialog_mess();
	}
	
}