package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class InboxFragmentActivity extends Fragment {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private HashMap<String, Object> server = new HashMap<>();
	
	private LinearLayout linear3;
	private TabLayout TabLayoutInbox;
	private LinearLayout linear4;
	private ViewPager ViewPagerInbox;
	private TextView Name;
	
	private TabFragmentAdapter Tab;
	private DatabaseReference serverMain = _firebase.getReference("server");
	private ChildEventListener _serverMain_child_listener;
	private Intent in = new Intent();
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.inbox_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear3 = _view.findViewById(R.id.linear3);
		TabLayoutInbox = _view.findViewById(R.id.TabLayoutInbox);
		linear4 = _view.findViewById(R.id.linear4);
		ViewPagerInbox = _view.findViewById(R.id.ViewPagerInbox);
		Name = _view.findViewById(R.id.Name);
		Tab = new TabFragmentAdapter(getContext().getApplicationContext(), getActivity().getSupportFragmentManager());
		
		_serverMain_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Server")) {
					if (_childValue.get("Status").toString().equals("Offline")) {
						in.setClass(getContext().getApplicationContext(), MaintenanceActivity.class);
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Server")) {
					if (_childValue.get("Status").toString().equals("Offline")) {
						in.setClass(getContext().getApplicationContext(), MaintenanceActivity.class);
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					} else {
						
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		serverMain.addChildEventListener(_serverMain_child_listener);
	}
	
	private void initializeLogic() {
		TabLayoutInbox.setupWithViewPager(ViewPagerInbox);
		TabLayoutInbox.addTab(TabLayoutInbox.newTab().setText("Notifikasi"));
		TabLayoutInbox.addTab(TabLayoutInbox.newTab().setText("Informasi"));
		Tab.setTabCount(2);
		ViewPagerInbox.setAdapter(Tab);
		TabLayoutInbox.setTabTextColors(0xFF424242, 0xFF000000);
		TabLayoutInbox.setSelectedTabIndicatorColor(0xFF000000);
		TabLayoutInbox.setInlineLabel(false);
	}
	
	public class TabFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public TabFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			if (_position == 0) {
				return "Notifikasi";
			}
			if (_position == 1) {
				return "Informasi";
			}
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new NotifikasiFragmentActivity();
			}
			if (_position == 1) {
				return new InformasiFragmentActivity();
			}
			return null;
		}
	}
	
}