package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class TripayActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double received = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String balance = "";
	private double saldo = 0;
	
	private LinearLayout linear1;
	private CardView cardview1;
	private CardView cardview2;
	private CardView cardview3;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3_jumlah_tp;
	private TextView textview4;
	private TextView textview5_m_fee;
	private TextView textview6;
	private TextView textview7_cs_fee;
	private TextView textview8;
	private TextView textview9_jumlah_terima;
	private TextView textview10;
	private TextView textview11_ref;
	private TextView textview12;
	private TextView textview13_tgl;
	private TextView textview14;
	private TextView textview15_status;
	private TextView textview16;
	private MaterialButton materialbutton1;
	private MaterialButton materialbutton2;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference deposit = _firebase.getReference("deposit");
	private ChildEventListener _deposit_child_listener;
	private SharedPreferences sp;
	private Intent i = new Intent();
	private TimerTask t;
	private RequestNetwork cek;
	private RequestNetwork.RequestListener _cek_request_listener;
	private TimerTask tm;
	private DatabaseReference user = _firebase.getReference("users");
	private ChildEventListener _user_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.tripay);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		cardview1 = findViewById(R.id.cardview1);
		cardview2 = findViewById(R.id.cardview2);
		cardview3 = findViewById(R.id.cardview3);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		textview3_jumlah_tp = findViewById(R.id.textview3_jumlah_tp);
		textview4 = findViewById(R.id.textview4);
		textview5_m_fee = findViewById(R.id.textview5_m_fee);
		textview6 = findViewById(R.id.textview6);
		textview7_cs_fee = findViewById(R.id.textview7_cs_fee);
		textview8 = findViewById(R.id.textview8);
		textview9_jumlah_terima = findViewById(R.id.textview9_jumlah_terima);
		textview10 = findViewById(R.id.textview10);
		textview11_ref = findViewById(R.id.textview11_ref);
		textview12 = findViewById(R.id.textview12);
		textview13_tgl = findViewById(R.id.textview13_tgl);
		textview14 = findViewById(R.id.textview14);
		textview15_status = findViewById(R.id.textview15_status);
		textview16 = findViewById(R.id.textview16);
		materialbutton1 = findViewById(R.id.materialbutton1);
		materialbutton2 = findViewById(R.id.materialbutton2);
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		cek = new RequestNetwork(this);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse(sp.getString("Url", "")));
				startActivity(i);
			}
		});
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_telegramLoaderDialog(true);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								map = new HashMap<>();
								map.put("reference", textview11_ref.getText().toString());
								map.put("unik", sp.getString("Unik", ""));
								cek.setParams(map, RequestNetworkController.REQUEST_PARAM);
								cek.startRequestNetwork(RequestNetworkController.POST, "https://anseltsm.biz.id/app/payment/cektransaksi.php", "", _cek_request_listener);
								map.clear();
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
			}
		});
		
		_deposit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("nominal")) {
						sp.edit().putString("nominal", _childValue.get("nominal").toString()).commit();
					}
					if (_childValue.containsKey("method")) {
						sp.edit().putString("method", _childValue.get("method").toString()).commit();
					}
					if (_childValue.containsKey("Reference")) {
						textview11_ref.setText(_childValue.get("Reference").toString());
					}
					if (_childValue.containsKey("Amount")) {
						textview3_jumlah_tp.setText(_childValue.get("Amount").toString());
					}
					if (_childValue.containsKey("Merchant_fee")) {
						textview5_m_fee.setText(_childValue.get("Merchant_fee").toString());
					}
					if (_childValue.containsKey("Customer_fee")) {
						textview7_cs_fee.setText(_childValue.get("Customer_fee").toString());
					}
					if (_childValue.containsKey("Amount_received")) {
						textview9_jumlah_terima.setText(_childValue.get("Amount_received").toString());
						received = Double.parseDouble(_childValue.get("Amount_received").toString());
					}
					if (_childValue.containsKey("Status")) {
						textview15_status.setText(_childValue.get("Status").toString());
						if (_childValue.get("Status").toString().equals("PAID")) {
							textview15_status.setTextColor(0xFF4CAF50);
							cardview3.setVisibility(View.GONE);
						} else {
							textview15_status.setTextColor(0xFFF44336);
							cardview3.setVisibility(View.VISIBLE);
						}
					}
					if (_childValue.containsKey("Url")) {
						sp.edit().putString("Url", _childValue.get("Url").toString()).commit();
					}
					if (_childValue.containsKey("Unik")) {
						sp.edit().putString("Unik", _childValue.get("Unik").toString()).commit();
					}
					if (_childValue.containsKey("Refid")) {
						textview11_ref.setText(_childValue.get("Refid").toString());
					}
					textview13_tgl.setText(_childValue.get("tgl").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("nominal")) {
						sp.edit().putString("nominal", _childValue.get("nominal").toString()).commit();
					}
					if (_childValue.containsKey("method")) {
						sp.edit().putString("method", _childValue.get("method").toString()).commit();
					}
					if (_childValue.containsKey("Reference")) {
						textview11_ref.setText(_childValue.get("Reference").toString());
					}
					if (_childValue.containsKey("Amount")) {
						textview3_jumlah_tp.setText(_childValue.get("Amount").toString());
					}
					if (_childValue.containsKey("Merchant_fee")) {
						textview5_m_fee.setText(_childValue.get("Merchant_fee").toString());
					}
					if (_childValue.containsKey("Customer_fee")) {
						textview7_cs_fee.setText(_childValue.get("Customer_fee").toString());
					}
					if (_childValue.containsKey("Amount_received")) {
						textview9_jumlah_terima.setText(_childValue.get("Amount_received").toString());
						received = Double.parseDouble(_childValue.get("Amount_received").toString());
					}
					if (_childValue.containsKey("Status")) {
						textview15_status.setText(_childValue.get("Status").toString());
						if (_childValue.get("Status").toString().equals("PAID")) {
							textview15_status.setTextColor(0xFF4CAF50);
							materialbutton2.setVisibility(View.GONE);
						} else {
							textview15_status.setTextColor(0xFFF44336);
							materialbutton2.setVisibility(View.VISIBLE);
						}
					}
					if (_childValue.containsKey("Url")) {
						sp.edit().putString("Url", _childValue.get("Url").toString()).commit();
					}
					if (_childValue.containsKey("Unik")) {
						sp.edit().putString("Unik", _childValue.get("Unik").toString()).commit();
					}
					if (_childValue.containsKey("Refid")) {
						textview11_ref.setText(_childValue.get("Refid").toString());
					}
					textview13_tgl.setText(_childValue.get("tgl").toString());
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		deposit.addChildEventListener(_deposit_child_listener);
		
		_cek_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_telegramLoaderDialog(false);
				try{
					org.json.JSONObject response = new org.json.JSONObject(_response);
					if (response.optString("message"). equals("Status transaksi saat ini UNPAID")) {
						
					} else {
						if (response.optString("message"). equals("Status transaksi belum sukses. Coba beberapa menit lagi")) {
							
						} else {
							map = new HashMap<>();
							map.put("saldo", String.valueOf((long)(Double.parseDouble(String.valueOf((long)(saldo + received))))));
							user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
							map.clear();
							map = new HashMap<>();
							map.put("Status", "PAID");
							deposit.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
							map.clear();
							_set_Notification(sp.getString("info", ""), "DEPOSIT SALDO SEBESAR  ".concat("Rp ".concat(textview9_jumlah_terima.getText().toString().concat("  BERHASIL"))));
						}
					}
				} catch (Exception e) {}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					saldo = Double.parseDouble(_childValue.get("saldo").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					saldo = Double.parseDouble(_childValue.get("saldo").toString());
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user.addChildEventListener(_user_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
	}
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _set_Notification(final String _Title, final String _Message) {
		final Context context = getApplicationContext();
		
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(this, TripayActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
		
		// Tambahkan FLAG_IMMUTABLE
		PendingIntent pendingIntent = PendingIntent.getActivity(
		    this, 
		    0, 
		    intent, 
		    PendingIntent.FLAG_IMMUTABLE
		);
		
		int notificationId = 1;
		String channelId = "channel-01";
		String channelName = "Channel Name";
		int importance = NotificationManager.IMPORTANCE_HIGH;
		
		// Buat NotificationChannel untuk API 26+
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			    NotificationChannel mChannel = new NotificationChannel(
			            channelId, 
			            channelName, 
			            importance
			    );
			    notificationManager.createNotificationChannel(mChannel);
		}
		
		// Builder untuk notifikasi
		androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
		        .setSmallIcon(R.drawable.receipt_in) // Ganti dengan icon yang benar
		        .setContentTitle(_Title)
		        .setContentText(_Message)
		        .setAutoCancel(true) // Atur apakah notifikasi hilang setelah diklik
		        .setOngoing(false) // Jika true, ini akan menjadi notifikasi permanen
		        .setContentIntent(pendingIntent);
		
		// Kirim notifikasi
		notificationManager.notify(notificationId, mBuilder.build());
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}