package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
/*
*/
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

public class PasscodeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String btncolor = "";
	private String str_text1 = "";
	private String fontName = "";
	private String typeace = "";
	private HashMap<String, Object> pinMap = new HashMap<>();
	private String passcode = "";
	private boolean isVisible = false;
	private boolean tru = false;
	private String fullName = "";
	private String shtName = "";
	
	private ArrayList<HashMap<String, Object>> listUserMap = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout keypad;
	private LinearLayout linear1;
	private LinearLayout edit_lin;
	private LinearLayout indicator;
	private TextView textview3;
	private LinearLayout linear4;
	private LinearLayout keypad_1;
	private LinearLayout keypad_2;
	private LinearLayout keypad_3;
	private LinearLayout keypad_4;
	private LinearLayout linear2;
	private CircleImageView image;
	private LinearLayout linear3;
	private TextView passcode_txt;
	private TextView textview2;
	private EditText edittext1;
	private LinearLayout edit_divider_1;
	private EditText edittext2;
	private LinearLayout edit_divider_2;
	private EditText edittext3;
	private LinearLayout edit_divider_3;
	private EditText edittext4;
	private TextView textview1;
	private TextView textview4;
	private TextView textview5;
	private TextView num_1;
	private LinearLayout num_divider_1;
	private TextView num_2;
	private LinearLayout num_divider_2;
	private TextView num_3;
	private TextView num_4;
	private LinearLayout num_divider_3;
	private TextView num_5;
	private LinearLayout num_divider_4;
	private TextView num_6;
	private TextView num_7;
	private LinearLayout num_divider_5;
	private TextView num_8;
	private LinearLayout num_divider_6;
	private TextView num_9;
	private LinearLayout reset_lin;
	private LinearLayout num_divider_7;
	private TextView num_0;
	private LinearLayout num_divider_8;
	private LinearLayout backspace_lin;
	private ImageView reset_img;
	private ImageView backspace_img;
	
	private SharedPreferences passcodeData;
	private AlertDialog.Builder ready_cus_dialog;
	private TimerTask timer;
	private AlertDialog.Builder progress_cus_dialog;
	private Intent intent = new Intent();
	private SharedPreferences theme;
	private AlertDialog.Builder my_dialog;
	private Vibrator vib;
	private TimerTask t;
	private Vibrator vb;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference userDB = _firebase.getReference("users");
	private ChildEventListener _userDB_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.passcode);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		keypad = findViewById(R.id.keypad);
		linear1 = findViewById(R.id.linear1);
		edit_lin = findViewById(R.id.edit_lin);
		indicator = findViewById(R.id.indicator);
		textview3 = findViewById(R.id.textview3);
		linear4 = findViewById(R.id.linear4);
		keypad_1 = findViewById(R.id.keypad_1);
		keypad_2 = findViewById(R.id.keypad_2);
		keypad_3 = findViewById(R.id.keypad_3);
		keypad_4 = findViewById(R.id.keypad_4);
		linear2 = findViewById(R.id.linear2);
		image = findViewById(R.id.image);
		linear3 = findViewById(R.id.linear3);
		passcode_txt = findViewById(R.id.passcode_txt);
		textview2 = findViewById(R.id.textview2);
		edittext1 = findViewById(R.id.edittext1);
		edit_divider_1 = findViewById(R.id.edit_divider_1);
		edittext2 = findViewById(R.id.edittext2);
		edit_divider_2 = findViewById(R.id.edit_divider_2);
		edittext3 = findViewById(R.id.edittext3);
		edit_divider_3 = findViewById(R.id.edit_divider_3);
		edittext4 = findViewById(R.id.edittext4);
		textview1 = findViewById(R.id.textview1);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		num_1 = findViewById(R.id.num_1);
		num_divider_1 = findViewById(R.id.num_divider_1);
		num_2 = findViewById(R.id.num_2);
		num_divider_2 = findViewById(R.id.num_divider_2);
		num_3 = findViewById(R.id.num_3);
		num_4 = findViewById(R.id.num_4);
		num_divider_3 = findViewById(R.id.num_divider_3);
		num_5 = findViewById(R.id.num_5);
		num_divider_4 = findViewById(R.id.num_divider_4);
		num_6 = findViewById(R.id.num_6);
		num_7 = findViewById(R.id.num_7);
		num_divider_5 = findViewById(R.id.num_divider_5);
		num_8 = findViewById(R.id.num_8);
		num_divider_6 = findViewById(R.id.num_divider_6);
		num_9 = findViewById(R.id.num_9);
		reset_lin = findViewById(R.id.reset_lin);
		num_divider_7 = findViewById(R.id.num_divider_7);
		num_0 = findViewById(R.id.num_0);
		num_divider_8 = findViewById(R.id.num_divider_8);
		backspace_lin = findViewById(R.id.backspace_lin);
		reset_img = findViewById(R.id.reset_img);
		backspace_img = findViewById(R.id.backspace_img);
		passcodeData = getSharedPreferences("passcodeData", Activity.MODE_PRIVATE);
		ready_cus_dialog = new AlertDialog.Builder(this);
		progress_cus_dialog = new AlertDialog.Builder(this);
		theme = getSharedPreferences("theme", Activity.MODE_PRIVATE);
		my_dialog = new AlertDialog.Builder(this);
		vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		auth = FirebaseAuth.getInstance();
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vib.vibrate((long)(25));
				if (passcodeData.getString("passCodeData", "").equals("0")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Tidak ada kode pin untuk mengatur ulang");
				} else {
					pinMap = new HashMap<>();
					pinMap.put("-passcode", "0");
					userDB.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(pinMap);
				}
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SupportActivity.class);
				intent.setAction(Intent.ACTION_VIEW);
				startActivity(intent);
			}
		});
		
		num_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_1.getText().toString(), num_1.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_2.getText().toString(), num_2.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_3.getText().toString(), num_3.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_4.getText().toString(), num_4.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_5.getText().toString(), num_5.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_6.getText().toString(), num_6.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_7.getText().toString(), num_7.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_8.getText().toString(), num_8.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_9.getText().toString(), num_9.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		num_0.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Pass(num_0.getText().toString(), num_0.getText().toString());
				vib.vibrate((long)(25));
			}
		});
		
		backspace_lin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vib.vibrate((long)(25));
				if (str_text1.length() == 1) {
					edittext1.setText("");
					str_text1 = "";
				}
				if (str_text1.length() == 2) {
					edittext2.setText("");
					str_text1 = str_text1.substring((int)(0), (int)(1));
				}
				if (str_text1.length() == 3) {
					edittext3.setText("");
					str_text1 = str_text1.substring((int)(0), (int)(2));
				}
				if (str_text1.length() == 4) {
					edittext4.setText("");
					str_text1 = str_text1.substring((int)(0), (int)(3));
				}
			}
		});
		
		_userDB_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				userDB.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listUserMap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listUserMap.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("full_name")) {
								fullName = _childValue.get("full_name").toString();
								String[] nameParts = fullName.split(" ");
								        
								        // Get the first element
								        String firstName = nameParts[0];
								shtName = firstName;
							} else {
								shtName = "User";
							}
							if (_childValue.containsKey("passcode")) {
								passcode = _childValue.get("passcode").toString();
								passcodeData.edit().putString("passCodeData", passcode).commit();
								_telegramLoaderDialog(false);
								if (passcode.equals("0")) {
									passcode_txt.setText("Halo, ".concat(shtName));
									textview2.setText("Buat kode pin untuk akun anda");
									str_text1 = "";
									edittext1.setText("");
									edittext2.setText("");
									edittext3.setText("");
									edittext4.setText("");
								} else {
									passcode_txt.setText("Halo, ".concat(shtName));
									textview2.setText("Masukkan kode pin akun anda");
									str_text1 = "";
									edittext1.setText("");
									edittext2.setText("");
									edittext3.setText("");
									edittext4.setText("");
								}
							} else {
								pinMap = new HashMap<>();
								pinMap.put("passcode", "0");
								userDB.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(pinMap);
								pinMap.clear();
							}
							if (_childValue.containsKey("avatar")) {
								Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(image);
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("full_name")) {
						fullName = _childValue.get("full_name").toString();
						String[] nameParts = fullName.split(" ");
						        
						        // Get the first element
						        String firstName = nameParts[0];
						shtName = firstName;
					} else {
						shtName = "User";
					}
					if (_childValue.containsKey("passcode")) {
						passcode = _childValue.get("passcode").toString();
						passcodeData.edit().putString("passCodeData", passcode).commit();
						_telegramLoaderDialog(false);
						if (passcode.equals("0")) {
							passcode_txt.setText("Hello ".concat(shtName));
							textview2.setText("Buat kode pin untuk dompet anda");
							str_text1 = "";
							edittext1.setText("");
							edittext2.setText("");
							edittext3.setText("");
							edittext4.setText("");
						} else {
							passcode_txt.setText("Hello ".concat(shtName));
							textview2.setText("Masukkan kode pin untuk dompet anda");
							str_text1 = "";
							edittext1.setText("");
							edittext2.setText("");
							edittext3.setText("");
							edittext4.setText("");
						}
					} else {
						pinMap = new HashMap<>();
						pinMap.put("passcode", "0");
						userDB.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(pinMap);
						pinMap.clear();
					}
					if (_childValue.containsKey("avatar")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(image);
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userDB.addChildEventListener(_userDB_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_UiDesign();
		_typeface();
		_biometric();
		_telegramLoaderDialog(true);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (passcodeData.contains("passCodeData")) {
			passcode_txt.setText("Enter Your Passcode");
			textview2.setText("Enter the passcode for your wallet");
			
		} else {
			
		}
	}
	
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Override
	public void onResume() {
		super.onResume();
		userDB.addChildEventListener(_userDB_child_listener);
	}
	public void _UiDesign() {
		btncolor = "#EEEEEE";
		edittext1.setEnabled(false);
		edittext2.setEnabled(false);
		edittext3.setEnabled(false);
		edittext4.setEnabled(false);
		main.setBackgroundColor(0xFFFFFFFF);
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)6, 0xFFEEEEEE, 0xFFFFFFFF));
		edittext2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)6, 0xFFEEEEEE, 0xFFFFFFFF));
		edittext3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)6, 0xFFEEEEEE, 0xFFFFFFFF));
		edittext4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)6, 0xFFEEEEEE, 0xFFFFFFFF));
		_rippleRoundStroke(num_1, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_2, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_3, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_4, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_5, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_6, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_7, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_8, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_9, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(num_0, btncolor, "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(backspace_lin, "#000000", "#FFFFFF", 100, 0, "#FFFFFF");
		_rippleRoundStroke(reset_lin, "#000000", "#FFFFFF", 100, 0, "#FFFFFF");
		edittext1.setTextColor(0xFF424242);
		edittext2.setTextColor(0xFF424242);
		edittext3.setTextColor(0xFF424242);
		edittext4.setTextColor(0xFF000000);
		indicator.setBackgroundColor(0xFFE8EAED);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _Pass(final String _txt, final String _txt2) {
		if (str_text1.length() == 0) {
			edittext1.setText(_txt2);
			str_text1 = str_text1.concat(_txt);
		} else {
			if (str_text1.length() == 1) {
				edittext2.setText(_txt2);
				str_text1 = str_text1.concat(_txt);
			} else {
				if (str_text1.length() == 2) {
					edittext3.setText(_txt2);
					str_text1 = str_text1.concat(_txt);
				} else {
					if (str_text1.length() == 3) {
						edittext4.setText(_txt2);
						str_text1 = str_text1.concat(_txt);
						if (str_text1.length() == 4) {
							_ready_dialog();
						}
					}
				}
			}
		}
	}
	
	
	public void _typeface() {
		_changeActivityFont("light");
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _ready_dialog() {
		if (passcodeData.contains("passCodeData")) {
			if (passcodeData.getString("passCodeData", "").equals("0")) {
				_set_password();
			} else {
				_check_passcode();
			}
		}
	}
	
	
	public void _set_password() {
		_telegramLoaderDialog(true);
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (passcodeData.getString("passCodeData", "").equals("0")) {
							pinMap = new HashMap<>();
							pinMap.put("passcode", str_text1);
							userDB.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(pinMap);
							pinMap.clear();
						}
					}
				});
			}
		};
		_timer.schedule(timer, (int)(2000));
	}
	
	
	public void _check_passcode() {
		_telegramLoaderDialog(true);
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						_telegramLoaderDialog(false);
						if (!passcode.equals("0")) {
							if (passcode.equals(str_text1)) {
								intent.setClass(getApplicationContext(), MainActivity.class);
								intent.setAction(Intent.ACTION_VIEW);
								startActivity(intent);
								finish();
							} else {
								vib.vibrate((long)(100));
								_Toast("Kode Pin Salah.");
								str_text1 = "";
								edittext1.setText("");
								edittext2.setText("");
								edittext3.setText("");
								edittext4.setText("");
							}
						} else {
							_Toast("Ada sesuatu yang salah!");
						}
					}
				});
			}
		};
		_timer.schedule(timer, (int)(2000));
	}
	
	
	public void _getThemeData() {
		
	}
	
	
	public void _biometric() {
		try{
			BiometricManager biometricManager = androidx.biometric.BiometricManager.from(this);
			switch(biometricManager.canAuthenticate()) {
				case BiometricManager.BIOMETRIC_SUCCESS: {
					 
					break;
				}
				case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE: {
					 
					break;
				}
				case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE: {
					 
					break;
				}
				case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED: {
					 
					break;
				}
			}
			Executor executor = ContextCompat.getMainExecutor(this);
			final BiometricPrompt biometricPrompt = new BiometricPrompt(PasscodeActivity.this, executor, new BiometricPrompt.AuthenticationCallback() { 
					
					@Override
					
					public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) { 
							
							super.onAuthenticationError(errorCode, errString); 
							
					} 
					
					
					
					// THIS METHOD IS CALLED WHEN AUTHENTICATION IS SUCCESS 
					
					@Override
					
					public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) { 
							
							super.onAuthenticationSucceeded(result);
							
					        intent.setClass(getApplicationContext(), MainActivity.class);
					        
					        startActivity(intent);
					        
					        finish();
					        
					} 
					
					@Override
					
					public void onAuthenticationFailed() { 
							
							super.onAuthenticationFailed();
							
					} 
					
			}); 
			
			final BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder().setTitle("Autentikasi Sidik Jari") 
			
			.setDescription("Gunakan Sidik Jari Untuk Login").setNegativeButtonText("Gunakan PIN").build(); 
			
			reset_lin.setOnClickListener(new View.OnClickListener() { 
					
					@Override
					
					public void onClick(View v) { 
							
							biometricPrompt.authenticate(promptInfo); 
							
							
							
					} 
					
			}); 
			
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), e.toString());
		}
		
	}
	
	
	public void _dangerDialog() {
		
		
		AlertDialog alert = my_dialog.show();
		alert.getWindow().getDecorView().setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, Color.parseColor("#FFEBEE")));
		alert.getWindow().getDecorView().setPadding(8,8,8,8);
		alert.show();
		
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#FF0000"));
		alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#2196f3"));
		alert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#2196f3"));
		alert.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
		alert.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
		alert.getButton(AlertDialog.BUTTON_NEUTRAL).setAllCaps(false);
		alert.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
		alert.getWindow().getDecorView().setTranslationY(-20);
		TextView textT = (TextView)alert.getWindow().getDecorView().findViewById(android.R.id.message);
		Spannable text = new SpannableString(textT.getText().toString()); 
		text.setSpan(new ForegroundColorSpan(Color.parseColor("#263238")), 0, text.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE); 
		alert.setMessage(text);
		
		int titleId = getResources().getIdentifier( "alertTitle", "id", "android" ); 
		if (titleId > 0) 
		{ 
			TextView dialogTitle = (TextView) alert.getWindow().getDecorView().findViewById(titleId); 
			if (dialogTitle != null) 
			{
				Spannable title = new SpannableString(dialogTitle.getText().toString()); 
				title.setSpan(new ForegroundColorSpan(Color.parseColor("#000000")), 0, title.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE); 
				alert.setTitle(title);
			} 
		}
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _Toast(final String _text) {
		SketchwareUtil.showMessage(getApplicationContext(), _text);
		_telegramLoaderDialog(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}