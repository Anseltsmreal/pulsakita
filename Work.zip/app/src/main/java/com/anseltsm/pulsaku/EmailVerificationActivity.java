package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

public class EmailVerificationActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double Times = 0;
	private double m = 0;
	private double s = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private HashMap<String, Object> usersMap = new HashMap<>();
	private boolean emailVerify = false;
	private HashMap<String, Object> mj = new HashMap<>();
	private HashMap<String, Object> walMap = new HashMap<>();
	private String fullName = "";
	private String uid = "";
	private HashMap<String, Object> Inbox = new HashMap<>();
	private String pushKey = "";
	private String token = "";
	
	private LinearLayout linear3;
	private LinearLayout linear6;
	private LinearLayout linear4;
	private LinearLayout linear7;
	private LinearLayout linear2;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private ImageView imageview3;
	private TextView textview2;
	private TextView my_token;
	private LinearLayout buttons;
	private TextView skip_button;
	private LinearLayout complete_button;
	private TextView complete_button_title;
	private ProgressBar complete_button_loader_bar;
	
	private TimerTask t;
	private Intent in = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference sqlUsers = _firebase.getReference("users");
	private ChildEventListener _sqlUsers_child_listener;
	private SharedPreferences passcodeData;
	private SharedPreferences data;
	private DatabaseReference sqlDevice = _firebase.getReference("users/device");
	private ChildEventListener _sqlDevice_child_listener;
	private RequestNetwork reqNet;
	private RequestNetwork.RequestListener _reqNet_request_listener;
	private DatabaseReference sqlWallet = _firebase.getReference("wallet");
	private ChildEventListener _sqlWallet_child_listener;
	private Calendar date = Calendar.getInstance();
	private SharedPreferences nameUser;
	private DatabaseReference broadMessage = _firebase.getReference("broadcast");
	private ChildEventListener _broadMessage_child_listener;
	private DatabaseReference userInbox = _firebase.getReference("inbox");
	private ChildEventListener _userInbox_child_listener;
	
	private OnCompleteListener cloudMessaging_onCompleteListener;
	private RequestNetwork requestNetwork;
	private RequestNetwork.RequestListener _requestNetwork_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.email_verification);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		linear6 = findViewById(R.id.linear6);
		linear4 = findViewById(R.id.linear4);
		linear7 = findViewById(R.id.linear7);
		linear2 = findViewById(R.id.linear2);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		imageview3 = findViewById(R.id.imageview3);
		textview2 = findViewById(R.id.textview2);
		my_token = findViewById(R.id.my_token);
		buttons = findViewById(R.id.buttons);
		skip_button = findViewById(R.id.skip_button);
		complete_button = findViewById(R.id.complete_button);
		complete_button_title = findViewById(R.id.complete_button_title);
		complete_button_loader_bar = findViewById(R.id.complete_button_loader_bar);
		auth = FirebaseAuth.getInstance();
		passcodeData = getSharedPreferences("data", Activity.MODE_PRIVATE);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		reqNet = new RequestNetwork(this);
		nameUser = getSharedPreferences("name", Activity.MODE_PRIVATE);
		requestNetwork = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(auth_emailVerificationSentListener);
			}
		});
		
		skip_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		complete_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pushKey = userInbox.push().getKey();
				complete_button_title.setVisibility(View.GONE);
				complete_button_loader_bar.setVisibility(View.VISIBLE);
				try{
					FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
					FirebaseUser user = firebaseAuth.getCurrentUser();
					
					if (user != null) {
							user.reload().addOnCompleteListener(new OnCompleteListener<Void>() {
									@Override
									public void onComplete(@NonNull Task<Void> task) {
											if (task.isSuccessful()) {
													if (user.isEmailVerified()) {
										                    
										                    emailVerify = true;
													} else {
										                    
										                    emailVerify = false;
													}
											}
									}
							});
					}
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (emailVerify) {
										date = Calendar.getInstance();
										fullName = nameUser.getString("fullName", "");
										String[] nameParts = fullName.split(" ");
										        
										        // Get the first element
										        String firstName = nameParts[0];
										usersMap = new HashMap<>();
										usersMap.put("avatar", "https://firebasestorage.googleapis.com/v0/b/database-ptreodactyl.appspot.com/o/bucket%2Fprofile%2F1000449466.jpg?alt=media&token=8813e9af-adfe-49d3-8c7e-9decd2d1ab4c");
										usersMap.put("username", firstName.concat("_".concat(_getRandomText(5, "abcd12345"))));
										usersMap.put("full_name", fullName);
										usersMap.put("email", nameUser.getString("mailUser", ""));
										usersMap.put("number", nameUser.getString("numbUser", ""));
										usersMap.put("password", nameUser.getString("passUser", ""));
										usersMap.put("emailverified", "true");
										usersMap.put("token", token);
										usersMap.put("date_joined", new SimpleDateFormat("dd MM, yyyy - hh:mm").format(date.getTime()));
										usersMap.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
										usersMap.put("status", "Member");
										usersMap.put("banned", "No");
										usersMap.put("freeze", "false");
										usersMap.put("user_package", getApplicationContext().getPackageName());
										usersMap.put("pin", "0");
										usersMap.put("passcode", "0");
										usersMap.put("saldo", "0");
										usersMap.put("poin", "0");
										usersMap.put("transaksi", "0");
										sqlUsers.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(usersMap);
										usersMap.clear();
										Inbox = new HashMap<>();
										Inbox.put("Time", new SimpleDateFormat("yyyy-MM-dd, HH:mm").format(date.getTime()));
										Inbox.put("Judul", "Layanan Sudah Aktif!");
										Inbox.put("Pesan", "Selamat menikmati kemudahan transaksi dengan NoblePay. Kini beli dan bayar apapun jadi #Lebih Mudah!");
										Inbox.put("UID", FirebaseAuth.getInstance().getCurrentUser().getUid());
										userInbox.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(pushKey).updateChildren(Inbox); 
										Inbox.clear();
										passcodeData.edit().putString("passCodeData", "0").commit();
										data.edit().putString("chk", "").commit();
										t = new TimerTask() {
											@Override
											public void run() {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														in.setClass(getApplicationContext(), PasscodeActivity.class);
														startActivity(in);
														finish();
													}
												});
											}
										};
										_timer.schedule(t, (int)(200));
									} else {
										SketchwareUtil.showMessage(getApplicationContext(), "Verifikasi Email Terlebih Dahulu!");
										complete_button_loader_bar.setVisibility(View.GONE);
										complete_button_title.setVisibility(View.VISIBLE);
									}
								}
							});
						}
					};
					_timer.schedule(t, (int)(5000));
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "Sepertinya Ada Yang Salah!");
				}
			}
		});
		
		_sqlUsers_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlUsers.addChildEventListener(_sqlUsers_child_listener);
		
		_sqlDevice_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlDevice.addChildEventListener(_sqlDevice_child_listener);
		
		_reqNet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_sqlWallet_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlWallet.addChildEventListener(_sqlWallet_child_listener);
		
		_broadMessage_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		broadMessage.addChildEventListener(_broadMessage_child_listener);
		
		_userInbox_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userInbox.addChildEventListener(_userInbox_child_listener);
		
		cloudMessaging_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_requestNetwork_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "Link Verifikasi Telah Dikirim Ke Email Anda!");
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(auth_emailVerificationSentListener);
		_stateColor(0xFFFFFFFF, 0xFFFFFFFF);
		complete_button_loader_bar.setVisibility(View.GONE);
		_progressBarColor(complete_button_loader_bar, 0xFFFFFFFF);
		_viewGraphics(skip_button, 0xFFFFFFFF, 0xFFEEEEEE, 300, 3, 0xFFEEEEEE);
		_viewGraphics(complete_button, 0xFF000000, 0xFF000000, 300, 0, Color.TRANSPARENT);
		_subscribeFCMTopic("all");
		_getDeviceFCMToken();
	}
	
	@Override
	public void onBackPressed() {
		
	}
	
	public void _viewGraphics(final View _view, final int _onFocus, final int _onRipple, final double _radius, final double _stroke, final int _strokeColor) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(_onFocus);
		GG.setCornerRadius((float)_radius);
		GG.setStroke((int) _stroke, _strokeColor);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ _onRipple}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _stateColor(final int _statusColor, final int _navigationColor) {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(_statusColor);
		getWindow().setNavigationBarColor(_navigationColor);
	}
	
	
	public void _progressBarColor(final ProgressBar _progressbar, final int _color) {
		int color = _color;
		_progressbar.setIndeterminateTintList(ColorStateList.valueOf(color));
		_progressbar.setProgressTintList(ColorStateList.valueOf(color));
	}
	
	
	public void _Toast(final String _text) {
		SketchwareUtil.showMessage(getApplicationContext(), _text);
	}
	
	
	public String _getRandomText(final double _num, final String _string) {
		String str2 = "";
		for (int i = 0; i < (int)_num; i++) {
				str2 = str2 + _string.charAt(new java.util.Random().nextInt(_string.length()));
		}
		return str2;
	}
	
	
	public void _getDeviceFCMToken() {
		FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(@NonNull Task<InstanceIdResult> task) {
				if (task.isSuccessful()) {
					token = task.getResult().getToken();
					
					
					
					// here my_token is textview
					
					
					//SketchwareUtil.showMessage(getApplicationContext(), "Fcm Token generated !");
					
					
				} else {
					
					
					//SketchwareUtil.showMessage(getApplicationContext(), "Unknown Error Occurred");
				}}});
	}
	
	
	public void _subscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().subscribeToTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						//SketchwareUtil.showMessage(getApplicationContext(), "Subscribed Successfully");
					} else {
						//SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Subscribe");
					}}});
		} else {
			//SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _unsubscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().unsubscribeFromTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						//SketchwareUtil.showMessage(getApplicationContext(), "Unsubscribed Successfully");
					} else {
						//SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Unsubscribe");
					}}});
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _sendFCMNotification(final String _key, final String _title, final String _content, final String _imageUrl, final String _topic, final String _token) {
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			HashMap<String, Object> requestHeader = new HashMap<>();
			
			HashMap<String, Object> notificationBody = new HashMap<>();
			
			HashMap<String, Object> requestBody = new HashMap<>();
			requestHeader = new HashMap<>();
			requestHeader.put("Authorization", "key=".concat(_key));
			requestHeader.put("Content-Type", "application/json");
			
			notificationBody = new HashMap<>();
			notificationBody.put("title", _title);
			notificationBody.put("body", _content);
			notificationBody.put("image", _imageUrl);
			
			requestBody = new HashMap<>();
			if (!_topic.equals("null")) {
				requestBody.put("to", "/topics/".concat(_topic));
			} else {
				requestBody.put("to", _token);
			}
			requestBody.put("notification", notificationBody);
			requestNetwork.setHeaders(requestHeader);
			requestNetwork.setParams(requestBody, RequestNetworkController.REQUEST_BODY);
			requestNetwork.startRequestNetwork(RequestNetworkController.POST, "https://fcm.googleapis.com/fcm/send", "", _requestNetwork_request_listener);
		} else {
			//SketchwareUtil.showMessage(getApplicationContext(), "No Internet Connection");
		}
	}
	
	
	public void _glideFromURL(final String _url, final ImageView _imageview) {
		Glide.with(getApplicationContext())
		.load(_url)
		.diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
		.error(R.drawable.noblepay_black_logo)
		.into(_imageview);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}