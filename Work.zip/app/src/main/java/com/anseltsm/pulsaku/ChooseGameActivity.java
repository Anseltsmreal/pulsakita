package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ChooseGameActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear3;
	private ScrollView core;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private LinearLayout linear_second;
	private LinearLayout linear9;
	private LinearLayout linear13;
	private LinearLayout linear17;
	private LinearLayout linear25;
	private LinearLayout linear21;
	private CardView cardview1;
	private CardView cardview2;
	private CardView cardview3;
	private LinearLayout linear10;
	private ImageView imageview4;
	private TextView textview1;
	private LinearLayout linear11;
	private ImageView imageview5;
	private TextView textview2;
	private LinearLayout linear12;
	private ImageView imageview6;
	private TextView textview3;
	private CardView cardview4;
	private CardView cardview5;
	private CardView cardview6;
	private LinearLayout linear14;
	private ImageView imageview7;
	private TextView textview4;
	private LinearLayout linear15;
	private ImageView imageview8;
	private TextView textview5;
	private LinearLayout linear16;
	private ImageView imageview9;
	private TextView textview6;
	private CardView cardview7;
	private CardView cardview8;
	private CardView cardview9;
	private LinearLayout linear18;
	private ImageView imageview10;
	private TextView textview7;
	private LinearLayout linear19;
	private ImageView imageview11;
	private TextView textview8;
	private LinearLayout linear20;
	private ImageView imageview12;
	private TextView textview9;
	private CardView cardview13;
	private CardView cardview14;
	private CardView cardview15;
	private LinearLayout linear26;
	private ImageView imageview16;
	private TextView textview13;
	private LinearLayout linear27;
	private ImageView imageview17;
	private TextView textview14;
	private LinearLayout linear28;
	private ImageView imageview18;
	private TextView textview15;
	private CardView cardview10;
	private CardView cardview11;
	private CardView cardview12;
	private LinearLayout linear22;
	private ImageView imageview13;
	private TextView textview10;
	private LinearLayout linear23;
	private ImageView imageview14;
	private TextView textview11;
	private LinearLayout linear24;
	private ImageView imageview15;
	private TextView textview12;
	
	private TimerTask t;
	private Intent in = new Intent();
	private AlertDialog.Builder d;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.choose_game);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		core = findViewById(R.id.core);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		linear_second = findViewById(R.id.linear_second);
		linear9 = findViewById(R.id.linear9);
		linear13 = findViewById(R.id.linear13);
		linear17 = findViewById(R.id.linear17);
		linear25 = findViewById(R.id.linear25);
		linear21 = findViewById(R.id.linear21);
		cardview1 = findViewById(R.id.cardview1);
		cardview2 = findViewById(R.id.cardview2);
		cardview3 = findViewById(R.id.cardview3);
		linear10 = findViewById(R.id.linear10);
		imageview4 = findViewById(R.id.imageview4);
		textview1 = findViewById(R.id.textview1);
		linear11 = findViewById(R.id.linear11);
		imageview5 = findViewById(R.id.imageview5);
		textview2 = findViewById(R.id.textview2);
		linear12 = findViewById(R.id.linear12);
		imageview6 = findViewById(R.id.imageview6);
		textview3 = findViewById(R.id.textview3);
		cardview4 = findViewById(R.id.cardview4);
		cardview5 = findViewById(R.id.cardview5);
		cardview6 = findViewById(R.id.cardview6);
		linear14 = findViewById(R.id.linear14);
		imageview7 = findViewById(R.id.imageview7);
		textview4 = findViewById(R.id.textview4);
		linear15 = findViewById(R.id.linear15);
		imageview8 = findViewById(R.id.imageview8);
		textview5 = findViewById(R.id.textview5);
		linear16 = findViewById(R.id.linear16);
		imageview9 = findViewById(R.id.imageview9);
		textview6 = findViewById(R.id.textview6);
		cardview7 = findViewById(R.id.cardview7);
		cardview8 = findViewById(R.id.cardview8);
		cardview9 = findViewById(R.id.cardview9);
		linear18 = findViewById(R.id.linear18);
		imageview10 = findViewById(R.id.imageview10);
		textview7 = findViewById(R.id.textview7);
		linear19 = findViewById(R.id.linear19);
		imageview11 = findViewById(R.id.imageview11);
		textview8 = findViewById(R.id.textview8);
		linear20 = findViewById(R.id.linear20);
		imageview12 = findViewById(R.id.imageview12);
		textview9 = findViewById(R.id.textview9);
		cardview13 = findViewById(R.id.cardview13);
		cardview14 = findViewById(R.id.cardview14);
		cardview15 = findViewById(R.id.cardview15);
		linear26 = findViewById(R.id.linear26);
		imageview16 = findViewById(R.id.imageview16);
		textview13 = findViewById(R.id.textview13);
		linear27 = findViewById(R.id.linear27);
		imageview17 = findViewById(R.id.imageview17);
		textview14 = findViewById(R.id.textview14);
		linear28 = findViewById(R.id.linear28);
		imageview18 = findViewById(R.id.imageview18);
		textview15 = findViewById(R.id.textview15);
		cardview10 = findViewById(R.id.cardview10);
		cardview11 = findViewById(R.id.cardview11);
		cardview12 = findViewById(R.id.cardview12);
		linear22 = findViewById(R.id.linear22);
		imageview13 = findViewById(R.id.imageview13);
		textview10 = findViewById(R.id.textview10);
		linear23 = findViewById(R.id.linear23);
		imageview14 = findViewById(R.id.imageview14);
		textview11 = findViewById(R.id.textview11);
		linear24 = findViewById(R.id.linear24);
		imageview15 = findViewById(R.id.imageview15);
		textview12 = findViewById(R.id.textview12);
		d = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		cardview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				cardview1.startAnimation(fade_in);
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "1");
				in.setAction(Intent.ACTION_VIEW);
				startActivity(in);
			}
		});
		
		cardview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "2");
				startActivity(in);
				finish();
			}
		});
		
		cardview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "4");
				startActivity(in);
				finish();
			}
		});
		
		cardview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "7");
				startActivity(in);
				finish();
			}
		});
		
		cardview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "66");
				startActivity(in);
				finish();
			}
		});
		
		cardview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "128");
				startActivity(in);
				finish();
			}
		});
		
		cardview13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "5");
				startActivity(in);
				finish();
			}
		});
		
		cardview14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "9");
				startActivity(in);
				finish();
			}
		});
		
		cardview15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "131");
				startActivity(in);
				finish();
			}
		});
		
		cardview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "70");
				startActivity(in);
				finish();
			}
		});
		
		cardview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), KategoriActivity.class);
				in.putExtra("id", "152");
				startActivity(in);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		linear3.setElevation((float)4);
	}
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}