package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class TopupActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private double crn = 0;
	private double amut = 0;
	private HashMap<String, Object> map = new HashMap<>();
	
	private LinearLayout linear3;
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView Name;
	private LinearLayout linear4;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linearAMT;
	private TextView txt_amt;
	private CardView cardview1;
	private LinearLayout button1;
	private TextView textview42;
	private LinearLayout linear13;
	private LinearLayout linear22;
	private LinearLayout linear_input;
	private LinearLayout linear27;
	private EditText amt;
	private TextView textview43;
	private TextView textbtn;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private TextView textview8_49;
	private TextView textview10_98;
	private TextView textview12_197;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private TextView textview22;
	private TextView textview24;
	private TextView textview26;
	
	private Intent in = new Intent();
	private TimerTask t;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference deposit = _firebase.getReference("deposit");
	private ChildEventListener _deposit_child_listener;
	private Calendar c = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.topup);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		Name = findViewById(R.id.Name);
		linear4 = findViewById(R.id.linear4);
		vscroll1 = findViewById(R.id.vscroll1);
		linear2 = findViewById(R.id.linear2);
		linearAMT = findViewById(R.id.linearAMT);
		txt_amt = findViewById(R.id.txt_amt);
		cardview1 = findViewById(R.id.cardview1);
		button1 = findViewById(R.id.button1);
		textview42 = findViewById(R.id.textview42);
		linear13 = findViewById(R.id.linear13);
		linear22 = findViewById(R.id.linear22);
		linear_input = findViewById(R.id.linear_input);
		linear27 = findViewById(R.id.linear27);
		amt = findViewById(R.id.amt);
		textview43 = findViewById(R.id.textview43);
		textbtn = findViewById(R.id.textbtn);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		textview8_49 = findViewById(R.id.textview8_49);
		textview10_98 = findViewById(R.id.textview10_98);
		textview12_197 = findViewById(R.id.textview12_197);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		textview22 = findViewById(R.id.textview22);
		textview24 = findViewById(R.id.textview24);
		textview26 = findViewById(R.id.textview26);
		auth = FirebaseAuth.getInstance();
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				c = Calendar.getInstance();
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				button1.startAnimation(fade_in);
				map = new HashMap<>();
				map.put("nominal", amt.getText().toString());
				map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("tgl", new SimpleDateFormat("EEEE, ddMMMMyyyy HH:mm:ss").format(c.getTime()));
				deposit.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
				_telegramLoaderDialog(true);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_telegramLoaderDialog(false);
								in.setClass(getApplicationContext(), MethodActivity.class);
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
			}
		});
		
		linear14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amt.setText("10000");
			}
		});
		
		linear15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amt.setText("20000");
			}
		});
		
		linear16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amt.setText("50000");
			}
		});
		
		linear23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amt.setText("100000");
			}
		});
		
		linear24.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amt.setText("300000");
			}
		});
		
		linear25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amt.setText("500000");
			}
		});
		
		_deposit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		deposit.addChildEventListener(_deposit_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		_removeScollBar(vscroll1);
		amt.requestFocus();
		crn = 20;
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)crn, 0xFF212121));
		linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)crn, (int)2, 0xFFEEEEEE, 0xFFFFFFFF));
		linear15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)crn, (int)2, 0xFFEEEEEE, 0xFFFFFFFF));
		linear16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)crn, (int)2, 0xFFEEEEEE, 0xFFFFFFFF));
		linear23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)crn, (int)2, 0xFFEEEEEE, 0xFFFFFFFF));
		linear24.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)crn, (int)2, 0xFFEEEEEE, 0xFFFFFFFF));
		linear25.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)crn, (int)2, 0xFFEEEEEE, 0xFFFFFFFF));
		_advancedCorners(linear27, "#E1E1E9", 20, 0, 20, 0);
		linearAMT.setVisibility(View.VISIBLE);
		_autoTransitionScroll(linear2);
		textbtn.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		Name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview8_49.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview10_98.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview12_197.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview22.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview24.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		textview26.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _extra() {
		// original library is in github (https://github.com/AbhinayMe/currency-edittext)
	}
	public class CurrencyEditText extends EditText {
		
		    private String current = "";
		    private CurrencyEditText editText = CurrencyEditText.this;
		
		    //properties
		    private String Currency = "";
		    private String Separator = ".";
		    private Boolean Spacing = false;
		    private Boolean Delimiter = false;
		    private Boolean Decimals = true;
		
		    public CurrencyEditText(android.content.Context context) {
			        super(context);
			        init();
			    }
		
		    public CurrencyEditText(android.content.Context context, android.util.AttributeSet attrs) {
			        super(context, attrs);
			        init();
			    }
		
		    public CurrencyEditText(android.content.Context context, android.util.AttributeSet attrs, int defStyleAttr) {
			        super(context, attrs, defStyleAttr);
			        init();
			    }
		
		    public void init() {
			
			        this.addTextChangedListener(new android.text.TextWatcher() {
				            @Override
				            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
					
					            }
				
				            @Override
				            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
					                if (!s.toString().equals(current)) {
						                    editText.removeTextChangedListener(this);
						
						                    String cleanString = s.toString().replaceAll("[$,.]", "").replaceAll(Currency, "").replaceAll("\\s+", "");
						
						                    if (cleanString.length() != 0) {
							                        try {
								
								                            String currencyFormat = "";
								                            if (Spacing) {
									                                if (Delimiter) {
										                                    currencyFormat = Currency + ". ";
										                                } else {
										                                    currencyFormat = Currency + " ";
										                                }
									                            } else {
									                                if (Delimiter) {
										                                    currencyFormat = Currency + ".";
										                                } else {
										                                    currencyFormat = Currency;
										                                }
									                            }
								
								                            double parsed;
								                            int parsedInt;
								                            String formatted;
								
								                            if (Decimals) {
									                                parsed = Double.parseDouble(cleanString);
									                                formatted = java.text.NumberFormat.getCurrencyInstance().format((parsed / 100)).replace(java.text.NumberFormat.getCurrencyInstance().getCurrency().getSymbol(), currencyFormat);
									                            } else {
									                                parsedInt = Integer.parseInt(cleanString);
									                                formatted = currencyFormat + java.text.NumberFormat.getNumberInstance(java.util.Locale.US).format(parsedInt);
									                            }
								
								                            current = formatted;
								
								                            //if decimals are turned off and Separator is set as anything other than commas..
								                            if (!Separator.equals(",") && !Decimals) {
									                                //..replace the commas with the new separator
									                                editText.setText(formatted.replaceAll(",", Separator));
									                            } else {
									                                //since no custom separators were set, proceed with comma separation
									                                editText.setText(formatted);
									                            }
								                            editText.setSelection(formatted.length());
								                        } catch (java.lang.NumberFormatException e) {
								
								                        }
							                    }
						
						                    editText.addTextChangedListener(this);
						                }
					            }
				
				            @Override
				            public void afterTextChanged(android.text.Editable editable) {
					
					            }
				        });
			    }
		
		    /*
    *
    */
		    public double getCleanDoubleValue() {
			        double value = 0.0;
			        if (Decimals) {
				            value = Double.parseDouble(editText.getText().toString().trim().replaceAll("[$,]", "").replaceAll(Currency, ""));
				        } else {
				            String cleanString = editText.getText().toString().trim().replaceAll("[$,.]", "").replaceAll(Currency, "").replaceAll("\\s+", "");
				            try {
					                value = Double.parseDouble(cleanString);
					            } catch (java.lang.NumberFormatException e) {
					
					            }
				        }
			        return value;
			    }
		
		    public int getCleanIntValue() {
			        int value = 0;
			        if (Decimals) {
				            double doubleValue = Double.parseDouble(editText.getText().toString().trim().replaceAll("[$,]", "").replaceAll(Currency, ""));
				            value = (int) Math.round(doubleValue);
				        } else {
				            String cleanString = editText.getText().toString().trim().replaceAll("[$,.]", "").replaceAll(Currency, "").replaceAll("\\s+", "");
				            try {
					                value = Integer.parseInt(cleanString);
					            } catch (java.lang.NumberFormatException e) {
					
					            }
				        }
			        return value;
			    }
		
		    public void setDecimals(boolean value) {
			        this.Decimals = value;
			    }
		
		    public void setCurrency(String currencySymbol) {
			        this.Currency = currencySymbol;
			    }
		
		    public void setSpacing(boolean value) {
			        this.Spacing = value;
			    }
		
		    public void setDelimiter(boolean value) {
			        this.Delimiter = value;
			    }
		
		    /**
     * Separator allows a custom symbol to be used as the thousand separator. Default is set as comma (e.g: 20,000)
     * <p>
     * Custom Separator cannot be set when Decimals is set as `true`. Set Decimals as `false` to continue setting up custom separator
     *
     * @value is the custom symbol sent in place of the default comma
     */
		    public void setSeparator(String value) {
			        this.Separator = value;
			    }
	}
	{
	}
	public class CurrencySymbols {
		    public static final String NONE = "";
		    public static final String MALAYSIA = "RM";
		    public static final String INDONESIA = "Rp";
		    public static final String SRILANKA = "Rs";
		    public static final String USA = "$";
		    public static final String UK = "£";
		    public static final String INDIA = "₹";
		    public static final String PHILIPPINES = "₱";
		    public static final String PAKISTAN = "₨";
		    public static final String NIGERIA = "₦";
	}
	{
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _advancedCorners(final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}