package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class DetailTransferActivity extends AppCompatActivity {
	
	private LinearLayout linear3;
	private LinearLayout linear_garis1;
	private LinearLayout linear6;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear_garis4;
	private LinearLayout linear24;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private LinearLayout linear7;
	private LinearLayout linear_garis2;
	private LinearLayout linear12;
	private LinearLayout linear_garis3;
	private LinearLayout linear18;
	private LinearLayout linear8;
	private LinearLayout line;
	private LinearLayout linear35;
	private TextView NamIn;
	private LinearLayout line1;
	private TextView name_recipient;
	private TextView numbIn;
	private LinearLayout linear36;
	private TextView numb_recipient;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private TextView textview3;
	private ImageView imageview2;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private LinearLayout linear_pesan;
	private EditText pesan;
	private LinearLayout linear34;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private ImageView imageview4;
	private LinearLayout linear31;
	private TextView textview11;
	private TextView textview12;
	private LinearLayout linear29;
	private TextView textview14;
	private TextView textview13;
	private LinearLayout linear30;
	private TextView textview15;
	private TextView textview16;
	private LinearLayout linear32;
	private TextView textview17;
	private LinearLayout linear25;
	private LinearLayout button1;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.detail_transfer);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		linear_garis1 = findViewById(R.id.linear_garis1);
		linear6 = findViewById(R.id.linear6);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		linear_garis4 = findViewById(R.id.linear_garis4);
		linear24 = findViewById(R.id.linear24);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		linear7 = findViewById(R.id.linear7);
		linear_garis2 = findViewById(R.id.linear_garis2);
		linear12 = findViewById(R.id.linear12);
		linear_garis3 = findViewById(R.id.linear_garis3);
		linear18 = findViewById(R.id.linear18);
		linear8 = findViewById(R.id.linear8);
		line = findViewById(R.id.line);
		linear35 = findViewById(R.id.linear35);
		NamIn = findViewById(R.id.NamIn);
		line1 = findViewById(R.id.line1);
		name_recipient = findViewById(R.id.name_recipient);
		numbIn = findViewById(R.id.numbIn);
		linear36 = findViewById(R.id.linear36);
		numb_recipient = findViewById(R.id.numb_recipient);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		textview3 = findViewById(R.id.textview3);
		imageview2 = findViewById(R.id.imageview2);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		textview7 = findViewById(R.id.textview7);
		linear_pesan = findViewById(R.id.linear_pesan);
		pesan = findViewById(R.id.pesan);
		linear34 = findViewById(R.id.linear34);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		imageview4 = findViewById(R.id.imageview4);
		linear31 = findViewById(R.id.linear31);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		linear29 = findViewById(R.id.linear29);
		textview14 = findViewById(R.id.textview14);
		textview13 = findViewById(R.id.textview13);
		linear30 = findViewById(R.id.linear30);
		textview15 = findViewById(R.id.textview15);
		textview16 = findViewById(R.id.textview16);
		linear32 = findViewById(R.id.linear32);
		textview17 = findViewById(R.id.textview17);
		linear25 = findViewById(R.id.linear25);
		button1 = findViewById(R.id.button1);
		textview8 = findViewById(R.id.textview8);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		linear_pesan.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFF5F5F5));
		_viewGraphics(button1, 0xFF000000, 0xFF000000, 300, 1, 0xFF000000);
		name_recipient.setText("");
		numb_recipient.setText("");
		name_recipient.setText("");
		numb_recipient.setText("");
		name_recipient.setText("");
		numb_recipient.setText("");
	}
	
	public void _viewGraphics(final View _view, final int _onFocus, final int _onRipple, final double _radius, final double _stroke, final int _strokeColor) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(_onFocus);
		GG.setCornerRadius((float)_radius);
		GG.setStroke((int) _stroke, _strokeColor);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ _onRipple}), GG, null);
		_view.setBackground(RE);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}