package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ListPulsaFragmentActivity extends Fragment {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> Map = new HashMap<>();
	private HashMap<String, Object> Map2 = new HashMap<>();
	private String status = "";
	private String data = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double telkomsel = 0;
	private double indosat = 0;
	private double save = 0;
	
	private ArrayList<HashMap<String, Object>> testing = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	
	private LinearLayout linear13;
	private ListView listview1;
	
	private RequestNetwork viewProduct;
	private RequestNetwork.RequestListener _viewProduct_request_listener;
	private SharedPreferences sp;
	private Intent in = new Intent();
	private TimerTask t;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.list_pulsa_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear13 = _view.findViewById(R.id.linear13);
		listview1 = _view.findViewById(R.id.listview1);
		viewProduct = new RequestNetwork((Activity) getContext());
		sp = getContext().getSharedPreferences("sp", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		
		_viewProduct_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Map = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				status = (new Gson()).toJson(Map2.get("key"), new TypeToken<HashMap<String, Object>>(){}.getType());
				Map2 = new Gson().fromJson(status, new TypeToken<HashMap<String, Object>>(){}.getType());
				data = (new Gson()).toJson(Map.get("data"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listMap = new Gson().fromJson(data, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(listMap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				_removeScollBar(listview1);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("telkomsel")) {
						telkomsel = Double.parseDouble(_childValue.get("telkomsel").toString());
					}
					if (_childValue.containsKey("indosat")) {
						indosat = Double.parseDouble(_childValue.get("indosat").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("telkomsel")) {
						telkomsel = Double.parseDouble(_childValue.get("telkomsel").toString());
					}
					if (_childValue.containsKey("indosat")) {
						indosat = Double.parseDouble(_childValue.get("indosat").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if (sp.getString("code", "").equals("")) {
			SketchwareUtil.showMessage(getContext().getApplicationContext(), "Maaf Gagal Mendapatkan Data, Silahkan Ulangi kembali");
		} else {
			viewProduct.startRequestNetwork(RequestNetworkController.GET, "https://api.tokovoucher.net/member/produk/list?member_code=".concat(sp.getString("member_id", "").concat("&signature=".concat(sp.getString("signature", "").concat("&id_jenis=".concat(sp.getString("code", "")))))), "", _viewProduct_request_listener);
		}
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.pulsa_custom, null);
			}
			
			final LinearLayout core_pulsa = _view.findViewById(R.id.core_pulsa);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview_jumlah = _view.findViewById(R.id.textview_jumlah);
			final TextView textview_nominal = _view.findViewById(R.id.textview_nominal);
			
			core_pulsa.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getContext().getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFFF8F7FC);SketchUi.setCornerRadii(new float[]{
					d*10,d*10,d*10 ,d*10,d*0,d*0 ,d*0,d*0});
				linear2.setBackground(SketchUi);
			}
			textview_jumlah.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
			textview_nominal.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
			if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa Telkomsel")) {
				textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
				textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("telkomsel", "")))));
				core_pulsa.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
						in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
						in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
						in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("telkomsel", "")))));
						in.putExtra("tujuan", sp.getString("tujuan", ""));
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					}
				});
			} else {
				if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa AXIS")) {
					textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
					textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("axis", "")))));
					core_pulsa.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
							in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
							in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
							in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("axis", "")))));
							in.putExtra("tujuan", sp.getString("tujuan", ""));
							in.setAction(Intent.ACTION_VIEW);
							startActivity(in);
						}
					});
				} else {
					if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa XL")) {
						textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
						textview_nominal.setText("Rp".concat(new DecimalFormat("###,##0").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("xl", "")))));
						core_pulsa.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
								in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
								in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
								in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("xl", "")))));
								in.putExtra("tujuan", sp.getString("tujuan", ""));
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					} else {
						if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa INDOSAT")) {
							textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
							textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("indosat", "")))));
							core_pulsa.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
									sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
									in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
									in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
									in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("indosat", "")))));
									in.putExtra("tujuan", sp.getString("tujuan", ""));
									in.setAction(Intent.ACTION_VIEW);
									startActivity(in);
								}
							});
						} else {
							if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa TRI")) {
								textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
								textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("tri", "")))));
								core_pulsa.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
										sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
										in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
										in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
										in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("tri", "")))));
										in.putExtra("tujuan", sp.getString("tujuan", ""));
										in.setAction(Intent.ACTION_VIEW);
										startActivity(in);
									}
								});
							} else {
								if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa SMARTFREN")) {
									textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
									textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("smartfren", "")))));
									core_pulsa.setOnClickListener(new View.OnClickListener() {
										@Override
										public void onClick(View _view) {
											sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
											in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
											in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
											in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("smartfren", "")))));
											in.putExtra("tujuan", sp.getString("tujuan", ""));
											in.setAction(Intent.ACTION_VIEW);
											startActivity(in);
										}
									});
								}
							}
						}
					}
				}
			}
			
			return _view;
		}
	}
}