package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MasaAktifFragmentActivity extends Fragment {
	
	private HashMap<String, Object> Map = new HashMap<>();
	private HashMap<String, Object> Map2 = new HashMap<>();
	private String data = "";
	private String status = "";
	
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	
	private RequestNetwork viewProduk;
	private RequestNetwork.RequestListener _viewProduk_request_listener;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.masa_aktif_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		listview1 = _view.findViewById(R.id.listview1);
		viewProduk = new RequestNetwork((Activity) getContext());
		
		_viewProduk_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Map = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				status = (new Gson()).toJson(Map2.get("key"), new TypeToken<HashMap<String, Object>>(){}.getType());
				Map2 = new Gson().fromJson(status, new TypeToken<HashMap<String, Object>>(){}.getType());
				data = (new Gson()).toJson(Map.get("data"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listMap = new Gson().fromJson(data, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(listMap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		viewProduk.startRequestNetwork(RequestNetworkController.GET, "https://api.tokovoucher.net/member/produk/list?member_code=".concat(sp.getString("member_id", "").concat("&signature=".concat(sp.getString("signature", "").concat("&id_jenis=".concat(sp.getString("code", "")))))), "", _viewProduk_request_listener);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.pulsa_custom, null);
			}
			
			final LinearLayout core_pulsa = _view.findViewById(R.id.core_pulsa);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview_jumlah = _view.findViewById(R.id.textview_jumlah);
			final TextView textview_nominal = _view.findViewById(R.id.textview_nominal);
			
			core_pulsa.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getContext().getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFFF8F7FC);SketchUi.setCornerRadii(new float[]{
					d*10,d*10,d*10 ,d*10,d*0,d*0 ,d*0,d*0});
				linear2.setBackground(SketchUi);
			}
			textview_jumlah.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
			textview_nominal.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/light.ttf"), 1);
			if (_data.get((int)_position).get("operator_nama").toString().equals("Telkomsel")) {
				textview_jumlah.setText(_data.get((int)_position).get("nama").toString());
				textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("telkomsel", "")))));
				core_pulsa.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
						in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
						in.putExtra("nama_produk", _data.get((int)_position).get("nama").toString());
						in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("telkomsel", "")))));
						in.putExtra("tujuan", sp.getString("tujuan", ""));
						in.setAction(Intent.ACTION_VIEW);
						startActivity(in);
					}
				});
			} else {
				if (_data.get((int)_position).get("operator_nama").toString().equals("Axis")) {
					textview_jumlah.setText(_data.get((int)_position).get("nama").toString());
					textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("axis", "")))));
					core_pulsa.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
							in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
							in.putExtra("nama_produk", _data.get((int)_position).get("nama").toString());
							in.putExtra("nominal", "");
							in.putExtra("tujuan", sp.getString("tujuan", ""));
							in.setAction(Intent.ACTION_VIEW);
							startActivity(in);
						}
					});
				} else {
					if (_data.get((int)_position).get("operator_nama").toString().equals("XL")) {
						textview_jumlah.setText(_data.get((int)_position).get("nama").toString());
						textview_nominal.setText("Rp".concat(new DecimalFormat("###,##0").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("xl", "")))));
						core_pulsa.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
								in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
								in.putExtra("nama_produk", _data.get((int)_position).get("nama").toString());
								in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("xl", "")))));
								in.putExtra("tujuan", sp.getString("tujuan", ""));
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					} else {
						if (_data.get((int)_position).get("operator_nama").toString().equals("Indosat")) {
							textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
							textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("indosat", "")))));
							core_pulsa.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
									sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
									in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
									in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
									in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("indosat", "")))));
									in.putExtra("tujuan", sp.getString("tujuan", ""));
									in.setAction(Intent.ACTION_VIEW);
									startActivity(in);
								}
							});
						} else {
							if (_data.get((int)_position).get("operator_produk").toString().equals("Three")) {
								textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
								textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("tri", "")))));
								core_pulsa.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
										sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
										in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
										in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
										in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("tri", "")))));
										in.putExtra("tujuan", sp.getString("tujuan", ""));
										in.setAction(Intent.ACTION_VIEW);
										startActivity(in);
									}
								});
							} else {
								if (_data.get((int)_position).get("operator_produk").toString().equals("Pulsa SMARTFREN")) {
									textview_jumlah.setText(_data.get((int)_position).get("nama_produk").toString());
									textview_nominal.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("smartfren", "")))));
									core_pulsa.setOnClickListener(new View.OnClickListener() {
										@Override
										public void onClick(View _view) {
											sp.edit().putString("code", _data.get((int)_position).get("code").toString()).commit();
											in.setClass(getContext().getApplicationContext(), CheckoutActivity.class);
											in.putExtra("nama_produk", _data.get((int)_position).get("nama_produk").toString());
											in.putExtra("nominal", String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("price").toString()) + Double.parseDouble(sp.getString("smartfren", "")))));
											in.putExtra("tujuan", sp.getString("tujuan", ""));
											in.setAction(Intent.ACTION_VIEW);
											startActivity(in);
										}
									});
								}
							}
						}
					}
				}
			}
			
			return _view;
		}
	}
}