package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class IsiSaldoFragmentActivity extends Fragment {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	private boolean sucess = false;
	private double rand = 0;
	private String dataJSON = "";
	private String username = "";
	private String email = "";
	private String no = "";
	private String refid = "";
	private String message = "";
	private String data = "";
	private String merchantRef = "";
	private String paymentSelectionType = "";
	private String paymentMethod = "";
	private String paymentName = "";
	private String customerPhone = "";
	private String customerName = "";
	private String customerEmail = "";
	private String callbackUrl = "";
	private String returnUrl = "";
	private String amount = "";
	private String feeMerchant = "";
	private String feeCustomer = "";
	private String totalFee = "";
	private String amountReceived = "";
	private String payCode = "";
	private String payUrl = "";
	private String checkoutUrl = "";
	private String status = "";
	private String expiredTime = "";
	private String HasilRef = "";
	private String HasilAmount = "";
	private String HasilMF = "";
	private String HasilCF = "";
	private String HasilAR = "";
	private String HasilStatus = "";
	private String HasilUrl = "";
	
	private LinearLayout linear26;
	private ScrollView vscroll1;
	private TextView textview18;
	private LinearLayout linear1;
	private TextView textview17;
	private LinearLayout linear2;
	private LinearLayout core_topup1;
	private LinearLayout core_topup2;
	private LinearLayout core_topup3;
	private LinearLayout core_topup4;
	private LinearLayout core_topup5;
	private LinearLayout core_topup6;
	private TextView textview14;
	private LinearLayout core_topup_manual;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private CircleImageView circleimageview1;
	private TextView textview1;
	private TextView textview3;
	private ImageView imageview1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView imageview4;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private CircleImageView circleimageview2;
	private TextView textview4;
	private TextView textview5;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private CircleImageView circleimageview3;
	private TextView textview6;
	private TextView textview7;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private CircleImageView circleimageview4;
	private TextView textview8;
	private TextView textview9;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private CircleImageView circleimageview5;
	private TextView textview10;
	private TextView textview11;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private CircleImageView circleimageview6;
	private TextView textview12;
	private TextView textview13;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private CircleImageView circleimageview7;
	private TextView textview15;
	private TextView textview16;
	
	private Intent in = new Intent();
	private TimerTask t;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference deposit = _firebase.getReference("deposit");
	private ChildEventListener _deposit_child_listener;
	private RequestNetwork req;
	private RequestNetwork.RequestListener _req_request_listener;
	private Calendar c = Calendar.getInstance();
	private SharedPreferences sp;
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.isi_saldo_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear26 = _view.findViewById(R.id.linear26);
		vscroll1 = _view.findViewById(R.id.vscroll1);
		textview18 = _view.findViewById(R.id.textview18);
		linear1 = _view.findViewById(R.id.linear1);
		textview17 = _view.findViewById(R.id.textview17);
		linear2 = _view.findViewById(R.id.linear2);
		core_topup1 = _view.findViewById(R.id.core_topup1);
		core_topup2 = _view.findViewById(R.id.core_topup2);
		core_topup3 = _view.findViewById(R.id.core_topup3);
		core_topup4 = _view.findViewById(R.id.core_topup4);
		core_topup5 = _view.findViewById(R.id.core_topup5);
		core_topup6 = _view.findViewById(R.id.core_topup6);
		textview14 = _view.findViewById(R.id.textview14);
		core_topup_manual = _view.findViewById(R.id.core_topup_manual);
		linear3 = _view.findViewById(R.id.linear3);
		linear4 = _view.findViewById(R.id.linear4);
		linear5 = _view.findViewById(R.id.linear5);
		linear6 = _view.findViewById(R.id.linear6);
		linear7 = _view.findViewById(R.id.linear7);
		circleimageview1 = _view.findViewById(R.id.circleimageview1);
		textview1 = _view.findViewById(R.id.textview1);
		textview3 = _view.findViewById(R.id.textview3);
		imageview1 = _view.findViewById(R.id.imageview1);
		imageview2 = _view.findViewById(R.id.imageview2);
		imageview3 = _view.findViewById(R.id.imageview3);
		imageview4 = _view.findViewById(R.id.imageview4);
		linear9 = _view.findViewById(R.id.linear9);
		linear10 = _view.findViewById(R.id.linear10);
		circleimageview2 = _view.findViewById(R.id.circleimageview2);
		textview4 = _view.findViewById(R.id.textview4);
		textview5 = _view.findViewById(R.id.textview5);
		linear12 = _view.findViewById(R.id.linear12);
		linear13 = _view.findViewById(R.id.linear13);
		circleimageview3 = _view.findViewById(R.id.circleimageview3);
		textview6 = _view.findViewById(R.id.textview6);
		textview7 = _view.findViewById(R.id.textview7);
		linear15 = _view.findViewById(R.id.linear15);
		linear16 = _view.findViewById(R.id.linear16);
		circleimageview4 = _view.findViewById(R.id.circleimageview4);
		textview8 = _view.findViewById(R.id.textview8);
		textview9 = _view.findViewById(R.id.textview9);
		linear18 = _view.findViewById(R.id.linear18);
		linear19 = _view.findViewById(R.id.linear19);
		circleimageview5 = _view.findViewById(R.id.circleimageview5);
		textview10 = _view.findViewById(R.id.textview10);
		textview11 = _view.findViewById(R.id.textview11);
		linear21 = _view.findViewById(R.id.linear21);
		linear22 = _view.findViewById(R.id.linear22);
		circleimageview6 = _view.findViewById(R.id.circleimageview6);
		textview12 = _view.findViewById(R.id.textview12);
		textview13 = _view.findViewById(R.id.textview13);
		linear24 = _view.findViewById(R.id.linear24);
		linear25 = _view.findViewById(R.id.linear25);
		circleimageview7 = _view.findViewById(R.id.circleimageview7);
		textview15 = _view.findViewById(R.id.textview15);
		textview16 = _view.findViewById(R.id.textview16);
		auth = FirebaseAuth.getInstance();
		req = new RequestNetwork((Activity) getContext());
		sp = getContext().getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		core_topup3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				map = new HashMap<>();
				map.put("method", "OVO");
				deposit.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
			}
		});
		
		core_topup4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				c = Calendar.getInstance();
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				core_topup4.startAnimation(fade_in);
				map = new HashMap<>();
				map.put("method", "QRIS2");
				deposit.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
				rand = SketchwareUtil.getRandom((int)(100000), (int)(900000));
				refid = String.valueOf((long)(SketchwareUtil.getRandom((int)(100000), (int)(900000)) + c.getTimeInMillis()));
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
								fade_in.setDuration(300);
								fade_in.setFillAfter(true);
								linear12.startAnimation(fade_in);
								map = new HashMap<>();
								map.put("refid", "INV".concat(refid));
								map.put("total", sp.getString("nominal", ""));
								map.put("method", sp.getString("method", ""));
								map.put("username", "NoblePay");
								map.put("email", "user@gmail.com");
								map.put("no", "081234457888");
								map.put("unik", String.valueOf((long)(rand)));
								map.put("apikey", sp.getString("apikey", ""));
								map.put("private_key", sp.getString("privatekey", ""));
								map.put("merchant", sp.getString("merchant", ""));
								req.setParams(map, RequestNetworkController.REQUEST_PARAM);
								req.startRequestNetwork(RequestNetworkController.POST, "https://anseltsm.biz.id/Tripay/order.php", "", _req_request_listener);
							}
						});
					}
				};
				_timer.schedule(t, (int)(4000));
			}
		});
		
		core_topup5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				map = new HashMap<>();
				map.put("method", "DANA");
				deposit.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
			}
		});
		
		core_topup_manual.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				core_topup_manual.startAnimation(fade_in);
				t = new TimerTask() {
					@Override
					public void run() {
						getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								in.setClass(getContext().getApplicationContext(), PayWithQrisManualActivity.class);
								in.setAction(Intent.ACTION_VIEW);
								startActivity(in);
							}
						});
					}
				};
				_timer.schedule(t, (int)(200));
			}
		});
		
		_deposit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					sp.edit().putString("nominal", _childValue.get("nominal").toString()).commit();
					sp.edit().putString("method", _childValue.get("method").toString()).commit();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					sp.edit().putString("nominal", _childValue.get("nominal").toString()).commit();
					sp.edit().putString("method", _childValue.get("method").toString()).commit();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		deposit.addChildEventListener(_deposit_child_listener);
		
		_req_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				dataJSON = _response;
				try{
					
					
					// Parse data JSON
					JSONObject json = new JSONObject(dataJSON);
					
					// Cek apakah parsing berhasil
					if (json != null) {
						  // Ambil data dari JSON
						  boolean success = json.getBoolean("success");
						  String message = json.getString("message");
						  JSONObject data = json.getJSONObject("data");
						
						  // Ambil data transaksi
						  String reference = data.getString("reference");
						  String merchantRef = data.getString("merchant_ref");
						  String paymentSelectionType = data.getString("payment_selection_type");
						  String paymentMethod = data.getString("payment_method");
						  String paymentName = data.getString("payment_name");
						  String customerName = data.getString("customer_name");
						  String customerEmail = data.getString("customer_email");
						  String customerPhone = data.getString("customer_phone");
						  String callbackUrl = data.getString("callback_url");
						  String returnUrl = data.getString("return_url");
						  int amount = data.getInt("amount");
						  int feeMerchant = data.getInt("fee_merchant");
						  int feeCustomer = data.getInt("fee_customer");
						  int totalFee = data.getInt("total_fee");
						  int amountReceived = data.getInt("amount_received");
						  String payCode = data.getString("pay_code");
						  String payUrl = data.getString("pay_url");
						  String checkoutUrl = data.getString("checkout_url");
						  String status = data.getString("status");
						  long expiredTime = data.getLong("expired_time");
						
						  // Tampilkan hasil parsing di beberapa TextV
						
						HasilRef = ("" + reference);
						HasilAmount = ("" + amount);
						HasilMF = ("" + feeMerchant);
						HasilCF = ("" + feeCustomer);
						HasilAR = ("" + amountReceived);
						HasilStatus = ("" + status);
						HasilUrl = ("" + checkoutUrl);
						
						 
						  
					} else {
						
					}
				} catch (Exception e) {}
				map = new HashMap<>();
				map.put("Reference", HasilRef);
				map.put("Amount", HasilAmount);
				map.put("Merchant_fee", HasilMF);
				map.put("Amount_received", HasilAR);
				map.put("Customer_fee", HasilCF);
				map.put("Status", HasilStatus);
				map.put("Url", HasilUrl);
				map.put("Customer_name", "NoblePay");
				map.put("Customer_phone", "082135462757");
				map.put("Customer_email", "noblepay@gmail.com");
				map.put("Unik", refid);
				deposit.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				//push data ke database
				map.clear();
				in.setAction(Intent.ACTION_VIEW);
				in.setClass(getContext().getApplicationContext(), TripayActivity.class);
				startActivity(in);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					sp.edit().putString("apikey", _childValue.get("apikey").toString()).commit();
					sp.edit().putString("privatekey", _childValue.get("privatekey").toString()).commit();
					sp.edit().putString("merchant", _childValue.get("merchant").toString()).commit();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					sp.edit().putString("apikey", _childValue.get("apikey").toString()).commit();
					sp.edit().putString("privatekey", _childValue.get("privatekey").toString()).commit();
					sp.edit().putString("merchant", _childValue.get("merchant").toString()).commit();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		core_topup1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		core_topup2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		core_topup3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		core_topup4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		core_topup5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		core_topup6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		core_topup_manual.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
		c = Calendar.getInstance();
		ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
		fade_in.setDuration(300);
		fade_in.setFillAfter(true);
		core_topup4.startAnimation(fade_in);
		rand = SketchwareUtil.getRandom((int)(100000), (int)(900000));
		refid = String.valueOf((long)(SketchwareUtil.getRandom((int)(100000), (int)(900000)) + c.getTimeInMillis()));
		t = new TimerTask() {
			@Override
			public void run() {
				getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
						fade_in.setDuration(300);
						fade_in.setFillAfter(true);
						linear12.startAnimation(fade_in);
						map = new HashMap<>();
						map.put("refid", "INV".concat(refid));
						map.put("total", sp.getString("nominal", ""));
						map.put("method", sp.getString("method", ""));
						map.put("username", "NoblePay");
						map.put("email", "user@gmail.com");
						map.put("no", "081234457888");
						map.put("unik", String.valueOf((long)(rand)));
						map.put("apikey", sp.getString("apikey", ""));
						map.put("private_key", sp.getString("privatekey", ""));
						map.put("merchant", sp.getString("merchant", ""));
						req.setParams(map, RequestNetworkController.REQUEST_PARAM);
						req.startRequestNetwork(RequestNetworkController.POST, "https://anseltsm.biz.id/app/payment/order.php", "", _req_request_listener);
					}
				});
			}
		};
		_timer.schedule(t, (int)(4000));
	}
	
}