package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class RechargepyActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private String phoneNumber = "";
	private String maskedNumber = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String type = "";
	
	private LinearLayout linear3;
	private LinearLayout linear26;
	private LinearLayout linear_person;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private LinearLayout linear34;
	private LinearLayout linear40;
	private LinearLayout linear_history_core;
	private ImageView imageview1;
	private LinearLayout linear44;
	private TextView Name;
	private LinearLayout linear28;
	private LinearLayout linear31;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private TextView textview1;
	private TextView textview_mynumber;
	private ImageView imageview3;
	private LinearLayout linear35;
	private LinearLayout linear_nomor;
	private TextView textview3;
	private LinearLayout linear37;
	private EditText edittext1;
	private LinearLayout linear_delete;
	private LinearLayout linear_kontak;
	private TextView textview4;
	private ImageView imageview4;
	private ImageView imageview6;
	private TextView textview9;
	private LinearLayout button1;
	private TextView textview5;
	private LinearLayout linear42;
	private LinearLayout linear4;
	private TextView textview6;
	private ImageView imageview5;
	private LinearLayout linear43;
	private TextView textview7;
	private TextView textview8;
	
	private Vibrator vib;
	private TimerTask t;
	private Intent in = new Intent();
	private SharedPreferences sp;
	private DatabaseReference sqlUsers = _firebase.getReference("users");
	private ChildEventListener _sqlUsers_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private SharedPreferences data;
	private Intent activity = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.rechargepy);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		linear26 = findViewById(R.id.linear26);
		linear_person = findViewById(R.id.linear_person);
		linear32 = findViewById(R.id.linear32);
		linear33 = findViewById(R.id.linear33);
		linear34 = findViewById(R.id.linear34);
		linear40 = findViewById(R.id.linear40);
		linear_history_core = findViewById(R.id.linear_history_core);
		imageview1 = findViewById(R.id.imageview1);
		linear44 = findViewById(R.id.linear44);
		Name = findViewById(R.id.Name);
		linear28 = findViewById(R.id.linear28);
		linear31 = findViewById(R.id.linear31);
		linear29 = findViewById(R.id.linear29);
		linear30 = findViewById(R.id.linear30);
		textview1 = findViewById(R.id.textview1);
		textview_mynumber = findViewById(R.id.textview_mynumber);
		imageview3 = findViewById(R.id.imageview3);
		linear35 = findViewById(R.id.linear35);
		linear_nomor = findViewById(R.id.linear_nomor);
		textview3 = findViewById(R.id.textview3);
		linear37 = findViewById(R.id.linear37);
		edittext1 = findViewById(R.id.edittext1);
		linear_delete = findViewById(R.id.linear_delete);
		linear_kontak = findViewById(R.id.linear_kontak);
		textview4 = findViewById(R.id.textview4);
		imageview4 = findViewById(R.id.imageview4);
		imageview6 = findViewById(R.id.imageview6);
		textview9 = findViewById(R.id.textview9);
		button1 = findViewById(R.id.button1);
		textview5 = findViewById(R.id.textview5);
		linear42 = findViewById(R.id.linear42);
		linear4 = findViewById(R.id.linear4);
		textview6 = findViewById(R.id.textview6);
		imageview5 = findViewById(R.id.imageview5);
		linear43 = findViewById(R.id.linear43);
		textview7 = findViewById(R.id.textview7);
		textview8 = findViewById(R.id.textview8);
		vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		linear_person.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				linear_person.startAnimation(fade_in);
				_telegramLoaderDialog(true);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_telegramLoaderDialog(false);
								if (textview_mynumber.getText().toString().equals("Belum ada nomor telepon!")) {
									type = "number";
									t = new TimerTask() {
										@Override
										public void run() {
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													activity.setClass(getApplicationContext(), UpdateNumericActivity.class);
													activity.putExtra("t1", "Tambahkan Nomor Telepon");
													activity.putExtra("t2", "Masukkan nomor telepon Anda untuk memperbarui akun Anda.");
													activity.putExtra("hint", data.getString("mask-number", ""));
													activity.putExtra("type", type);
													startActivity(activity);
												}
											});
										}
									};
									_timer.schedule(t, (int)(200));
								} else {
									if (getIntent().getStringExtra("type").equals("Dana")) {
										in.setClass(getApplicationContext(), EwalletTopupActivity.class);
										in.putExtra("number", textview_mynumber.getText().toString());
										in.putExtra("type", "Dana");
										sp.edit().putString("code_wallet", "123").commit();
										sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
										in.setAction(Intent.ACTION_VIEW);
										startActivity(in);
									} else {
										if (getIntent().getStringExtra("type").equals("Ovo")) {
											in.setClass(getApplicationContext(), EwalletTopupActivity.class);
											in.putExtra("number", textview_mynumber.getText().toString());
											sp.edit().putString("code_wallet", "124").commit();
											in.putExtra("type", "Ovo");
											sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
											in.setAction(Intent.ACTION_VIEW);
											startActivity(in);
										} else {
											if (getIntent().getStringExtra("type").equals("LinkAja")) {
												in.setClass(getApplicationContext(), EwalletTopupActivity.class);
												in.putExtra("number", textview_mynumber.getText().toString());
												sp.edit().putString("code_wallet", "263").commit();
												in.putExtra("type", "LinkAja");
												sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
												in.setAction(Intent.ACTION_VIEW);
												startActivity(in);
											} else {
												if (getIntent().getStringExtra("type").equals("Gopay")) {
													in.setClass(getApplicationContext(), EwalletTopupActivity.class);
													in.putExtra("number", textview_mynumber.getText().toString());
													sp.edit().putString("code_wallet", "125").commit();
													in.putExtra("type", "Gopay");
													sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
													in.setAction(Intent.ACTION_VIEW);
													startActivity(in);
												} else {
													if (getIntent().getStringExtra("type").equals("Kaspro")) {
														in.setClass(getApplicationContext(), EwalletTopupActivity.class);
														in.putExtra("number", textview_mynumber.getText().toString());
														sp.edit().putString("code_wallet", "275").commit();
														in.putExtra("type", "Kaspro");
														sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
														in.setAction(Intent.ACTION_VIEW);
														startActivity(in);
													} else {
														if (getIntent().getStringExtra("type").equals("ShopeePay")) {
															in.setClass(getApplicationContext(), EwalletTopupActivity.class);
															in.putExtra("number", textview_mynumber.getText().toString());
															sp.edit().putString("code_wallet", "380").commit();
															in.putExtra("type", "ShopeePay");
															sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
															in.setAction(Intent.ACTION_VIEW);
															startActivity(in);
														} else {
															if (getIntent().getStringExtra("type").equals("iSaku")) {
																in.setClass(getApplicationContext(), EwalletTopupActivity.class);
																in.putExtra("number", textview_mynumber.getText().toString());
																sp.edit().putString("code_wallet", "267").commit();
																in.putExtra("type", "iSaku");
																sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
																in.setAction(Intent.ACTION_VIEW);
																startActivity(in);
															} else {
																if (getIntent().getStringExtra("type").equals("Grab")) {
																	in.setClass(getApplicationContext(), EwalletTopupActivity.class);
																	in.putExtra("number", textview_mynumber.getText().toString());
																	sp.edit().putString("code_wallet", "138").commit();
																	in.putExtra("type", "Grab");
																	sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
																	in.setAction(Intent.ACTION_VIEW);
																	startActivity(in);
																} else {
																	if (getIntent().getStringExtra("type").equals("PulsaData")) {
																		in.setClass(getApplicationContext(), ListItemActivity.class);
																		in.putExtra("CNumber", textview_mynumber.getText().toString());
																		in.putExtra("Number", textview_mynumber.getText().toString());
																		sp.edit().putString("code", "27").commit();
																		sp.edit().putString("code_data", "67").commit();
																		sp.edit().putString("tujuan", textview_mynumber.getText().toString()).commit();
																		in.setAction(Intent.ACTION_VIEW);
																		startActivity(in);
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sp.edit().remove("ct").commit();
				finish();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (getIntent().getStringExtra("type").equals("Dana")) {
					// Ambil input dari EditText
					String input = edittext1.getText().toString();
					
					// Hapus angka 0 di awal jika ada
					if (input.startsWith("0")) {
						    input = input.substring(1);
						    edittext1.setText(input); // Update teks di EditText
						    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
					}
					
					// Tampilkan atau sembunyikan tombol hapus
					if (!edittext1.getText().toString().isEmpty()) {
						    linear_delete.setVisibility(View.VISIBLE);
						    linear_kontak.setVisibility(View.GONE);
					} else {
						    linear_delete.setVisibility(View.GONE);
						    linear_kontak.setVisibility(View.VISIBLE);
					}
					sp.edit().putString("code_wallet", "123").commit();
				} else {
					if (getIntent().getStringExtra("type").equals("Ovo")) {
						// Ambil input dari EditText
						String input = edittext1.getText().toString();
						
						// Hapus angka 0 di awal jika ada
						if (input.startsWith("0")) {
							    input = input.substring(1);
							    edittext1.setText(input); // Update teks di EditText
							    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
						}
						
						// Tampilkan atau sembunyikan tombol hapus
						if (!edittext1.getText().toString().isEmpty()) {
							    linear_delete.setVisibility(View.VISIBLE);
							    linear_kontak.setVisibility(View.GONE);
						} else {
							    linear_delete.setVisibility(View.GONE);
							    linear_kontak.setVisibility(View.VISIBLE);
						}
						sp.edit().putString("code_wallet", "124").commit();
					} else {
						if (getIntent().getStringExtra("type").equals("LinkAja")) {
							// Ambil input dari EditText
							String input = edittext1.getText().toString();
							
							// Hapus angka 0 di awal jika ada
							if (input.startsWith("0")) {
								    input = input.substring(1);
								    edittext1.setText(input); // Update teks di EditText
								    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
							}
							
							// Tampilkan atau sembunyikan tombol hapus
							if (!edittext1.getText().toString().isEmpty()) {
								    linear_delete.setVisibility(View.VISIBLE);
								    linear_kontak.setVisibility(View.GONE);
							} else {
								    linear_delete.setVisibility(View.GONE);
								    linear_kontak.setVisibility(View.VISIBLE);
							}
							sp.edit().putString("code_wallet", "263").commit();
						} else {
							if (getIntent().getStringExtra("type").equals("Gopay")) {
								// Ambil input dari EditText
								String input = edittext1.getText().toString();
								
								// Hapus angka 0 di awal jika ada
								if (input.startsWith("0")) {
									    input = input.substring(1);
									    edittext1.setText(input); // Update teks di EditText
									    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
								}
								
								// Tampilkan atau sembunyikan tombol hapus
								if (!edittext1.getText().toString().isEmpty()) {
									    linear_delete.setVisibility(View.VISIBLE);
									    linear_kontak.setVisibility(View.GONE);
								} else {
									    linear_delete.setVisibility(View.GONE);
									    linear_kontak.setVisibility(View.VISIBLE);
								}
								sp.edit().putString("code_wallet", "125").commit();
							} else {
								if (getIntent().getStringExtra("type").equals("Kaspro")) {
									// Ambil input dari EditText
									String input = edittext1.getText().toString();
									
									// Hapus angka 0 di awal jika ada
									if (input.startsWith("0")) {
										    input = input.substring(1);
										    edittext1.setText(input); // Update teks di EditText
										    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
									}
									
									// Tampilkan atau sembunyikan tombol hapus
									if (!edittext1.getText().toString().isEmpty()) {
										    linear_delete.setVisibility(View.VISIBLE);
										    linear_kontak.setVisibility(View.GONE);
									} else {
										    linear_delete.setVisibility(View.GONE);
										    linear_kontak.setVisibility(View.VISIBLE);
									}
									sp.edit().putString("code_wallet", "275").commit();
								} else {
									if (getIntent().getStringExtra("type").equals("ShopeePay")) {
										// Ambil input dari EditText
										String input = edittext1.getText().toString();
										
										// Hapus angka 0 di awal jika ada
										if (input.startsWith("0")) {
											    input = input.substring(1);
											    edittext1.setText(input); // Update teks di EditText
											    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
										}
										
										// Tampilkan atau sembunyikan tombol hapus
										if (!edittext1.getText().toString().isEmpty()) {
											    linear_delete.setVisibility(View.VISIBLE);
											    linear_kontak.setVisibility(View.GONE);
										} else {
											    linear_delete.setVisibility(View.GONE);
											    linear_kontak.setVisibility(View.VISIBLE);
										}
										sp.edit().putString("code_wallet", "380").commit();
									} else {
										if (getIntent().getStringExtra("type").equals("iSaku")) {
											// Ambil input dari EditText
											String input = edittext1.getText().toString();
											
											// Hapus angka 0 di awal jika ada
											if (input.startsWith("0")) {
												    input = input.substring(1);
												    edittext1.setText(input); // Update teks di EditText
												    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
											}
											
											// Tampilkan atau sembunyikan tombol hapus
											if (!edittext1.getText().toString().isEmpty()) {
												    linear_delete.setVisibility(View.VISIBLE);
												    linear_kontak.setVisibility(View.GONE);
											} else {
												    linear_delete.setVisibility(View.GONE);
												    linear_kontak.setVisibility(View.VISIBLE);
											}
											sp.edit().putString("code_wallet", "267").commit();
										} else {
											if (getIntent().getStringExtra("type").equals("Grab")) {
												// Ambil input dari EditText
												String input = edittext1.getText().toString();
												
												// Hapus angka 0 di awal jika ada
												if (input.startsWith("0")) {
													    input = input.substring(1);
													    edittext1.setText(input); // Update teks di EditText
													    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
												}
												
												// Tampilkan atau sembunyikan tombol hapus
												if (!edittext1.getText().toString().isEmpty()) {
													    linear_delete.setVisibility(View.VISIBLE);
													    linear_kontak.setVisibility(View.GONE);
												} else {
													    linear_delete.setVisibility(View.GONE);
													    linear_kontak.setVisibility(View.VISIBLE);
												}
												sp.edit().putString("code_wallet", "138").commit();
											} else {
												if (getIntent().getStringExtra("type").equals("PulsaData")) {
													// Ambil input dari EditText
													String input = edittext1.getText().toString();
													
													// Hapus angka 0 di awal jika ada
													if (input.startsWith("0")) {
														    input = input.substring(1);
														    edittext1.setText(input); // Update teks di EditText
														    edittext1.setSelection(input.length()); // Pindahkan kursor ke akhir
													}
													
													// Tampilkan atau sembunyikan tombol hapus
													if (!edittext1.getText().toString().isEmpty()) {
														    linear_delete.setVisibility(View.VISIBLE);
														    linear_kontak.setVisibility(View.GONE);
													} else {
														    linear_delete.setVisibility(View.GONE);
														    linear_kontak.setVisibility(View.VISIBLE);
													}
													
													// Deteksi operator berdasarkan prefix (awalan nomor tanpa 0)
													if (input.startsWith("811") || input.startsWith("812") || input.startsWith("813") || 
													    input.startsWith("821") || input.startsWith("822") || input.startsWith("823") || 
													    input.startsWith("851") || input.startsWith("852") || input.startsWith("853")) {
														    // Telkomsel
														    sp.edit().putString("code", "25").commit();
														    sp.edit().putString("code_data", "36").commit();
														sp.edit().putString("ma","103").commit();
													} else if (input.startsWith("814") || input.startsWith("815") || input.startsWith("816") || 
													           input.startsWith("855") || input.startsWith("856") || input.startsWith("857") || 
													           input.startsWith("858")) {
														    // Indosat Ooredoo
														    sp.edit().putString("code", "31").commit();
														    sp.edit().putString("code_data", "39").commit();
													} else if (input.startsWith("817") || input.startsWith("818") || input.startsWith("819") || 
													           input.startsWith("859") || input.startsWith("879") || input.startsWith("877") || input.startsWith("878")) {
														    // XL Axiata
														    sp.edit().putString("code", "29").commit();
														    sp.edit().putString("code_data", "38").commit();
													} else if (input.startsWith("895") || input.startsWith("896") || input.startsWith("897") || 
													           input.startsWith("898") || input.startsWith("899")) {
														    // Tri (3)
														    sp.edit().putString("code", "35").commit();
														    sp.edit().putString("code_data", "40").commit();
													} else if (input.startsWith("831") || input.startsWith("832") || input.startsWith("833") || 
													           input.startsWith("838")) {
														    // Axis
														    sp.edit().putString("code", "27").commit();
														    sp.edit().putString("code_data", "37").commit();
													} else if (input.startsWith("881") || input.startsWith("882") || input.startsWith("883") || 
													           input.startsWith("884") || input.startsWith("885") || input.startsWith("886") || 
													           input.startsWith("887") || input.startsWith("888") || input.startsWith("889")) {
														    // Smartfren
														    sp.edit().putString("code", "33").commit();
														    sp.edit().putString("code_data", "41").commit();
													} else {
														    // Jika operator tidak dikenali
														    sp.edit().putString("code", "unknown").commit();
														    sp.edit().putString("code_data", "unknown").commit();
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		linear_kontak.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sp.edit().remove("ct").commit();
				in.setClass(getApplicationContext(), ChooseContactActivity.class);
				in.setAction(Intent.ACTION_VIEW);
				startActivity(in);
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sp.edit().remove("ct").commit();
				edittext1.setText("");
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sp.edit().remove("ct").commit();
				ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
				fade_in.setDuration(300);
				fade_in.setFillAfter(true);
				button1.startAnimation(fade_in);
				if (edittext1.getText().toString().length() > 10) {
					_telegramLoaderDialog(true);
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									_telegramLoaderDialog(false);
									if (getIntent().getStringExtra("type").equals("Dana")) {
										in.setClass(getApplicationContext(), EwalletTopupActivity.class);
										in.putExtra("number", "0".concat(edittext1.getText().toString()));
										in.putExtra("type", "Dana");
										sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
										in.setAction(Intent.ACTION_VIEW);
										startActivity(in);
									} else {
										if (getIntent().getStringExtra("type").equals("Ovo")) {
											in.setClass(getApplicationContext(), EwalletTopupActivity.class);
											in.putExtra("number", "0".concat(edittext1.getText().toString()));
											in.putExtra("type", "Ovo");
											sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
											in.setAction(Intent.ACTION_VIEW);
											startActivity(in);
										} else {
											if (getIntent().getStringExtra("type").equals("LinkAja")) {
												in.setClass(getApplicationContext(), EwalletTopupActivity.class);
												in.putExtra("number", "0".concat(edittext1.getText().toString()));
												in.putExtra("type", "LinkAja");
												sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
												in.setAction(Intent.ACTION_VIEW);
												startActivity(in);
											} else {
												if (getIntent().getStringExtra("type").equals("Gopay")) {
													in.setClass(getApplicationContext(), EwalletTopupActivity.class);
													in.putExtra("number", "0".concat(edittext1.getText().toString()));
													in.putExtra("type", "Gopay");
													sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
													in.setAction(Intent.ACTION_VIEW);
													startActivity(in);
												} else {
													if (getIntent().getStringExtra("type").equals("Kaspro")) {
														in.setClass(getApplicationContext(), EwalletTopupActivity.class);
														in.putExtra("number", "0".concat(edittext1.getText().toString()));
														in.putExtra("type", "Kaspro");
														sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
														in.setAction(Intent.ACTION_VIEW);
														startActivity(in);
													} else {
														if (getIntent().getStringExtra("type").equals("ShopeePay")) {
															in.setClass(getApplicationContext(), EwalletTopupActivity.class);
															in.putExtra("number", "0".concat(edittext1.getText().toString()));
															in.putExtra("type", "ShopeePay");
															sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
															in.setAction(Intent.ACTION_VIEW);
															startActivity(in);
														} else {
															if (getIntent().getStringExtra("type").equals("iSaku")) {
																in.setClass(getApplicationContext(), EwalletTopupActivity.class);
																in.putExtra("number", "0".concat(edittext1.getText().toString()));
																in.putExtra("type", "iSaku");
																sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
																in.setAction(Intent.ACTION_VIEW);
																startActivity(in);
															} else {
																if (getIntent().getStringExtra("type").equals("Grab")) {
																	in.setClass(getApplicationContext(), EwalletTopupActivity.class);
																	in.putExtra("number", "0".concat(edittext1.getText().toString()));
																	in.putExtra("type", "Grab");
																	sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
																	in.setAction(Intent.ACTION_VIEW);
																	startActivity(in);
																} else {
																	if (getIntent().getStringExtra("type").equals("PulsaData")) {
																		in.setClass(getApplicationContext(), ListItemActivity.class);
																		in.putExtra("CNumber", "0".concat(edittext1.getText().toString()));
																		in.putExtra("Number", "0".concat(edittext1.getText().toString()));
																		sp.edit().putString("tujuan", "0".concat(edittext1.getText().toString())).commit();
																		in.setAction(Intent.ACTION_VIEW);
																		startActivity(in);
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							});
						}
					};
					_timer.schedule(t, (int)(3000));
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Masukkan Nomor Telepon Dengan Benar!");
				}
			}
		});
		
		_sqlUsers_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childKey)) {
					if (_childValue.containsKey("number")) {
						phoneNumber = _childValue.get("number").toString();
						String maskedPhoneNum = phoneNumber.replaceAll("\\d(?=\\d{4})", "*");
						textview_mynumber.setText(_childValue.get("number").toString());
					} else {
						if (!_childValue.containsKey("number")) {
							textview_mynumber.setText("Belum ada nomor telepon!");
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("number")) {
					phoneNumber = _childValue.get("number").toString();
					String maskedPhoneNum = phoneNumber.replaceAll("\\d(?=\\d{4})", "*");
					textview_mynumber.setText(_childValue.get("number").toString());
				} else {
					if (!_childValue.containsKey("number")) {
						textview_mynumber.setText("Belum ada nomor telepon!");
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlUsers.addChildEventListener(_sqlUsers_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		_autoTransitionScroll(linear_history_core);
		_changeActivityFont("muli");
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		Name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/muli.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/muli.ttf"), 1);
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)80, 0xFF000000));
		linear_nomor.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF9E9E9E, 0xFFF8F7FC));
		linear_delete.setVisibility(View.INVISIBLE);
		_LengthOfEditText(edittext1, 11);
		if (getIntent().getStringExtra("type").equals("Dana")) {
			Name.setText("Topup Dana");
		} else {
			if (getIntent().getStringExtra("type").equals("Ovo")) {
				Name.setText("Topup Ovo");
			} else {
				if (getIntent().getStringExtra("type").equals("LinkAja")) {
					Name.setText("Topup LinkAja");
				} else {
					if (getIntent().getStringExtra("type").equals("Gopay")) {
						Name.setText("Topup Gopay");
					} else {
						if (getIntent().getStringExtra("type").equals("Kaspro")) {
							Name.setText("Topup Kaspro");
						} else {
							if (getIntent().getStringExtra("type").equals("ShopeePay")) {
								Name.setText("Topup ShopeePay");
							} else {
								if (getIntent().getStringExtra("type").equals("iSaku")) {
									Name.setText("Topup iSaku");
								} else {
									if (getIntent().getStringExtra("type").equals("Grab")) {
										Name.setText("Topup Grab");
									} else {
										if (getIntent().getStringExtra("type").equals("PulsaData")) {
											Name.setText("Pulsa & Data");
										}
									}
								}
							}
						}
					}
				}
			}
		}
		if (Build.VERSION.SDK_INT >= 23) {
			//SDK > 23
			if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_DENIED) {
				//Denied
				requestPermissions(new String[] {android.Manifest.permission.READ_CONTACTS}, 1111);
			}else {
				//Granted
				 
			}
		}else {
			//SDK < 23
			 
		}
	}
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Override
	public void onResume() {
		super.onResume();
		edittext1.setText(sp.getString("ct", ""));
	}
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)_scroll, new android.transition.AutoTransition());
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		} else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _LengthOfEditText(final TextView _editText, final double _value_character) {
		InputFilter[] gb = _editText.getFilters(); 
		InputFilter[] newFilters = new InputFilter[gb.length + 1]; 
		System.arraycopy(gb, 0, newFilters, 0, gb.length); 
		newFilters[gb.length] = new InputFilter.LengthFilter((int)_value_character); 
		_editText.setFilters(newFilters);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}