package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class NotifikasiFragmentActivity extends Fragment {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> inbox = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> Inbox = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	private LinearLayout linear_notif;
	private ImageView imageview2;
	private TextView textview3;
	private TextView textview2;
	
	private DatabaseReference userInbox = _firebase.getReference("inbox");
	private ChildEventListener _userInbox_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.notifikasi_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		listview1 = _view.findViewById(R.id.listview1);
		linear_notif = _view.findViewById(R.id.linear_notif);
		imageview2 = _view.findViewById(R.id.imageview2);
		textview3 = _view.findViewById(R.id.textview3);
		textview2 = _view.findViewById(R.id.textview2);
		auth = FirebaseAuth.getInstance();
		
		_userInbox_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				userInbox.child(_childKey).addChildEventListener(new ChildEventListener() {
					    @Override
					    public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
						        // Ambil data notifikasi
						        HashMap<String, Object> pushData = (HashMap<String, Object>) dataSnapshot.getValue();
						
						        if (pushData != null) {
							            HashMap<String, Object> _item = new HashMap<>();
							            String pushKey = dataSnapshot.getKey();  // Ambil pushKey dari data
							
							            // Pengecekan apakah pushData memiliki UID yang sama dengan pengguna yang sedang login
							            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
							            if (pushData.containsKey("UID") && pushData.get("UID").equals(userId)) {
								                // Periksa apakah notifikasi dengan pushKey yang sama sudah ada di Inbox
								                boolean itemExists = false;
								                for (HashMap<String, Object> existingItem : Inbox) {
									                    if (existingItem.containsKey("pushKey") && existingItem.get("pushKey").equals(pushKey)) {
										                        itemExists = true;
										                        break;  // Jika sudah ada, tidak perlu menambah
										                    }
									                }
								
								                // Jika notifikasi belum ada, tambahkan
								                if (!itemExists) {
									                    // Tambahkan data baru ke Inbox
									                    _item.put("Time", pushData.get("Time"));
									                    _item.put("Judul", pushData.get("Judul"));
									                    _item.put("Pesan", pushData.get("Pesan"));
									                    _item.put("pushKey", pushKey);  // Simpan pushKey untuk identifikasi
									
									                    Inbox.add(_item);  // Tambahkan ke list Inbox
									                }
								
								                // Update adapter
								                if (listview1.getAdapter() == null) {
									                    listview1.setAdapter(new Listview1Adapter(Inbox));
									                } else {
									                    ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
									                }
								
								                // Jika ada data di Inbox, sembunyikan linear_notif dan tampilkan listview1
								                if (!Inbox.isEmpty()) {
									                    linear_notif.setVisibility(View.GONE);  // Sembunyikan linear_notif
									                    listview1.setVisibility(View.VISIBLE);  // Tampilkan listview1
									                }
								            }
							        }
						    }
					
					    @Override
					    public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {
						        // Update data jika ada perubahan
						        HashMap<String, Object> pushData = (HashMap<String, Object>) dataSnapshot.getValue();
						        if (pushData != null) {
							            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
							            if (pushData.containsKey("UID") && pushData.get("UID").equals(userId)) {
								                for (HashMap<String, Object> existingItem : Inbox) {
									                    if (existingItem.containsKey("pushKey") && existingItem.get("pushKey").equals(dataSnapshot.getKey())) {
										                        existingItem.put("Time", pushData.get("Time"));
										                        existingItem.put("Judul", pushData.get("Judul"));
										                        existingItem.put("Pesan", pushData.get("Pesan"));
										                        break;
										                    }
									                }
								
								                // Perbarui adapter
								                ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
								            }
							        }
						    }
					
					    @Override
					    public void onChildRemoved(DataSnapshot dataSnapshot) {
						        // Hapus data yang dihapus di Firebase dari Inbox
						        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
						        if (dataSnapshot.exists() && dataSnapshot.hasChild("UID")) {
							            String pushDataUid = (String) dataSnapshot.child("UID").getValue();
							            if (pushDataUid.equals(userId)) {
								                Inbox.removeIf(item -> item.containsKey("pushKey") && item.get("pushKey").equals(dataSnapshot.getKey()));
								                ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
								
								                // Jika Inbox kosong, tampilkan linear_notif
								                if (Inbox.isEmpty()) {
									                    linear_notif.setVisibility(View.VISIBLE);  // Tampilkan linear_notif
									                    listview1.setVisibility(View.GONE);  // Sembunyikan listview1
									                }
								            }
							        }
						    }
					
					    @Override
					    public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {
						        // Tidak perlu menangani pergerakan data
						    }
					
					    @Override
					    public void onCancelled(DatabaseError databaseError) {
						        // Tangani error jika perlu
						    }
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				userInbox.child(_childKey).addChildEventListener(new ChildEventListener() {
					    @Override
					    public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
						        // Ambil data notifikasi
						        HashMap<String, Object> pushData = (HashMap<String, Object>) dataSnapshot.getValue();
						
						        if (pushData != null) {
							            HashMap<String, Object> _item = new HashMap<>();
							            String pushKey = dataSnapshot.getKey();  // Ambil pushKey dari data
							
							            // Pengecekan apakah pushData memiliki UID yang sama dengan pengguna yang sedang login
							            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
							            if (pushData.containsKey("UID") && pushData.get("UID").equals(userId)) {
								                // Periksa apakah notifikasi dengan pushKey yang sama sudah ada di Inbox
								                boolean itemExists = false;
								                for (HashMap<String, Object> existingItem : Inbox) {
									                    if (existingItem.containsKey("pushKey") && existingItem.get("pushKey").equals(pushKey)) {
										                        itemExists = true;
										                        break;  // Jika sudah ada, tidak perlu menambah
										                    }
									                }
								
								                // Jika notifikasi belum ada, tambahkan
								                if (!itemExists) {
									                    // Tambahkan data baru ke Inbox
									                    _item.put("Time", pushData.get("Time"));
									                    _item.put("Judul", pushData.get("Judul"));
									                    _item.put("Pesan", pushData.get("Pesan"));
									                    _item.put("pushKey", pushKey);  // Simpan pushKey untuk identifikasi
									
									                    Inbox.add(_item);  // Tambahkan ke list Inbox
									                }
								
								                // Update adapter
								                if (listview1.getAdapter() == null) {
									                    listview1.setAdapter(new Listview1Adapter(Inbox));
									                } else {
									                    ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
									                }
								
								                // Jika ada data di Inbox, sembunyikan linear_notif dan tampilkan listview1
								                if (!Inbox.isEmpty()) {
									                    linear_notif.setVisibility(View.GONE);  // Sembunyikan linear_notif
									                    listview1.setVisibility(View.VISIBLE);  // Tampilkan listview1
									                }
								            }
							        }
						    }
					
					    @Override
					    public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {
						        // Update data jika ada perubahan
						        HashMap<String, Object> pushData = (HashMap<String, Object>) dataSnapshot.getValue();
						        if (pushData != null) {
							            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
							            if (pushData.containsKey("UID") && pushData.get("UID").equals(userId)) {
								                for (HashMap<String, Object> existingItem : Inbox) {
									                    if (existingItem.containsKey("pushKey") && existingItem.get("pushKey").equals(dataSnapshot.getKey())) {
										                        existingItem.put("Time", pushData.get("Time"));
										                        existingItem.put("Judul", pushData.get("Judul"));
										                        existingItem.put("Pesan", pushData.get("Pesan"));
										                        break;
										                    }
									                }
								
								                // Perbarui adapter
								                ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
								            }
							        }
						    }
					
					    @Override
					    public void onChildRemoved(DataSnapshot dataSnapshot) {
						        // Hapus data yang dihapus di Firebase dari Inbox
						        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
						        if (dataSnapshot.exists() && dataSnapshot.hasChild("UID")) {
							            String pushDataUid = (String) dataSnapshot.child("UID").getValue();
							            if (pushDataUid.equals(userId)) {
								                Inbox.removeIf(item -> item.containsKey("pushKey") && item.get("pushKey").equals(dataSnapshot.getKey()));
								                ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
								
								                // Jika Inbox kosong, tampilkan linear_notif
								                if (Inbox.isEmpty()) {
									                    linear_notif.setVisibility(View.VISIBLE);  // Tampilkan linear_notif
									                    listview1.setVisibility(View.GONE);  // Sembunyikan listview1
									                }
								            }
							        }
						    }
					
					    @Override
					    public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {
						        // Tidak perlu menangani pergerakan data
						    }
					
					    @Override
					    public void onCancelled(DatabaseError databaseError) {
						        // Tangani error jika perlu
						    }
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userInbox.addChildEventListener(_userInbox_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_removeScollBar(listview1);
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.notifikasi_custom, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView time = _view.findViewById(R.id.time);
			final TextView judul = _view.findViewById(R.id.judul);
			final TextView pesan = _view.findViewById(R.id.pesan);
			
			// Periksa apakah posisi valid dan data di Inbox tidak null
			if (Inbox != null && _position >= 0 && _position < Inbox.size()) {
				    HashMap<String, Object> item = Inbox.get(_position);
				
				    if (item != null) {
					        // Set nilai Time dengan pengecekan null
					        if (item.containsKey("Time") && item.get("Time") != null) {
						            time.setText(item.get("Time").toString());
						        } else {
						            time.setText("Waktu tidak tersedia"); // Nilai default
						        }
					
					        // Set nilai Judul dengan pengecekan null
					        if (item.containsKey("Judul") && item.get("Judul") != null) {
						            judul.setText(item.get("Judul").toString());
						        } else {
						            judul.setText("Judul tidak tersedia"); // Nilai default
						        }
					
					        // Set nilai Pesan dengan pengecekan null
					        if (item.containsKey("Pesan") && item.get("Pesan") != null) {
						            pesan.setText(item.get("Pesan").toString());
						        } else {
						            pesan.setText("Pesan tidak tersedia"); // Nilai default
						        }
					    } else {
					        // Jika item null, set teks default
					        time.setText("Waktu tidak tersedia");
					        judul.setText("Judul tidak tersedia");
					        pesan.setText("Pesan tidak tersedia");
					    }
			} else {
				    // Jika posisi tidak valid atau Inbox kosong
				    time.setText("Waktu tidak tersedia");
				    judul.setText("Judul tidak tersedia");
				    pesan.setText("Pesan tidak tersedia");
			}
			
			return _view;
		}
	}
}