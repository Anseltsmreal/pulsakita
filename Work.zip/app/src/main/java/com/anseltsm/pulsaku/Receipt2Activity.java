package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class Receipt2Activity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> Map = new HashMap<>();
	private HashMap<String, Object> Map2 = new HashMap<>();
	private String statuss = "";
	private String data = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double balance = 0;
	
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear_core;
	private LinearLayout linear11;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView menu;
	private LinearLayout linear14;
	private LinearLayout linear2;
	private LinearLayout linear15;
	private ListView listview1;
	private TextView amt1;
	private TextView mess;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout line;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear17;
	private LinearLayout linear19;
	private LinearLayout linear18;
	private TextView textview4;
	private LinearLayout linear8;
	private LinearLayout line2;
	private LinearLayout linear24;
	private TextView NamIn;
	private LinearLayout line1;
	private TextView name_produk;
	private TextView numbIn;
	private LinearLayout linear25;
	private TextView numb_tujuan;
	private TextView textview5;
	private TextView biller;
	private TextView textview7;
	private TextView trs_ref;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private TextView textview9;
	private TextView amt2;
	private TextView textview13;
	private TextView fee;
	private LinearLayout linear23;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private TextView textview16;
	private TextView textview19;
	private TextView status;
	private LinearLayout linear22;
	private TextView date_time;
	private TextView textview20;
	private TextView ss_id;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference trx = _firebase.getReference("transaksi/gagal");
	private ChildEventListener _trx_child_listener;
	private DatabaseReference trxx = _firebase.getReference("transaksi");
	private ChildEventListener _trxx_child_listener;
	private SharedPreferences sp;
	private Intent i = new Intent();
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private TimerTask t;
	private DatabaseReference deposit_sucess = _firebase.getReference("depositSucess");
	private ChildEventListener _deposit_sucess_child_listener;
	private DatabaseReference deposit = _firebase.getReference("deposit");
	private ChildEventListener _deposit_child_listener;
	private DatabaseReference wallet = _firebase.getReference("wallet");
	private ChildEventListener _wallet_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.receipt2);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear_core = findViewById(R.id.linear_core);
		linear11 = findViewById(R.id.linear11);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		menu = findViewById(R.id.menu);
		linear14 = findViewById(R.id.linear14);
		linear2 = findViewById(R.id.linear2);
		linear15 = findViewById(R.id.linear15);
		listview1 = findViewById(R.id.listview1);
		amt1 = findViewById(R.id.amt1);
		mess = findViewById(R.id.mess);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		line = findViewById(R.id.line);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear17 = findViewById(R.id.linear17);
		linear19 = findViewById(R.id.linear19);
		linear18 = findViewById(R.id.linear18);
		textview4 = findViewById(R.id.textview4);
		linear8 = findViewById(R.id.linear8);
		line2 = findViewById(R.id.line2);
		linear24 = findViewById(R.id.linear24);
		NamIn = findViewById(R.id.NamIn);
		line1 = findViewById(R.id.line1);
		name_produk = findViewById(R.id.name_produk);
		numbIn = findViewById(R.id.numbIn);
		linear25 = findViewById(R.id.linear25);
		numb_tujuan = findViewById(R.id.numb_tujuan);
		textview5 = findViewById(R.id.textview5);
		biller = findViewById(R.id.biller);
		textview7 = findViewById(R.id.textview7);
		trs_ref = findViewById(R.id.trs_ref);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		textview9 = findViewById(R.id.textview9);
		amt2 = findViewById(R.id.amt2);
		textview13 = findViewById(R.id.textview13);
		fee = findViewById(R.id.fee);
		linear23 = findViewById(R.id.linear23);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		textview16 = findViewById(R.id.textview16);
		textview19 = findViewById(R.id.textview19);
		status = findViewById(R.id.status);
		linear22 = findViewById(R.id.linear22);
		date_time = findViewById(R.id.date_time);
		textview20 = findViewById(R.id.textview20);
		ss_id = findViewById(R.id.ss_id);
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		net = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MainActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		menu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				{PopupMenu popup = new PopupMenu(Receipt2Activity.this, menu);
							android.view.Menu menu = popup.getMenu();
					
					menu.add("Refresh");
					popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
						
										public boolean onMenuItemClick(android.view.MenuItem item) {
												switch (item.getTitle().toString()) {
														
														case "Refresh":
								net.startRequestNetwork(RequestNetworkController.GET, sp.getString("url", ""), "", _net_request_listener);
								_telegramLoaderDialog(true);
								t = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												_telegramLoaderDialog(false);
											}
										});
									}
								};
								_timer.schedule(t, (int)(3000));
								return true;
								
														default: return false;
												}
										}
								});
					
					
					popup.show();}
			}
		});
		
		_trx_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		trx.addChildEventListener(_trx_child_listener);
		
		_trxx_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("refid")) {
						trs_ref.setText(_childValue.get("refid").toString());
					}
					if (_childValue.containsKey("status")) {
						status.setText(_childValue.get("status").toString());
						mess.setText("Transaksi ".concat(_childValue.get("status").toString()));
						sp.edit().putString("status", _childValue.get("status").toString()).commit();
						if (sp.getString("status", "").equals("gagal")) {
							mess.setTextColor(0xFFF44336);
							status.setTextColor(0xFFF44336);
						} else {
							if (sp.getString("status", "").equals("pending")) {
								mess.setTextColor(0xFF2196F3);
								status.setTextColor(0xFF2196F3);
							} else {
								mess.setTextColor(0xFF76FF03);
								status.setTextColor(0xFF76FF03);
							}
						}
					}
					if (_childValue.containsKey("nama_produk")) {
						name_produk.setText(_childValue.get("nama_produk").toString());
						sp.edit().putString("produk", _childValue.get("nama_produk").toString()).commit();
					}
					if (_childValue.containsKey("trxid")) {
						ss_id.setText(_childValue.get("trxid").toString());
					}
					if (_childValue.containsKey("nominal")) {
						amt2.setText("Rp ".concat(_childValue.get("nominal").toString()));
						amt1.setText("Rp ".concat(_childValue.get("nominal").toString()));
					}
					if (_childValue.containsKey("tujuan")) {
						numb_tujuan.setText(_childValue.get("tujuan").toString());
					}
					if (_childValue.containsKey("tgl")) {
						date_time.setText(_childValue.get("tgl").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("refid")) {
						trs_ref.setText(_childValue.get("refid").toString());
					}
					if (_childValue.containsKey("status")) {
						status.setText(_childValue.get("status").toString());
						mess.setText("Transaksi ".concat(_childValue.get("status").toString()));
						sp.edit().putString("status", _childValue.get("status").toString()).commit();
						if (sp.getString("status", "").equals("gagal")) {
							mess.setTextColor(0xFFF44336);
							status.setTextColor(0xFFF44336);
						} else {
							if (sp.getString("status", "").equals("pending")) {
								mess.setTextColor(0xFF2196F3);
								status.setTextColor(0xFF2196F3);
							} else {
								mess.setTextColor(0xFF76FF03);
								status.setTextColor(0xFF76FF03);
							}
						}
					}
					if (_childValue.containsKey("nama_produk")) {
						name_produk.setText(_childValue.get("nama_produk").toString());
						sp.edit().putString("produk", _childValue.get("nama_produk").toString()).commit();
					}
					if (_childValue.containsKey("trxid")) {
						ss_id.setText(_childValue.get("trxid").toString());
					}
					if (_childValue.containsKey("nominal")) {
						amt2.setText("Rp ".concat(_childValue.get("nominal").toString()));
						amt1.setText("Rp ".concat(_childValue.get("nominal").toString()));
					}
					if (_childValue.containsKey("tujuan")) {
						numb_tujuan.setText(_childValue.get("tujuan").toString());
					}
					if (_childValue.containsKey("tgl")) {
						date_time.setText(_childValue.get("tgl").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		trxx.addChildEventListener(_trxx_child_listener);
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Map = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				statuss = (new Gson()).toJson(Map2.get("key"), new TypeToken<HashMap<String, Object>>(){}.getType());
				Map2 = new Gson().fromJson(statuss, new TypeToken<HashMap<String, Object>>(){}.getType());
				data = (new Gson()).toJson(Map.get("data"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listMap = new Gson().fromJson(data, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(listMap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_deposit_sucess_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("date")) {
						date_time.setText(_childValue.get("date").toString());
					}
					if (_childValue.containsKey("nominal")) {
						amt2.setText("Rp ".concat(_childValue.get("nominal").toString()));
					}
					if (_childValue.containsKey("brand_name")) {
						biller.setText(_childValue.get("brand_name").toString());
					}
					if (_childValue.containsKey("userreff")) {
						trs_ref.setText(_childValue.get("userreff").toString());
					}
					if (_childValue.containsKey("buyerref")) {
						ss_id.setText(_childValue.get("buyerref").toString());
					}
					if (_childValue.containsKey("status")) {
						status.setText(_childValue.get("status").toString());
					}
				} else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("date")) {
						date_time.setText(_childValue.get("date").toString());
					}
					if (_childValue.containsKey("nominal")) {
						amt2.setText("Rp ".concat(_childValue.get("nominal").toString()));
					}
					if (_childValue.containsKey("brand_name")) {
						biller.setText(_childValue.get("brand_name").toString());
					}
					if (_childValue.containsKey("userreff")) {
						trs_ref.setText(_childValue.get("userreff").toString());
					}
					if (_childValue.containsKey("buyerref")) {
						status.setText(_childValue.get("buyerref").toString());
					}
				} else {
					
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		deposit_sucess.addChildEventListener(_deposit_sucess_child_listener);
		
		_deposit_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("nominal")) {
						sp.edit().putString("nominal", _childValue.get("nominal").toString()).commit();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		deposit.addChildEventListener(_deposit_child_listener);
		
		_wallet_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("-available-balance")) {
						balance = Double.parseDouble(_childValue.get("-available-balance").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		wallet.addChildEventListener(_wallet_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		listview1.setVisibility(View.VISIBLE);
	}
	
	@Override
	public void onBackPressed() {
		
	}
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.qris_gateway, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			
			textview1.setText(_data.get((int)_position).get("date").toString());
			textview2.setText(_data.get((int)_position).get("amount").toString());
			textview3.setText(_data.get((int)_position).get("brand_name").toString());
			textview4.setText(_data.get((int)_position).get("issuer_reff").toString());
			textview5.setText(_data.get((int)_position).get("buyer_reff").toString());
			map = new HashMap<>();
			map.put("date", _data.get((int)_position).get("date").toString());
			map.put("nominal", _data.get((int)_position).get("amount").toString());
			map.put("brand_name", _data.get((int)_position).get("brand_name").toString());
			map.put("userreff", _data.get((int)_position).get("issuer_reff").toString());
			map.put("buyerref", "");
			deposit_sucess.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
			map.clear();
			if (_data.get((int)_position).containsKey("amount")) {
				if (_data.get((int)_position).get("amount").toString().equals(sp.getString("nominal", ""))) {
					map = new HashMap<>();
					map.put("-available-balance", String.valueOf((long)(balance + Double.parseDouble(_data.get((int)_position).get("amount").toString()))));
					wallet.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "Saldo Ditambah kan Ke Akun");
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Error Tidak Diketahui");
				}
			} else {
				
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}