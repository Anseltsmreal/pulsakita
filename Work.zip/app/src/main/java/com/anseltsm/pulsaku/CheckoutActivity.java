package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class CheckoutActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double balance = 0;
	private String refid = "";
	private String dataJSON = "";
	private String t1 = "";
	private String t2 = "";
	private String t3 = "";
	private String t4 = "";
	private String t5 = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private LinearLayout linear3;
	private LinearLayout linear_garis1;
	private ScrollView vscroll1;
	private LinearLayout linear24;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView Name;
	private LinearLayout linear26;
	private LinearLayout linear7;
	private LinearLayout linear_garis2;
	private LinearLayout linear12;
	private LinearLayout linear_garis3;
	private LinearLayout linear18;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear8;
	private LinearLayout linear10;
	private TextView textview_produk;
	private TextView textview_nomor;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private TextView textview3;
	private ImageView imageview2;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private LinearLayout linear19;
	private ImageView imageview3;
	private TextView textview7;
	private LinearLayout linear33;
	private ImageView imageview5;
	private LinearLayout linear34;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private ImageView imageview4;
	private LinearLayout linear31;
	private TextView textview11;
	private TextView textview12;
	private LinearLayout linear29;
	private TextView textview14;
	private TextView textview13;
	private LinearLayout linear30;
	private TextView textview15;
	private TextView textview16;
	private LinearLayout linear32;
	private TextView textview17;
	private LinearLayout linear25;
	private LinearLayout button1;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private SharedPreferences sp;
	private Calendar c = Calendar.getInstance();
	private RequestNetwork buy;
	private RequestNetwork.RequestListener _buy_request_listener;
	private AlertDialog cd;
	private TimerTask t;
	private Intent i = new Intent();
	private DatabaseReference sqlHistory = _firebase.getReference("history");
	private ChildEventListener _sqlHistory_child_listener;
	private DatabaseReference config = _firebase.getReference("config/data");
	private ChildEventListener _config_child_listener;
	private RequestNetwork tg;
	private RequestNetwork.RequestListener _tg_request_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.checkout);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear3 = findViewById(R.id.linear3);
		linear_garis1 = findViewById(R.id.linear_garis1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear24 = findViewById(R.id.linear24);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		Name = findViewById(R.id.Name);
		linear26 = findViewById(R.id.linear26);
		linear7 = findViewById(R.id.linear7);
		linear_garis2 = findViewById(R.id.linear_garis2);
		linear12 = findViewById(R.id.linear12);
		linear_garis3 = findViewById(R.id.linear_garis3);
		linear18 = findViewById(R.id.linear18);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		linear8 = findViewById(R.id.linear8);
		linear10 = findViewById(R.id.linear10);
		textview_produk = findViewById(R.id.textview_produk);
		textview_nomor = findViewById(R.id.textview_nomor);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		textview3 = findViewById(R.id.textview3);
		imageview2 = findViewById(R.id.imageview2);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		linear19 = findViewById(R.id.linear19);
		imageview3 = findViewById(R.id.imageview3);
		textview7 = findViewById(R.id.textview7);
		linear33 = findViewById(R.id.linear33);
		imageview5 = findViewById(R.id.imageview5);
		linear34 = findViewById(R.id.linear34);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		imageview4 = findViewById(R.id.imageview4);
		linear31 = findViewById(R.id.linear31);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		linear29 = findViewById(R.id.linear29);
		textview14 = findViewById(R.id.textview14);
		textview13 = findViewById(R.id.textview13);
		linear30 = findViewById(R.id.linear30);
		textview15 = findViewById(R.id.textview15);
		textview16 = findViewById(R.id.textview16);
		linear32 = findViewById(R.id.linear32);
		textview17 = findViewById(R.id.textview17);
		linear25 = findViewById(R.id.linear25);
		button1 = findViewById(R.id.button1);
		textview8 = findViewById(R.id.textview8);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		buy = new RequestNetwork(this);
		tg = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				c = Calendar.getInstance();
				refid = "TRX".concat(_getRandomText(9, "123456789").concat(new SimpleDateFormat("yyyyHHmm").format(c.getTime())));
				if ((balance > Double.parseDouble(sp.getString("decimal", ""))) || (balance == Double.parseDouble(sp.getString("decimal", "")))) {
					_telegramLoaderDialog(true);
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									buy.startRequestNetwork(RequestNetworkController.GET, "https://api.tokovoucher.net/v1/transaksi?ref_id=".concat(refid.concat("&produk=".concat(sp.getString("code", "").concat("&tujuan=".concat(getIntent().getStringExtra("tujuan").concat("&secret=".concat(sp.getString("secret_key", "").concat("&member_code=".concat(sp.getString("member_id", "").concat("&server_id=".concat(""))))))))))), "", _buy_request_listener);
								}
							});
						}
					};
					_timer.schedule(t, (int)(5000));
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Saldo anda tidak cukup untuk melakukan transaksi, Topup terlebih dahulu!");
				}
			}
		});
		
		_buy_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_telegramLoaderDialog(false);
				c = Calendar.getInstance();
				dataJSON = _response;
				try{
					JSONObject jsonObject = new JSONObject(dataJSON);
					t1 = jsonObject.getString("status");
					t2 = jsonObject.getString("ref_id");
					t3 = jsonObject.getString("trx_id");
					t4 = jsonObject.getString("produk");
					t5 = jsonObject.getString("price");
				} catch (Exception e) {}
				map = new HashMap<>();
				map.put("status", t1);
				map.put("refid", t2);
				map.put("trxid", t3);
				map.put("produk", textview_produk.getText().toString());
				map.put("amount", sp.getString("decimal", ""));
				map.put("jam", new SimpleDateFormat("HHmmss").format(c.getTime()));
				map.put("tujuan", textview_nomor.getText().toString());
				map.put("tgl", new SimpleDateFormat("EEEE, dd MMMM yyyy HH:mm:ss").format(c.getTime()));
				map.put("tanggal", new SimpleDateFormat("HH mm - dd MMMM yyyy").format(c.getTime()));
				map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				//push data transaksi gagal
				sqlHistory.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat(new SimpleDateFormat("HHmmss").format(c.getTime()))).updateChildren(map);
				sp.edit().putString("jam", new SimpleDateFormat("HHmmss").format(c.getTime())).commit();
				map.clear();
				if (t1.equals("gagal")) {
					map = new HashMap<>();
					map.put("saldo", String.valueOf((long)(balance - Double.parseDouble(sp.getString("decimal", "")))));
					users.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat(sp.getString("jam", ""))).updateChildren(map);
					map.clear();
				} else {
					if (t1.equals("pending")) {
						map = new HashMap<>();
						map.put("saldo", String.valueOf((long)(balance - Double.parseDouble(sp.getString("decimal", "")))));
						users.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat(sp.getString("jam", ""))).updateChildren(map);
						map.clear();
					} else {
						if (t1.equals("sukses")) {
							map = new HashMap<>();
							map.put("saldo", String.valueOf((long)(balance - Double.parseDouble(sp.getString("decimal", "")))));
							users.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat(sp.getString("jam", ""))).updateChildren(map);
							map.clear();
						}
					}
				}
				i.setAction(Intent.ACTION_VIEW);
				i.setClass(getApplicationContext(), ReceiptActivity.class);
				startActivity(i);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_sqlHistory_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sqlHistory.addChildEventListener(_sqlHistory_child_listener);
		
		_config_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("member_id")) {
						sp.edit().putString("member_id", _childValue.get("member_id").toString()).commit();
					}
					if (_childValue.containsKey("secret_key")) {
						sp.edit().putString("secret_key", _childValue.get("secret_key").toString()).commit();
					}
					if (_childValue.containsKey("signature")) {
						sp.edit().putString("signature", _childValue.get("signature").toString()).commit();
					}
				} else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("key")) {
					if (_childValue.containsKey("member_id")) {
						sp.edit().putString("member_id", _childValue.get("member_id").toString()).commit();
					}
					if (_childValue.containsKey("secret_key")) {
						sp.edit().putString("secret_key", _childValue.get("secret_key").toString()).commit();
					}
					if (_childValue.containsKey("signature")) {
						sp.edit().putString("signature", _childValue.get("signature").toString()).commit();
					}
				} else {
					
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		config.addChildEventListener(_config_child_listener);
		
		_tg_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					textview5.setText(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("saldo").toString())));
					balance = Double.parseDouble(_childValue.get("saldo").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					textview5.setText(new DecimalFormat("###,###,###").format(Double.parseDouble(_childValue.get("saldo").toString())));
					balance = Double.parseDouble(_childValue.get("saldo").toString());
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		Name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lafontbold.ttf"), 1);
		textview_produk.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lafontbold.ttf"), 1);
		textview_produk.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lafontbold.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lafontregular.ttf"), 1);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lafontregular.ttf"), 1);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lafontregular.ttf"), 1);
		if (Build.VERSION.SDK_INT >= 21) { Window w = this.getWindow(); w.setNavigationBarColor(Color.parseColor("#ffffff")); }
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)80, 0xFF000000));
		textview_produk.setText(getIntent().getStringExtra("nama_produk"));
		textview_nomor.setText(getIntent().getStringExtra("tujuan"));
		textview6.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(getIntent().getStringExtra("nominal")))));
		textview14.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(getIntent().getStringExtra("nominal")))));
		textview17.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(getIntent().getStringExtra("nominal")))));
		textview9.setText("Rp".concat(new DecimalFormat("###,###,###").format(Double.parseDouble(getIntent().getStringExtra("nominal")))));
		sp.edit().putString("decimal", getIntent().getStringExtra("nominal")).commit();
	}
	
	@Override
	public void onBackPressed() {
		
	}
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#ffffff")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public String _getRandomText(final double _num, final String _string) {
		String str2 = "";
		for (int i = 0; i < (int)_num; i++) {
				str2 = str2 + _string.charAt(new java.util.Random().nextInt(_string.length()));
		}
		return str2;
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}