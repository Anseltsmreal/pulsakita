package com.anseltsm.pulsaku;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.android.prime.arab.ware.everythingutils.*;
import com.bachors.wordtospan.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.budiyev.android.codescanner.*;
import com.facebook.shimmer.*;
import com.github.angads25.filepicker.*;
import com.github.chrisbanes.photoview.*;
import com.google.firebase.FirebaseApp;
import com.google.zxing.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class InformasiFragmentActivity extends Fragment {
	
	private ArrayList<HashMap<String, Object>> testing = new ArrayList<>();
	
	private ListView listview1;
	private LinearLayout linear_notif;
	private ImageView imageview2;
	private TextView textview3;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.informasi_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		listview1 = _view.findViewById(R.id.listview1);
		linear_notif = _view.findViewById(R.id.linear_notif);
		imageview2 = _view.findViewById(R.id.imageview2);
		textview3 = _view.findViewById(R.id.textview3);
	}
	
	private void initializeLogic() {
		linear_notif.setVisibility(View.GONE);
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("q", "w");
			testing.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("e", "r");
			testing.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("t", "y");
			testing.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("1", "2");
			testing.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("3", "4");
			testing.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("5", "6");
			testing.add(_item);
		}
		listview1.setAdapter(new Listview1Adapter(testing));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		_removeScollBar(listview1);
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.informasi_custom, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout background1 = _view.findViewById(R.id.background1);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout space = _view.findViewById(R.id.space);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout space2 = _view.findViewById(R.id.space2);
			final LinearLayout like_layout = _view.findViewById(R.id.like_layout);
			final ImageView time = _view.findViewById(R.id.time);
			final TextView timeText = _view.findViewById(R.id.timeText);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final TextView TagText = _view.findViewById(R.id.TagText);
			final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
			final ScrollView vscroll2 = _view.findViewById(R.id.vscroll2);
			final ImageView imageview6 = _view.findViewById(R.id.imageview6);
			final TextView text = _view.findViewById(R.id.text);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout Like_button = _view.findViewById(R.id.Like_button);
			final LinearLayout dontLike_button = _view.findViewById(R.id.dontLike_button);
			final LinearLayout comment_button = _view.findViewById(R.id.comment_button);
			final LinearLayout share_button = _view.findViewById(R.id.share_button);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			
			return _view;
		}
	}
}